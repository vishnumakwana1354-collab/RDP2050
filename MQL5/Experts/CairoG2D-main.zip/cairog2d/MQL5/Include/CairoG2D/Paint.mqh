//+------------------------------------------------------------------+
//|                                                      Paint.mqh   |
//|                              Copyright 2026, Sandro Begashvili   |
//|                   https://www.mql5.com/en/users/sandrobegashvil  |
//|                          Telegram: https://t.me/MrMQL5Developer  |
//|                    Cairo5 - 2D vector engine - PART 8 code       |
//|                                                                  |
//|  THE SOURCE LAYER - the half of Part 1's Cairo model that has    |
//|  been a single uint parameter for seven articles.                |
//|                                                                  |
//|  A paint answers exactly ONE question for the rasterizer:        |
//|                                                                  |
//|      what color is at pixel (x, y)?                              |
//|                                                                  |
//|  That single virtual method is the whole contract. It is why a   |
//|  solid color, a linear gradient and a radial gradient all work   |
//|  on EVERY shape the path can describe, and why the word          |
//|  "gradient" appears nowhere in Raster.mqh.                       |
//|                                                                  |
//|  Adding a kind of paint - a conic gradient for a gauge, a        |
//|  checkerboard, a noise texture, an image pattern - means writing |
//|  one subclass and touching nothing else in the library.          |
//|                                                                  |
//|  Applications usually do not hold a CCairoPaint directly. They   |
//|  hold a CCairoFillStyle, at the bottom of this file, which       |
//|  switches between solid / linear / radial / none behind one      |
//|  handle and owns whatever that switch allocates.                 |
//+------------------------------------------------------------------+
#ifndef CAIRO5_PAINT_MQH
#define CAIRO5_PAINT_MQH

#include "Color.mqh"

//+------------------------------------------------------------------+
//| Which kind of fill a CCairoFillStyle currently holds. Public so  |
//| that a caller can ask before reaching for SolidColor().          |
//+------------------------------------------------------------------+
enum ENUM_CAIRO_FILL
  {
   CAIRO_FILL_SOLID  = 0,      // one color everywhere
   CAIRO_FILL_LINEAR = 1,      // a gradient along an axis
   CAIRO_FILL_RADIAL = 2,      // a gradient out from a center
   CAIRO_FILL_NONE   = 3       // draw nothing at all
  };

//+------------------------------------------------------------------+
//| CCairoPaint - the abstract color source.                         |
//|                                                                  |
//| One virtual method. That is the entire interface, and keeping it |
//| this small is the design: every constraint we do NOT put here is |
//| a kind of paint somebody can invent later without our            |
//| permission.                                                      |
//|                                                                  |
//| The base returns opaque black rather than being pure virtual, so |
//| a half-configured paint draws something VISIBLE instead of       |
//| failing silently. In a GUI, a black rectangle is a much better   |
//| bug report than a shape that never appeared.                     |
//+------------------------------------------------------------------+
class CCairoPaint
  {
public:
   virtual          ~CCairoPaint() {}

   //--- 0xAARRGGBB for the given buffer pixel
   virtual uint      ColorAt(const int x, const int y) { return 0xFF000000; }
  };

//+------------------------------------------------------------------+
//| CCairoSolidPaint - one color everywhere.                         |
//|                                                                  |
//| The overwhelmingly common case, and the cheapest implementation  |
//| the contract allows: it ignores both arguments.                  |
//|                                                                  |
//| Note that this is not a special case bolted onto the rasterizer. |
//| It is an ordinary paint that happens to be constant, which is    |
//| the difference between a design and a pile of features.          |
//+------------------------------------------------------------------+
class CCairoSolidPaint : public CCairoPaint
  {
private:
   uint              m_color;

public:
                     CCairoSolidPaint();
                     CCairoSolidPaint(const uint argb);

   void              SetColor(const uint argb);
   uint              GetColor() const;

   virtual uint      ColorAt(const int x, const int y) override;
  };

//+------------------------------------------------------------------+
//| Constructors. Black until told otherwise, for the reason the     |
//| base class returns black.                                        |
//+------------------------------------------------------------------+
CCairoSolidPaint::CCairoSolidPaint()
  {
   m_color = 0xFF000000;
  }

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CCairoSolidPaint::CCairoSolidPaint(const uint argb)
  {
   m_color = argb;
  }

//+------------------------------------------------------------------+
//| Accessors.                                                       |
//+------------------------------------------------------------------+
void CCairoSolidPaint::SetColor(const uint argb)
  {
   m_color = argb;
  }

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
uint CCairoSolidPaint::GetColor() const
  {
   return m_color;
  }

//+------------------------------------------------------------------+
//| The contract, answered without looking at the pixel.             |
//+------------------------------------------------------------------+
uint CCairoSolidPaint::ColorAt(const int x, const int y)
  {
   return m_color;
  }

//+------------------------------------------------------------------+
//| CCairoGradientPaint - the color-stop store both gradient kinds   |
//| share.                                                           |
//|                                                                  |
//| A STOP is a position from 0 to 1 plus a color. The gradient is   |
//| the piecewise linear interpolation between consecutive stops.    |
//|                                                                  |
//| Subclasses do exactly one thing: turn a pixel (x, y) into the    |
//| gradient parameter t, then call Sample( t ). Linear projects the |
//| pixel onto an axis; radial measures a distance from a center.    |
//| That is the whole difference between them, and it is why the     |
//| stop machinery lives here rather than being written twice.       |
//+------------------------------------------------------------------+
class CCairoGradientPaint : public CCairoPaint
  {
protected:
   double            m_positions[];      // 0..1, kept ascending
   uint              m_colors[];         // one color per position
   int               m_stop_count;

public:
                     CCairoGradientPaint();

   void              ClearStops();
   void              AddStop(const double position, const uint argb);
   int               StopCount() const;
   uint              Sample(const double t);
  };

//+------------------------------------------------------------------+
//| Constructor - no stops. Sample() then returns black, which is    |
//| again a visible bug rather than a silent one.                    |
//+------------------------------------------------------------------+
CCairoGradientPaint::CCairoGradientPaint()
  {
   m_stop_count = 0;

   ArrayResize(m_positions, 0);
   ArrayResize(m_colors, 0);
  }

//+------------------------------------------------------------------+
//| Forget every stop, without releasing the arrays. A widget that   |
//| rebuilds its gradient on a theme change reuses the memory.       |
//+------------------------------------------------------------------+
void CCairoGradientPaint::ClearStops()
  {
   m_stop_count = 0;
  }

//+------------------------------------------------------------------+
//| Insert a stop, keeping the array sorted by position.             |
//|                                                                  |
//| Sorting ON INSERT rather than on use is the right trade here:    |
//| stops are added a handful of times when a widget is configured,  |
//| and Sample() runs once per PIXEL. Put the work on the rare side  |
//| of that ratio.                                                   |
//|                                                                  |
//| An insertion sort is the correct choice rather than a lazy one - |
//| gradients have two to four stops in practice, and at that size   |
//| nothing beats it.                                                |
//+------------------------------------------------------------------+
void CCairoGradientPaint::AddStop(const double position, const uint argb)
  {
   double pos = position;

   if(pos < 0.0)
      pos = 0.0;
   if(pos > 1.0)
      pos = 1.0;

//--- find the slot this stop belongs in
   int idx = m_stop_count;

   for(int i = 0; i < m_stop_count; i++)
     {
      if(pos < m_positions[i])
        {
         idx = i;
         break;
        }
     }

//--- grow in blocks of 8, the same way the path grows its points.
//--- BOTH arrays are tested, not just the first: a resize that
//--- succeeded for m_positions and failed for m_colors would leave
//--- the two at different lengths, and the write below would go
//--- past the end of the shorter one.
   if(ArraySize(m_positions) < m_stop_count + 1 ||
      ArraySize(m_colors)    < m_stop_count + 1)
     {
      if(ArrayResize(m_positions, m_stop_count + 1, 8) < 0 ||
         ArrayResize(m_colors,    m_stop_count + 1, 8) < 0)
         return;                   // refused - drop the stop, not the run

      //--- and if one of them came back short anyway, do not write
      if(ArraySize(m_positions) < m_stop_count + 1 ||
         ArraySize(m_colors)    < m_stop_count + 1)
         return;
     }

//--- shift the tail up one slot
   for(int j = m_stop_count; j > idx; j--)
     {
      m_positions[j] = m_positions[j - 1];
      m_colors[j]    = m_colors[j - 1];
     }

   m_positions[idx] = pos;
   m_colors[idx]    = argb;
   m_stop_count++;
  }

//+------------------------------------------------------------------+
//| How many stops are defined.                                      |
//+------------------------------------------------------------------+
int CCairoGradientPaint::StopCount() const
  {
   return m_stop_count;
  }

//+------------------------------------------------------------------+
//| The color at gradient parameter t.                               |
//|                                                                  |
//| Outside the defined range the end stops are HELD CONSTANT - the  |
//| "pad" extend mode, which is what every design tool does and what |
//| makes an off-center radial highlight behave sensibly instead of  |
//| wrapping or going black.                                         |
//|                                                                  |
//| The interpolation is CairoLerp from Part 1, which mixes the      |
//| ALPHA channel along with the color channels. A stop that is      |
//| fully transparent therefore fades a shape OUT rather than fading |
//| it toward black - which is precisely what a glow, a soft shadow  |
//| or the area fill under a price line needs.                       |
//+------------------------------------------------------------------+
uint CCairoGradientPaint::Sample(const double t)
  {
   if(m_stop_count == 0)
      return 0xFF000000;

   if(m_stop_count == 1)
      return m_colors[0];

//--- pad: clamp outside the defined range
   if(t <= m_positions[0])
      return m_colors[0];

   if(t >= m_positions[m_stop_count - 1])
      return m_colors[m_stop_count - 1];

   for(int i = 0; i < m_stop_count - 1; i++)
     {
      if(t >= m_positions[i] && t <= m_positions[i + 1])
        {
         const double span = m_positions[i + 1] - m_positions[i];

         //--- two stops at the same position are a legal way to ask
         //--- for a hard edge; the span is then zero and there is
         //--- nothing to interpolate across
         const double local = (span > 0.0)
                              ? (t - m_positions[i]) / span
                              : 0.0;

         return CairoLerp(m_colors[i], m_colors[i + 1], local);
        }
     }

   return m_colors[m_stop_count - 1];
  }

//+------------------------------------------------------------------+
//| CCairoLinearGradient - a gradient along an axis, given as an     |
//| ANGLE IN DEGREES over a bounding box:                            |
//|                                                                  |
//|     0    left to right                                           |
//|     90   top to bottom                                           |
//|     45   diagonal, top-left to bottom-right                      |
//|                                                                  |
//| The angle convention is the screen one from Part 7 - y grows     |
//| downward, so 90 degrees points DOWN.                             |
//|                                                                  |
//| THE NORMALIZATION IS THE PART WORTH READING.                     |
//|                                                                  |
//| The projection is normalized against the box's four corners, so  |
//| t spans 0..1 across the shape AT ANY ANGLE. Without it a         |
//| 45-degree gradient runs out of color before it reaches the far   |
//| corner, which is the usual reason a hand-rolled gradient looks   |
//| right on a square button and wrong on a wide panel.              |
//+------------------------------------------------------------------+
class CCairoLinearGradient : public CCairoGradientPaint
  {
private:
   double            m_x0, m_y0, m_w, m_h;     // the box, in buffer pixels
   double            m_cos, m_sin;             // the direction vector
   double            m_proj_min, m_proj_inv;   // the normalization

public:
                     CCairoLinearGradient();

   void              SetBounds(const double x, const double y,
                               const double w, const double h);
   void              SetAngle(const double degrees);

   virtual uint      ColorAt(const int x, const int y) override;
  };

//+------------------------------------------------------------------+
//| Constructor - the unit box, left to right.                       |
//+------------------------------------------------------------------+
CCairoLinearGradient::CCairoLinearGradient()
  {
   SetBounds(0.0, 0.0, 1.0, 1.0);
   SetAngle(0.0);
  }

//+------------------------------------------------------------------+
//| Set the box the gradient spans. A zero extent is coerced to 1,   |
//| because ColorAt divides by it once per pixel.                    |
//+------------------------------------------------------------------+
void CCairoLinearGradient::SetBounds(const double x, const double y,
                                     const double w, const double h)
  {
   m_x0 = x;
   m_y0 = y;
   m_w  = (w != 0.0) ? w : 1.0;
   m_h  = (h != 0.0) ? h : 1.0;
  }

//+------------------------------------------------------------------+
//| Set the direction, and recompute the normalization.              |
//|                                                                  |
//| Project the UNIT box onto the direction vector. The extremes of  |
//| a linear function over a convex region are always reached at its |
//| VERTICES, so the four corners are the whole story - and corner   |
//| (0,0) projects to 0 by definition, which leaves three.           |
//|                                                                  |
//| All of this runs ONCE per angle change rather than once per      |
//| pixel, which is why ColorAt below is three lines with no         |
//| division in it.                                                  |
//+------------------------------------------------------------------+
void CCairoLinearGradient::SetAngle(const double degrees)
  {
   const double rad = degrees * M_PI / 180.0;

   m_cos = MathCos(rad);
   m_sin = MathSin(rad);

   const double p1 = m_cos;            // corner (1,0)
   const double p2 = m_sin;            // corner (0,1)
   const double p3 = m_cos + m_sin;    // corner (1,1)

   double lo = 0.0;                    // corner (0,0)
   double hi = 0.0;

   lo = MathMin(lo, MathMin(p1, MathMin(p2, p3)));
   hi = MathMax(hi, MathMax(p1, MathMax(p2, p3)));

   const double range = hi - lo;

   m_proj_min = lo;
   m_proj_inv = (range != 0.0) ? 1.0 / range : 0.0;
  }

//+------------------------------------------------------------------+
//| Project the pixel onto the gradient axis and sample.             |
//|                                                                  |
//| Normalize the pixel into the box, dot it with the direction      |
//| vector, rescale into 0..1. No branches, and no division -        |
//| m_proj_inv is a reciprocal computed back in SetAngle.            |
//+------------------------------------------------------------------+
uint CCairoLinearGradient::ColorAt(const int x, const int y)
  {
   const double u = (x - m_x0) / m_w;
   const double v = (y - m_y0) / m_h;
   const double t = ((u * m_cos + v * m_sin) - m_proj_min) * m_proj_inv;

   return Sample(t);
  }

//+------------------------------------------------------------------+
//| CCairoRadialGradient - a gradient outward from a center.         |
//|                                                                  |
//| The center and the radius are given NORMALIZED (0..1) against    |
//| the bounds rather than in pixels, so a widget can be resized     |
//| without its gradient having to be rebuilt: a highlight at        |
//| (0.3, 0.3) with radius 0.5 looks identical at any size.          |
//|                                                                  |
//| That matters more than it sounds for a trading panel, where      |
//| windows are dragged and resized constantly.                      |
//+------------------------------------------------------------------+
class CCairoRadialGradient : public CCairoGradientPaint
  {
private:
   double            m_x0, m_y0, m_w, m_h;      // the box, in buffer pixels
   double            m_center_u, m_center_v;    // the center, 0..1 in that box
   double            m_inv_radius;              // 1 / radius, also 0..1

public:
                     CCairoRadialGradient();

   void              SetBounds(const double x, const double y,
                               const double w, const double h);
   void              SetCenterNorm(const double u, const double v);
   void              SetRadiusNorm(const double r);

   virtual uint      ColorAt(const int x, const int y) override;
  };

//+------------------------------------------------------------------+
//| Constructor - centered, radius 0.5, so the gradient just touches |
//| the edges of its box.                                            |
//+------------------------------------------------------------------+
CCairoRadialGradient::CCairoRadialGradient()
  {
   SetBounds(0.0, 0.0, 1.0, 1.0);
   SetCenterNorm(0.5, 0.5);
   SetRadiusNorm(0.5);
  }

//+------------------------------------------------------------------+
//| Set the box, with the same guard the linear gradient uses.       |
//+------------------------------------------------------------------+
void CCairoRadialGradient::SetBounds(const double x, const double y,
                                     const double w, const double h)
  {
   m_x0 = x;
   m_y0 = y;
   m_w  = (w != 0.0) ? w : 1.0;
   m_h  = (h != 0.0) ? h : 1.0;
  }

//+------------------------------------------------------------------+
//| Where the gradient starts, as a fraction of the box.             |
//+------------------------------------------------------------------+
void CCairoRadialGradient::SetCenterNorm(const double u, const double v)
  {
   m_center_u = u;
   m_center_v = v;
  }

//+------------------------------------------------------------------+
//| Store the RECIPROCAL of the radius, so that ColorAt multiplies   |
//| instead of dividing once per pixel. A zero radius would be a     |
//| division by zero, so it is floored to something tiny - the       |
//| gradient then reads as its last stop everywhere, which is a      |
//| flat shape rather than a NaN.                                    |
//+------------------------------------------------------------------+
void CCairoRadialGradient::SetRadiusNorm(const double r)
  {
   m_inv_radius = 1.0 / ((r > 0.0) ? r : 1e-9);
  }

//+------------------------------------------------------------------+
//| Distance from the center, divided by the radius.                 |
//|                                                                  |
//| The distance is measured in the box's NORMALIZED space, so in a  |
//| wide, short box the gradient is ELLIPTICAL - it follows the      |
//| shape. That is almost always what a designer means by a          |
//| "highlight", and it is why the bounds are used here rather than  |
//| raw pixel distance.                                              |
//+------------------------------------------------------------------+
uint CCairoRadialGradient::ColorAt(const int x, const int y)
  {
   const double u  = (x - m_x0) / m_w;
   const double v  = (y - m_y0) / m_h;
   const double du = u - m_center_u;
   const double dv = v - m_center_v;
   const double t  = MathSqrt(du * du + dv * dv) * m_inv_radius;

   return Sample(t);
  }

//+------------------------------------------------------------------+
//| CCairoFillStyle - one handle answering "how is this shape        |
//| filled?".                                                        |
//|                                                                  |
//| Without it, a widget that supports both flat colors and          |
//| gradients has to hold a pointer, remember which kind it is, and  |
//| free the old one on every change. This class does that once, so  |
//| that thirty widget classes do not each do it badly.              |
//|                                                                  |
//| Typical use:                                                     |
//|                                                                  |
//|     CCairoFillStyle style;                                       |
//|     style.Solid( CairoRgb( 40, 90, 160 ) );                      |
//|                                                                  |
//|     CCairoLinearGradient *g = style.Linear();                    |
//|     g.SetAngle( 90 );                                            |
//|     g.AddStop( 0.0, top_color );                                 |
//|     g.AddStop( 1.0, bottom_color );                              |
//|                                                                  |
//|     ras.Fill( path, style.Paint( x, y, w, h ), px, W, H );       |
//+------------------------------------------------------------------+
class CCairoFillStyle
  {
private:
   ENUM_CAIRO_FILL       m_type;
   CCairoSolidPaint      m_solid;   // by value: always needed, never freed
   CCairoLinearGradient *m_linear;  // by pointer: usually absent
   CCairoRadialGradient *m_radial;

   void              FreeGradients();

public:
                     CCairoFillStyle();
                    ~CCairoFillStyle();

   //--- kind selection
   void              None();
   void              Solid(const uint argb);

   //--- return the gradient, so the caller can set stops and an angle
   CCairoLinearGradient *Linear();
   CCairoRadialGradient *Radial();

   //--- queries
   bool              IsNone() const;
   ENUM_CAIRO_FILL   Type() const;
   uint              SolidColor() const;

   //--- recolor a solid fill without reallocating anything
   void              SetSolidColor(const uint argb);

   //--- bind the gradient bounds to the shape, and hand the paint over
   CCairoPaint       *Paint(const int ax, const int ay,
                            const int w, const int h);
  };

//+------------------------------------------------------------------+
//| Constructor - solid black until told otherwise.                  |
//+------------------------------------------------------------------+
CCairoFillStyle::CCairoFillStyle()
  {
   m_type   = CAIRO_FILL_SOLID;
   m_linear = NULL;
   m_radial = NULL;

   m_solid.SetColor((uint)0xFF000000);
  }

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CCairoFillStyle::~CCairoFillStyle()
  {
   FreeGradients();
  }

//+------------------------------------------------------------------+
//| Release whatever gradient this style owns.                       |
//|                                                                  |
//| Called on EVERY kind change, which is what makes it safe for a   |
//| widget to go solid -> gradient -> solid across a theme switch    |
//| without leaking a single object.                                 |
//+------------------------------------------------------------------+
void CCairoFillStyle::FreeGradients()
  {
   if(m_linear != NULL)
     {
      delete m_linear;
      m_linear = NULL;
     }

   if(m_radial != NULL)
     {
      delete m_radial;
      m_radial = NULL;
     }
  }

//+------------------------------------------------------------------+
//| Draw nothing at all.                                             |
//|                                                                  |
//| Paint() then returns NULL and the rasterizer skips the fill      |
//| entirely - no scan, no edges, no rows. This is how an outlined   |
//| widget with no background is expressed, and it is cheaper than   |
//| filling with a fully transparent color, which would still walk   |
//| every pixel of the shape to achieve nothing.                     |
//+------------------------------------------------------------------+
void CCairoFillStyle::None()
  {
   FreeGradients();
   m_type = CAIRO_FILL_NONE;
  }

//+------------------------------------------------------------------+
//| Switch to a solid color.                                         |
//+------------------------------------------------------------------+
void CCairoFillStyle::Solid(const uint argb)
  {
   FreeGradients();
   m_type = CAIRO_FILL_SOLID;
   m_solid.SetColor(argb);
  }

//+------------------------------------------------------------------+
//| Switch to a linear gradient and return it for configuration.     |
//| The style owns the object; the caller only borrows the pointer.  |
//+------------------------------------------------------------------+
CCairoLinearGradient *CCairoFillStyle::Linear()
  {
   FreeGradients();
   m_linear = new CCairoLinearGradient();

//--- a refused allocation becomes "no fill" rather than a kind whose
//--- object does not exist. The caller still has to check the
//--- pointer before configuring it.
   m_type = (m_linear != NULL) ? CAIRO_FILL_LINEAR : CAIRO_FILL_NONE;

   return m_linear;
  }

//+------------------------------------------------------------------+
//| Switch to a radial gradient and return it for configuration.     |
//+------------------------------------------------------------------+
CCairoRadialGradient *CCairoFillStyle::Radial()
  {
   FreeGradients();
   m_radial = new CCairoRadialGradient();

//--- same contract as Linear() above
   m_type = (m_radial != NULL) ? CAIRO_FILL_RADIAL : CAIRO_FILL_NONE;

   return m_radial;
  }

//+------------------------------------------------------------------+
//| Queries.                                                         |
//+------------------------------------------------------------------+
bool CCairoFillStyle::IsNone() const
  {
   return (m_type == CAIRO_FILL_NONE);
  }

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
ENUM_CAIRO_FILL CCairoFillStyle::Type() const
  {
   return m_type;
  }

//+------------------------------------------------------------------+
//| The current solid color. Meaningless for a gradient, so check    |
//| Type() first.                                                    |
//|                                                                  |
//| It exists so a caller can ask "is this already the color I       |
//| want?" and skip an entire repaint - which is worth more than any |
//| micro-optimization inside the rasterizer when a tick handler     |
//| runs many times a second.                                        |
//+------------------------------------------------------------------+
uint CCairoFillStyle::SolidColor() const
  {
   return m_solid.GetColor();
  }

//+------------------------------------------------------------------+
//| Recolor a solid fill in place. Ignored for gradients, which have |
//| to be rebuilt through Linear() or Radial().                      |
//+------------------------------------------------------------------+
void CCairoFillStyle::SetSolidColor(const uint argb)
  {
   if(m_type == CAIRO_FILL_SOLID)
      m_solid.SetColor(argb);
  }

//+------------------------------------------------------------------+
//| Bind the gradient bounds to the shape's rectangle, and return    |
//| the paint to hand to the rasterizer.                             |
//|                                                                  |
//| The bounds are set HERE, at draw time, rather than at            |
//| configuration time. That is the point of the class: a widget can |
//| be moved or resized without anyone remembering to touch its      |
//| gradient. Forgetting to update gradient bounds after a resize is |
//| otherwise a common and very confusing bug - the shape moves and  |
//| the colors stay behind.                                          |
//+------------------------------------------------------------------+
CCairoPaint *CCairoFillStyle::Paint(const int ax, const int ay,
                                    const int w, const int h)
  {
   if(m_type == CAIRO_FILL_SOLID)
      return GetPointer(m_solid);

   if(m_type == CAIRO_FILL_LINEAR)
     {
      m_linear.SetBounds(ax, ay, w, h);
      return m_linear;
     }

   if(m_type == CAIRO_FILL_RADIAL)
     {
      m_radial.SetBounds(ax, ay, w, h);
      return m_radial;
     }

   return NULL;
  }

#endif // CAIRO5_PAINT_MQH
