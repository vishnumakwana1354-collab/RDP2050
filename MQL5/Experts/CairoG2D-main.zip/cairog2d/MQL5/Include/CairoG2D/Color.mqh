//+-------------------------------------------------------------------+
//|                                                        Color.mqh  |
//|                              Copyright 2026, Sandro Begashvili    |
//|                   https://www.mql5.com/en/users/sandrobegashvil   |
//|                          Telegram: https://t.me/MrMQL5Developer   |
//|                    Cairo5 - 2D vector engine - PART 4 snapshot    |
//|                                                                   |
//|  ONE color representation for the whole engine:                   |
//|                                                                   |
//|      uint  0xAARRGGBB                                             |
//|                                                                   |
//|  This is exactly what ColorToARGB() returns and exactly the pixel |
//|  layout ResourceCreate() expects with                             |
//|  COLOR_FORMAT_ARGB_NORMALIZE, so a pixel never has to be          |
//|  converted between our renderer and the chart.                    |
//|                                                                   |
//|  WHY NOT the MQL5 `color` type -----------------------------      |
//|  MQL5's `color` is 0x00BBGGRR - blue, green, red, and no alpha at |
//|  all. Mixing it with ARGB is the classic way to silently swap red |
//|  and blue in a GUI.                                               |
//|                                                                   |
//|  The rule in this library: a color is ALWAYS a uint ARGB. `color` |
//|  is accepted only at the boundary, through CairoFromMql().        |
//|                                                                   |
//|  PART 4 ADDS COMPOSITING CairoBlendOver, at the bottom of this    |
//|  file, puts a translucent color ON TOP of pixels that are already |
//|  there. It is also, and not by coincidence, what turns a partial  |
//|  coverage value into a smooth edge - a half-covered pixel and a   |
//|  half-transparent color are the same problem, so they get the     |
//|  same function.                                                   |
//+-------------------------------------------------------------------+
#ifndef CAIRO5_COLOR_MQH
#define CAIRO5_COLOR_MQH

//--- A fully transparent color.
#define CAIRO_TRANSPARENT ((uint)0x00000000)

//+-------------------------------------------------------------------+
//| Channel accessors.                                                |
//|                                                                   |
//| Deliberately macros, not functions: from Part 4 onwards they sit  |
//| in the innermost loop of the rasterizer, executed once per        |
//| composited pixel, and must not pay for a function call.           |
//+-------------------------------------------------------------------+
#define CAIRO_A(c) (((uint)(c) >> 24) & 0xFF)
#define CAIRO_R(c) (((uint)(c) >> 16) & 0xFF)
#define CAIRO_G(c) (((uint)(c) >>  8) & 0xFF)
#define CAIRO_B(c) (((uint)(c)      ) & 0xFF)

//+-------------------------------------------------------------------+
//| Free functions - declarations                                     |
//+-------------------------------------------------------------------+
uint  CairoArgb(const uint a, const uint r, const uint g, const uint b);
uint  CairoRgb(const uint r, const uint g, const uint b);
uint  CairoHex(const uint bgr, const uint alpha = 0xFF);
uint  CairoFromMql(const color clr, const uint alpha = 255);
color CairoToMql(const uint argb);
uint  CairoWithAlpha(const uint argb, const uint alpha);
uint  CairoWithOpacity(const uint argb, const double opacity);
uint  CairoLerp(const uint from, const uint to, const double t);
uint  CairoBlendOver(const uint dst, const uint src,
                     const double coverage);

//+-------------------------------------------------------------------+
//| Pack a, r, g, b (each 0..255) into 0xAARRGGBB.                    |
//+-------------------------------------------------------------------+
uint CairoArgb(const uint a, const uint r, const uint g, const uint b)
  {
   return ((a & 0xFF) << 24) |
          ((r & 0xFF) << 16) |
          ((g & 0xFF) <<  8) |
          (b & 0xFF);
  }

//+-------------------------------------------------------------------+
//| Pack r, g, b as fully opaque. The everyday constructor.           |
//+-------------------------------------------------------------------+
uint CairoRgb(const uint r, const uint g, const uint b)
  {
   return CairoArgb(255, r, g, b);
  }

//+-------------------------------------------------------------------+
//| Take a literal written in MQL5 `color` (BGR) order plus an alpha, |
//| and return the library's 0xAARRGGBB.                              |
//|                                                                   |
//| Why this exists: MetaEditor decorates every 0x literal with a     |
//| color swatch, interpreting it as an MQL5 `color`, i.e.            |
//| 0x00BBGGRR. If you write the value in THAT order, the swatch in   |
//| the editor shows the true color, and CairoHex swaps the bytes     |
//| back to RGB for you:                                              |
//|                                                                   |
//|     CairoHex( 0x0000FF )          // swatch shows red   -> red    |
//|     CairoHex( 0xFF0000 )          // swatch shows blue  -> blue   |
//|     CairoHex( 0xF6823B, 0x33 )    // same color at 20% alpha      |
//|                                                                   |
//| So you can pick colors by eye in the editor and still store       |
//| correct ARGB.                                                     |
//+-------------------------------------------------------------------+
uint CairoHex(const uint bgr, const uint alpha = 0xFF)
  {
   const uint r = (bgr) & 0xFF;
   const uint g = (bgr >>  8) & 0xFF;
   const uint b = (bgr >> 16) & 0xFF;

   return CairoArgb(alpha, r, g, b);
  }

//+-------------------------------------------------------------------+
//| Boundary conversion: MQL5 `color` (BGR) -> ARGB. Use this for     |
//| anything arriving from an `input color` parameter.                |
//+-------------------------------------------------------------------+
uint CairoFromMql(const color clr, const uint alpha = 255)
  {
//--- ColorToARGB already performs the BGR -> RGB swap for us
   return ((alpha & 0xFF) << 24) | (ColorToARGB(clr, 255) & 0x00FFFFFF);
  }

//+-------------------------------------------------------------------+
//| Boundary conversion: ARGB -> MQL5 `color` (BGR). Alpha is lost.   |
//| Only needed when feeding a native chart object, which cannot      |
//| express alpha at all.                                             |
//+-------------------------------------------------------------------+
color CairoToMql(const uint argb)
  {
   return (color)((CAIRO_B(argb) << 16) |
                  (CAIRO_G(argb) <<  8) |
                  CAIRO_R(argb));
  }

//+-------------------------------------------------------------------+
//| Replace the alpha channel, keep the RGB.                          |
//+-------------------------------------------------------------------+
uint CairoWithAlpha(const uint argb, const uint alpha)
  {
   return (argb & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
  }

//+-------------------------------------------------------------------+
//| Scale the EXISTING alpha by `opacity` (0.0 .. 1.0).               |
//|                                                                   |
//| Multiplicative rather than absolute, so a global "fade this whole |
//| panel to 50%" composes correctly with a color that is already     |
//| semi-transparent, instead of making it MORE opaque.               |
//+-------------------------------------------------------------------+
uint CairoWithOpacity(const uint argb, const double opacity)
  {
   double o = opacity;

   if(o < 0.0)
      o = 0.0;
   if(o > 1.0)
      o = 1.0;

   const uint a = (uint)(CAIRO_A(argb) * o + 0.5);

   return CairoWithAlpha(argb, a);
  }

//+-------------------------------------------------------------------+
//| Linear interpolation between two colors, alpha included. t = 0    |
//| returns `from`, t = 1 returns `to`.                               |
//|                                                                   |
//| Every gradient in this library will eventually be built on this   |
//| one function. For now it is what lets us paint a smooth ramp into |
//| the buffer by hand.                                               |
//+-------------------------------------------------------------------+
uint CairoLerp(const uint from, const uint to, const double t)
  {
   double k = t;

   if(k < 0.0)
      k = 0.0;
   if(k > 1.0)
      k = 1.0;

   const uint a = (uint)(CAIRO_A(from) +
                         (CAIRO_A(to) - (double)CAIRO_A(from)) * k + 0.5);
   const uint r = (uint)(CAIRO_R(from) +
                         (CAIRO_R(to) - (double)CAIRO_R(from)) * k + 0.5);
   const uint g = (uint)(CAIRO_G(from) +
                         (CAIRO_G(to) - (double)CAIRO_G(from)) * k + 0.5);
   const uint b = (uint)(CAIRO_B(from) +
                         (CAIRO_B(to) - (double)CAIRO_B(from)) * k + 0.5);

   return CairoArgb(a, r, g, b);
  }

//+------------------------------------------------------------------+
//| CairoBlendOver - put `src` on top of `dst`, at `coverage`.       |
//|                                                                  |
//| This is the "over" operator, the one every compositing system is |
//| built on, written for STRAIGHT (non-premultiplied) ARGB because  |
//| that is the format ResourceCreate expects from us.               |
//|                                                                  |
//| Coverage folds straight into the source alpha, which is the      |
//| whole reason anti-aliasing needs no code of its own: a pixel     |
//| half covered by an opaque color and a pixel fully covered by a   |
//| half-transparent one are the same arithmetic.                    |
//+------------------------------------------------------------------+
uint CairoBlendOver(const uint dst, const uint src, const double coverage)
  {
//--- fold coverage straight into the source alpha
   const double sa = (CAIRO_A(src) / 255.0) * coverage;

//--- nothing to add: leave the destination exactly as it was
   if(sa <= 0.0)
      return dst;

   const double da = CAIRO_A(dst) / 255.0;
   const double ia = 1.0 - sa;
   const double oa = sa + da * ia;

//--- transparent over transparent stays transparent
   if(oa <= 0.0)
      return CAIRO_TRANSPARENT;

//--- weight each color by how much of the result it owns, then
//--- divide through the output alpha to get back to straight ARGB
   const double inv = 1.0 / oa;
   const double r   = (CAIRO_R(src) * sa + CAIRO_R(dst) * da * ia) * inv;
   const double g   = (CAIRO_G(src) * sa + CAIRO_G(dst) * da * ia) * inv;
   const double b   = (CAIRO_B(src) * sa + CAIRO_B(dst) * da * ia) * inv;

   return CairoArgb((uint)(oa * 255.0 + 0.5),
                    (uint)(r  + 0.5),
                    (uint)(g  + 0.5),
                    (uint)(b  + 0.5));
  }

#endif // CAIRO5_COLOR_MQH
