//+------------------------------------------------------------------+
//|                                                       Config.mqh |
//|                              Copyright 2026, Sandro Begashvili   |
//|                   https://www.mql5.com/en/users/sandrobegashvil  |
//|                          Telegram: https://t.me/MrMQL5Developer  |
//|                    Cairo5 - 2D vector engine - PART 4 code       |
//|                                                                  |
//|  Every tunable number in the engine lives here, and nowhere      |
//|  else. No other file is allowed to invent a magic constant.      |
//|                                                                  |
//|  These are ordinary globals rather than #define, because quality |
//|  is something an application legitimately changes AT RUNTIME:    |
//|  full quality for a panel that is drawn once and then sits       |
//|  there, draft quality while the user is dragging something with  |
//|  the mouse and forty frames a second matter more than a perfect  |
//|  edge.                                                           |
//+------------------------------------------------------------------+
#ifndef CAIRO5_CONFIG_MQH
#define CAIRO5_CONFIG_MQH

//--- library identity
#define CAIRO5_VERSION   "1.0"

//+------------------------------------------------------------------+
//| CairoAaSamples                                                   |
//|                                                                  |
//| The number of horizontal sample lines taken per pixel row.       |
//|                                                                  |
//| The rasterizer computes coverage ANALYTICALLY in X - exact       |
//| fractional overlap, no sampling at all - but SAMPLES in Y. This  |
//| value is therefore the VERTICAL anti-aliasing quality, and the   |
//| cost of a fill is very close to linear in it.                    |
//|                                                                  |
//|   1  no vertical AA. Vertical and horizontal edges are still     |
//|      perfect - they always were - but a shallow diagonal shows   |
//|      banding, because the shape's height within a row is being   |
//|      guessed from one sample.                                    |
//|   2  most of the improvement, for half the price of 4.           |
//|   4  the default, and the point of diminishing returns on screen.|
//|   8  visibly better only on near-horizontal edges of large       |
//|      shapes.                                                     |
//|  16  for rendering at high resolution for an export.             |
//|                                                                  |
//| Part 4's demo puts all four side by side and prints the timings, |
//| so you can pick from evidence rather than from this comment.     |
//+------------------------------------------------------------------+
int CairoAaSamples = 4;

//+------------------------------------------------------------------+
//| CairoFlattenTolerance                           (added in Part 6)|
//|                                                                  |
//| The maximum distance, IN PIXELS, that one straight segment may   |
//| deviate from the true curve it stands in for.                    |
//|                                                                  |
//| This single number decides how many segments a Bezier is broken  |
//| into, which makes it the quality dial for GEOMETRY. It is a      |
//| different concern from CairoAaSamples above, and the two are     |
//| confused constantly:                                             |
//|                                                                  |
//|   CairoFlattenTolerance  how faithful is the OUTLINE to the      |
//|                          mathematical curve?                     |
//|   CairoAaSamples         how smoothly is that outline PAINTED?   |
//|                                                                  |
//| A curve flattened at 0.30 px still gets perfectly smooth edges,  |
//| because the rasterizer anti-aliases whatever segments it is      |
//| handed and has no idea they came from a curve. So a large circle |
//| that looks FACETED needs this value lowered; a diagonal edge that|
//| looks STEPPED needs CairoAaSamples raised. Reaching for the wrong|
//| one is the usual mistake.                                        |
//|                                                                  |
//|   1.00  visibly faceted on a large circle, very fast             |
//|   0.30  the default - indistinguishable from a true curve at     |
//|         normal screen sizes                                      |
//|   0.05  overkill for a screen; useful when rendering at 4x for a |
//|         high-resolution export                                   |
//|                                                                  |
//| Expressing it in PIXELS rather than as a segment count is what   |
//| makes it scale-independent: a 4-pixel corner radius and a        |
//| 400-pixel circle each get the number of segments they actually   |
//| need, and neither number had to be guessed by a caller.          |
//+------------------------------------------------------------------+
double CairoFlattenTolerance = 0.30;

#endif // CAIRO5_CONFIG_MQH
