//+-------------------------------------------------------------------+
//|                                                     DemoTheme.mqh |
//|                              Copyright 2026, Sandro Begashvili    |
//|                   https://www.mql5.com/en/users/sandrobegashvil   |
//|                          Telegram: https://t.me/MrMQL5Developer   |
//|                                                                   |
//|  THE LIGHT DEMO TEMPLATE - shared by every demo in the series.    |
//|                                                                   |
//|  IMPORTANT: this file is NOT part of the Cairo G2D library. It    |
//|  does not add a single feature to the renderer. It exists only so |
//|  that every demo in the series looks the same on screen, and so   |
//|  that the screenshots in the articles are readable after the site |
//|  compresses them.                                                 |
//|                                                                   |
//|  It does three things:                                            |
//|                                                                   |
//|    1. ONE PALETTE. Light background, dark ink, and the trading    |
//|       colors everybody already knows: blue and green for good,    |
//|       red for bad, grey for "no data".                            |
//|                                                                   |
//|    2. ONE CHART SETUP. DemoUseLightChart() puts the chart into    |
//|       the standard Black-On-White scheme, hides the grid and the  |
//|       volumes, and gets the terminal out of the way. mql5.com     |
//|       asks for exactly this scheme in article screenshots.        |
//|                                                                   |
//|    3. CAPTIONS. Part 1 of the series has no text renderer - we    |
//|       have not written one yet - so the labels you see in the     |
//|       article figures are plain OBJ_LABEL objects placed next to  |
//|       the bitmap. They are annotation for the reader, not part of |
//|       the drawing. Switch them off and the panel is still exactly |
//|       ONE chart object.                                           |
//+-------------------------------------------------------------------+
#ifndef CAIRO5_DEMOTHEME_MQH
#define CAIRO5_DEMOTHEME_MQH

//+-------------------------------------------------------------------+
//| 1. THE PALETTE                                                    |
//|                                                                   |
//| Written as 0xAARRGGBB, the one color layout this library uses.    |
//| Roles, not names: when a demo wants "the color of a loss" it      |
//| asks for DEMO_RED, and every demo in the series then agrees on    |
//| what a loss looks like.                                           |
//+-------------------------------------------------------------------+
#define DEMO_BG        ((uint)0xFFFFFFFF)   // panel background, plain white
#define DEMO_PANEL     ((uint)0xFFF6F8FA)   // a card inside the panel
#define DEMO_BORDER    ((uint)0xFFC8CDD4)   // 1 px frames and separators
#define DEMO_INK       ((uint)0xFF1B1F24)   // headings and anything that reads
#define DEMO_INK_SOFT  ((uint)0xFF57606A)   // secondary labels
#define DEMO_BLUE      ((uint)0xFF1F6FEB)   // positive / buy / the main accent
#define DEMO_GREEN     ((uint)0xFF1A7F37)   // positive, when blue is taken
#define DEMO_RED       ((uint)0xFFCF222E)   // negative / sell / fail
#define DEMO_AMBER     ((uint)0xFFBF8700)   // warning, threshold
#define DEMO_GREY      ((uint)0xFF8C959F)   // no data, disabled, invalid

//--- the caption font, kept in one place so every figure matches
#define DEMO_FONT      "Segoe UI"
#define DEMO_FONT_SIZE 9
//--- Every caption object created here starts with this prefix, and
//--- DemoLabelsClear() deletes exactly the objects that carry it. The
//--- prefix is deliberately specific rather than something generic
//--- like "label_": a bulk delete by prefix removes ANY object whose
//--- name begins with it, including objects that belong to somebody
//--- else's indicator on the same chart.
#define DEMO_TAG       "g2d_demo_lbl_"

//+-------------------------------------------------------------------+
//| 2. THE CHART                                                      |
//|                                                                   |
//| Put the chart into the scheme the site asks for: white paper,     |
//| black ink, no grid, no volumes, no clutter. Call this once from   |
//| OnInit and the screenshot is already half composed.               |
//+-------------------------------------------------------------------+
void DemoUseLightChart(const long chart = 0)
  {
   ChartSetInteger(chart, CHART_COLOR_BACKGROUND,  clrWhite);
   ChartSetInteger(chart, CHART_COLOR_FOREGROUND,  clrBlack);
   ChartSetInteger(chart, CHART_COLOR_GRID,        clrWhite);
   ChartSetInteger(chart, CHART_COLOR_CHART_UP,    clrBlack);
   ChartSetInteger(chart, CHART_COLOR_CHART_DOWN,  clrBlack);
   ChartSetInteger(chart, CHART_COLOR_CHART_LINE,  clrBlack);
   ChartSetInteger(chart, CHART_COLOR_CANDLE_BULL, clrWhite);
   ChartSetInteger(chart, CHART_COLOR_CANDLE_BEAR, clrBlack);
   ChartSetInteger(chart, CHART_COLOR_BID,         clrWhite);
   ChartSetInteger(chart, CHART_COLOR_ASK,         clrWhite);
   ChartSetInteger(chart, CHART_COLOR_LAST,        clrWhite);
   ChartSetInteger(chart, CHART_COLOR_STOP_LEVEL,  clrWhite);

   ChartSetInteger(chart, CHART_SHOW_GRID,         false);
   ChartSetInteger(chart, CHART_SHOW_VOLUMES,      CHART_VOLUME_HIDE);
   ChartSetInteger(chart, CHART_SHOW_PERIOD_SEP,   false);
   ChartSetInteger(chart, CHART_SHOW_OBJECT_DESCR, false);
   ChartSetInteger(chart, CHART_SHOW_ONE_CLICK,    false);
   ChartSetInteger(chart, CHART_SHOW_TRADE_LEVELS, false);
  }

//+-------------------------------------------------------------------+
//| 3. CAPTIONS                                                       |
//|                                                                   |
//| One short English caption per region of the panel, so a reader    |
//| never has to match a shape to a paragraph. Positions are chart    |
//| pixels measured from the upper-left corner, the same coordinate   |
//| system the surface uses.                                          |
//+-------------------------------------------------------------------+
void DemoLabel(const string id, const int x, const int y, const string text,
               const uint argb = DEMO_INK, const int size = DEMO_FONT_SIZE,
               const long chart = 0)
  {
   const string name = DEMO_TAG + id;

   if(ObjectFind(chart, name) < 0)
      ObjectCreate(chart, name, OBJ_LABEL, 0, 0, 0);

//--- OBJ_LABEL takes an MQL5 `color`, which has no alpha channel,
//--- so we hand it the RGB part only
   const color clr = (color)(((argb) & 0xFF) << 16 |
                             ((argb >>  8) & 0xFF) <<  8 |
                             ((argb >> 16) & 0xFF));

   ObjectSetInteger(chart, name, OBJPROP_CORNER,     CORNER_LEFT_UPPER);
   ObjectSetInteger(chart, name, OBJPROP_ANCHOR,     ANCHOR_LEFT_UPPER);
   ObjectSetInteger(chart, name, OBJPROP_XDISTANCE,  x);
   ObjectSetInteger(chart, name, OBJPROP_YDISTANCE,  y);
   ObjectSetInteger(chart, name, OBJPROP_COLOR,      clr);
   ObjectSetInteger(chart, name, OBJPROP_FONTSIZE,   size);
   ObjectSetInteger(chart, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(chart, name, OBJPROP_HIDDEN,     true);
   ObjectSetString(chart, name, OBJPROP_FONT,       DEMO_FONT);
   ObjectSetString(chart, name, OBJPROP_TEXT,       text);
  }

//+-------------------------------------------------------------------+
//| Remove every caption this file created.                           |
//|                                                                   |
//| ObjectsDeleteAll has two forms. The one taking a chart id and a   |
//| STRING selects by name prefix; the one taking a chart id and an   |
//| INT selects by subwindow. DEMO_TAG is a string, so the prefix     |
//| form is the one chosen here, and the sub-window and type filters  |
//| are passed explicitly so the call cannot be misread:              |
//|                                                                   |
//|     -1 = every subwindow,  -1 = every object type                 |
//|                                                                   |
//| What makes this safe is not the signature but the prefix: it      |
//| matches only names this file writes.                              |
//+-------------------------------------------------------------------+
void DemoLabelsClear(const long chart = 0)
  {
   ObjectsDeleteAll(chart, DEMO_TAG, -1, -1);
  }

#endif // CAIRO5_DEMOTHEME_MQH
