//+------------------------------------------------------------------+
//|                                                       Raster.mqh |
//|                              Copyright 2026, Sandro Begashvili   |
//|                   https://www.mql5.com/en/users/sandrobegashvil  |
//|                          Telegram: https://t.me/MrMQL5Developer  |
//|                    Cairo5 - 2D vector engine - PART 4 code       |
//|                                                                  |
//|  THE SCAN CONVERTER - second version, with coverage.             |
//|                                                                  |
//|  Part 3 asked a yes/no question:                                 |
//|                                                                  |
//|      "is this pixel's center inside the shape?"                  |
//|                                                                  |
//|  The answer was 0 or 1, and every diagonal came out as a         |
//|  staircase. This version asks a quantitative one:                |
//|                                                                  |
//|      "what FRACTION of this pixel is inside the shape?"          |
//|                                                                  |
//|  and gets an answer between 0 and 1 - the COVERAGE. That number  |
//|  is then handed to CairoBlendOver, which mixes the color into    |
//|  the buffer with exactly that much strength.                     |
//|                                                                  |
//|  HOW THE FRACTION IS COMPUTED                                    |
//|                                                                  |
//|    in X   ANALYTICALLY. A span from x = 10.3 to x = 13.6 gives   |
//|           column 10 exactly 0.7, columns 11 and 12 exactly 1.0,  |
//|           and column 13 exactly 0.6. No sampling, no estimate -  |
//|           real area, from two subtractions.                      |
//|                                                                  |
//|    in Y   BY SAMPLING. The row is cut into CairoAaSamples        |
//|           horizontal slices, each contributing 1/N of the total. |
//|                                                                  |
//|  That asymmetry is deliberate. Exact area in BOTH axes needs a   |
//|  considerably more elaborate algorithm, costs more, and at       |
//|  screen resolution is indistinguishable from four samples in Y.  |
//|                                                                  |
//|  THE STRUCTURE IS UNCHANGED FROM PART 3                          |
//|                                                                  |
//|  Still: bounding box, walk rows, find crossings, sort them,      |
//|  sweep with the winding number. Only two things differ - spans   |
//|  accumulate into a coverage array instead of being painted       |
//|  directly, and the row is sampled N times instead of once.       |
//|                                                                  |
//|  The winding number was already being counted. Part 3 and Part 4 |
//|  asked one question of it - "is it non-zero?" Part 5 adds a      |
//|  second question - "is it odd?" - and lets the caller choose.    |
//|                                                                  |
//|    CAIRO_NONZERO   inside when the winding number is not zero.   |
//|                    Direction matters: contours wound the same    |
//|                    way merge, and a contour wound the other way  |
//|                    cuts a hole.                                  |
//|                                                                  |
//|    CAIRO_EVENODD   inside when the number of crossings is odd.   |
//|                    Direction is ignored, so any overlap becomes  |
//|                    a hole, whichever way it was wound.           |
//|                                                                  |
//|  That is the entire change to this file: one enum, one extra     |
//|  parameter with a default, and one line in the sweep. No new     |
//|  loop, no new array, no measurable cost.                         |
//|                                                                  |
//|  STILL TO COME                                                   |
//|    * curves, Parts 6 and 7                                       |
//|    * gradients, Part 8                                           |
//|                                                                  |
//|  CARRIED OVER FROM PART 3 AND PART 4, UNCHANGED                  |
//|                                                                  |
//|  path.IsValid() is still checked before a fill starts, and every |
//|  ArrayResize() in this file is still checked and refused rather  |
//|  than trusted. Coverage in X is still analytical and coverage in |
//|  Y is still sampled CairoAaSamples times.                        |
//+------------------------------------------------------------------+
#ifndef CAIRO5_RASTER_MQH
#define CAIRO5_RASTER_MQH

#include "Config.mqh"
#include "Path.mqh"
#include "Color.mqh"
#include "Paint.mqh"

//+------------------------------------------------------------------+
//| ENUM_CAIRO_FILLRULE - what the winding number MEANS.             |
//|                                                                  |
//| The rasterizer counts the same number either way. The rule only  |
//| decides how to read it, which is why adding a second rule costs  |
//| one comparison and nothing else.                                 |
//+------------------------------------------------------------------+
enum ENUM_CAIRO_FILLRULE
  {
   CAIRO_NONZERO = 0,      // inside when winding != 0 - the default
   CAIRO_EVENODD = 1       // inside when the crossing count is odd
  };

//+------------------------------------------------------------------+
//| CCairoRasterizer                                                 |
//|                                                                  |
//| KEEP ONE INSTANCE ALIVE AND REUSE IT. The scratch arrays are the |
//| entire reason this is a class. They are never shrunk, so after a |
//| few fills the rasterizer stops allocating memory completely.     |
//+------------------------------------------------------------------+
class CCairoRasterizer
  {
private:
   CCairoEdgeList    m_edges;        // edges of the path being filled
   double            m_coverage[];   // NEW: one accumulator per pixel column
   double            m_cross_x[];    // where this scanline crosses each edge
   int               m_cross_dir[];  // and in which direction

   //--- Part 8: the paint the uint overload wraps a color in. Held
   //--- by value and reused, so a solid fill still allocates nothing.
   CCairoSolidPaint  m_solid;

   bool              EnsureCapacity(const int width, const int edge_count);
   void              AddSpan(const double xa, const double xb, const double weight,
                             const int lo, const int hi);
   void              SortCrossings(const int n);

public:
                     CCairoRasterizer();
   //--- Part 8: the real Fill. The color arrives as an object that is
   //--- asked, per pixel, what it is - so a gradient needs no case here.
   //--- Part 9 adds the clip, LAST and defaulted to NULL, so that
   //--- every call written against Parts 3 to 8 still compiles and
   //--- still means what it meant. NULL is not a special case inside
   //--- the loop either - it is one pointer test per shape, not per
   //--- pixel.
   void              Fill(CCairoPath &path, CCairoPaint *paint, uint &buffer[],
                          const int width, const int height,
                          const ENUM_CAIRO_FILLRULE rule = CAIRO_NONZERO,
                          CCairoClip *clip = NULL);

   void              Fill(CCairoPath &path, const uint argb, uint &buffer[],
                          const int width, const int height,
                          const ENUM_CAIRO_FILLRULE rule = CAIRO_NONZERO,
                          CCairoClip *clip = NULL);

   //--- Part 9: narrow a clip to the inside of a path. The rasterizer
   //--- owns this rather than CCairoClip because turning a path into
   //--- coverage is what a rasterizer IS; the clip only stores the
   //--- answer.
   bool              ClipToPath(CCairoPath &path, CCairoClip &clip,
                                const ENUM_CAIRO_FILLRULE rule = CAIRO_NONZERO);
  };

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CCairoRasterizer::CCairoRasterizer()
  {
  }

//+------------------------------------------------------------------+
//| Grow the scratch arrays if needed. They are never shrunk.        |
//|                                                                  |
//| Checked, for the reason Part 2 and Part 3 check their own: if    |
//| the memory is refused and the code carries on regardless, the    |
//| sweep below writes past the end of an array instead of failing   |
//| where the mistake actually is.                                   |
//+------------------------------------------------------------------+
bool CCairoRasterizer::EnsureCapacity(const int width, const int edge_count)
  {
//--- the coverage accumulator needs one slot per pixel column
   if(ArraySize(m_coverage) < width)
      if(ArrayResize(m_coverage, width) < width)
         return false;

//--- Part 9 fixes an asymmetry here. Both crossing arrays are grown
//--- together, but only m_cross_x was TESTED - so a run where the
//--- first resize succeeded and the second one did not would skip
//--- both of them on every later call, and the sweep would then index
//--- m_cross_dir past its end. Testing both costs one comparison per
//--- fill and removes the only way the two arrays could disagree.
   if(ArraySize(m_cross_x)   < edge_count ||
      ArraySize(m_cross_dir) < edge_count)
     {
      if(ArrayResize(m_cross_x,   edge_count) < edge_count)
         return false;
      if(ArrayResize(m_cross_dir, edge_count) < edge_count)
         return false;
     }

   return true;
  }

//+------------------------------------------------------------------+
//| THE NEW FUNCTION, AND THE WHOLE POINT OF PART 4.                 |
//|                                                                  |
//| Accumulate coverage for the horizontal span [xa, xb).            |
//|                                                                  |
//| The span is a REAL-NUMBERED INTERVAL, not a range of pixels.     |
//| Part 3 rounded it to whole pixels and threw away everything the  |
//| geometry knew. Here, the first and last pixels a span touches    |
//| receive only the fraction they are actually covered by, while    |
//| every pixel fully inside receives the whole weight.              |
//|                                                                  |
//| Worked example, span 10.3 -> 13.6, weight 1.0:                   |
//|                                                                  |
//|     column 10 += 0.7      covered from 10.3 to 11.0              |
//|     column 11 += 1.0      fully covered                          |
//|     column 12 += 1.0      fully covered                          |
//|     column 13 += 0.6      covered from 13.0 to 13.6              |
//|                                                                  |
//| No sampling and no approximation anywhere in that - it is the    |
//| exact area, from two subtractions.                               |
//|                                                                  |
//| `weight` is 1 / CairoAaSamples, so the N sub-scanlines of one    |
//| row sum to at most 1.0.                                          |
//+------------------------------------------------------------------+
void CCairoRasterizer::AddSpan(const double xa, const double xb,
                               const double weight,
                               const int lo, const int hi)
  {
   double a = xa;
   double b = xb;

   if(b <= a)
      return;

//--- clip to the range of columns this shape can touch
   if(a < lo)
      a = lo;

   if(b > hi + 1)
      b = hi + 1;

   if(b <= a)
      return;

   const int ia = (int)MathFloor(a);

//--- THE EPSILON MATTERS. A span ending exactly on a pixel
//--- boundary, say at x = 14.0, covers NOTHING of column 14.
//--- Without the nudge, MathFloor(14.0) = 14 and we would add a
//--- zero-width contribution to a column the shape never reached
//--- - visible as a faint one-pixel fringe on every axis-aligned
//--- right-hand edge.
   const int ib = (int)MathFloor(b - 1e-9);

//--- the whole span lies inside a single pixel
   if(ia == ib)
     {
      m_coverage[ia] += weight * (b - a);
      return;
     }

   m_coverage[ia] += weight * ((ia + 1) - a);       // leading partial pixel

   for(int x = ia + 1; x < ib; x++)
      m_coverage[x] += weight;                     // fully covered interior

   m_coverage[ib] += weight * (b - ib);             // trailing partial pixel
  }

//+------------------------------------------------------------------+
//| Sort this scanline's crossings from left to right.               |
//|                                                                  |
//| Unchanged from Part 3. Insertion sort is correct here because    |
//| `n` is the number of edges crossing ONE horizontal line - two    |
//| for a triangle, four for a ring, rarely more than a dozen - and  |
//| because consecutive scanlines give nearly-sorted input.          |
//+------------------------------------------------------------------+
void CCairoRasterizer::SortCrossings(const int n)
  {
   for(int i = 1; i < n; i++)
     {
      const double key_x   = m_cross_x[i];
      const int    key_dir = m_cross_dir[i];

      int j = i - 1;

      while(j >= 0 && m_cross_x[j] > key_x)
        {
         m_cross_x[j + 1]   = m_cross_x[j];
         m_cross_dir[j + 1] = m_cross_dir[j];
         j--;
        }

      m_cross_x[j + 1]   = key_x;
      m_cross_dir[j + 1] = key_dir;
     }
  }


//+------------------------------------------------------------------+
//| Fill `path` into an ARGB buffer, taking its color from `paint`.  |
//|                                                                  |
//| The paint is a POINTER rather than a reference so that NULL can  |
//| mean "draw nothing".                                             |
//+------------------------------------------------------------------+
void CCairoRasterizer::Fill(CCairoPath &path, CCairoPaint *paint,
                            uint &buffer[],
                            const int width, const int height,
                            const ENUM_CAIRO_FILLRULE rule,
                            CCairoClip *clip)
  {
//--- a path that lost an allocation is not geometry we can trust
   if(!path.IsValid())
      return;

//--- Part 9 HARDENING. The buffer is the one argument this function
//--- cannot check from inside the loop. A width and height that do
//--- not match it would be discovered as an array-out-of-range in the
//--- innermost line of the compositing loop, which points the finger
//--- at the rasterizer rather than at the caller who got the size
//--- wrong. Three comparisons, once per fill.
   if(width <= 0 || height <= 0 || ArraySize(buffer) < width * height)
      return;

//--- a clip that allows nothing is the cheapest possible draw: no
//--- edges built, no rows walked, no pixels read
   if(clip != NULL && clip.IsEmpty())
      return;

   if(paint == NULL)
      return;

   path.BuildEdges(m_edges);

   const int edge_count = m_edges.m_count;

   if(edge_count == 0)
      return;

   if(!EnsureCapacity(width, edge_count))
      return;                        // no scratch room - draw nothing

//  BOUNDING BOX, now in BOTH axes.
//
//  Part 3 only needed the vertical extent, to know which rows to
//  walk. Now we also need the horizontal extent, because the
//  coverage accumulator has to be cleared before each row - and
//  clearing the whole buffer width for a 20-pixel-wide shape
//  would cost far more than drawing it.
//
//  An edge is a straight segment, so its x extremes are at its
//  two ends; there is no need to walk along it.
   double ymin =  1e18, ymax = -1e18;
   double xmin =  1e18, xmax = -1e18;

   for(int i = 0; i < edge_count; i++)
     {
      const double etop = m_edges.m_edges[i].ytop;
      const double ebot = m_edges.m_edges[i].ybot;

      if(etop < ymin)
         ymin = etop;
      if(ebot > ymax)
         ymax = ebot;

      const double xa = m_edges.m_edges[i].xtop;
      const double xb = m_edges.m_edges[i].XAt(ebot);

      if(xa < xmin)
         xmin = xa;
      if(xb < xmin)
         xmin = xb;
      if(xa > xmax)
         xmax = xa;
      if(xb > xmax)
         xmax = xb;
     }

   int iy0 = (int)MathFloor(ymin);
   int iy1 = (int)MathCeil(ymax);
   int ix0 = (int)MathFloor(xmin);
   int ix1 = (int)MathCeil(xmax);

   if(iy0 < 0)
      iy0 = 0;
   if(iy1 > height)
      iy1 = height;
   if(ix0 < 0)
      ix0 = 0;
   if(ix1 > width - 1)
      ix1 = width - 1;

//--- PART 9: AND NOW THE CLIP NARROWS IT TOO.
//---
//--- This is the half of clipping that costs nothing and saves a
//--- great deal. A row above the clip, or a column to the left of it,
//--- is going to come out of the multiplication below as zero for
//--- every one of its pixels - so the cheapest way to clip them is
//--- not to visit them. A list of two hundred rows scrolled so that
//--- three are visible builds edges for all of them and walks pixels
//--- for three.
   if(clip != NULL)
     {
      const int cl = clip.PixelLeft();
      const int ct = clip.PixelTop();
      const int cr = clip.PixelRight();
      const int cb = clip.PixelBottom();

      if(ix0 < cl)
         ix0 = cl;
      if(iy0 < ct)
         iy0 = ct;
      if(ix1 > cr)
         ix1 = cr;
      if(iy1 > cb)
         iy1 = cb;
     }

//--- entirely off the buffer, or entirely outside the clip
   if(ix1 < ix0 || iy1 <= iy0)
      return;

//  How finely do we sample the row vertically?
   int samples = CairoAaSamples;

   if(samples < 1)
      samples = 1;

   const double weight = 1.0 / samples;

//  WALK THE ROWS
   for(int iy = iy0; iy < iy1; iy++)
     {
      //--- clear only the columns this shape can possibly touch
      for(int x = ix0; x <= ix1; x++)
         m_coverage[x] = 0.0;

      //-------------------------------------------------------------
      //  N SUB-SCANLINES PER ROW.
      //
      //  Part 3 took one sample, at iy + 0.5. Now we take N, spread
      //  evenly through the row, each contributing 1/N of the
      //  coverage.
      //
      //  This is what fixes a NEAR-HORIZONTAL edge. Consider a line
      //  at a very shallow angle crossing a row: with one sample
      //  the row is either fully in or fully out, so the edge
      //  advances in whole-row jumps. With four, a row can be 25%,
      //  50% or 75% covered, and the jump is smoothed away.
      //-------------------------------------------------------------
      for(int s = 0; s < samples; s++)
        {
         //--- center of each sub-row, never its boundary
         const double yc = iy + (s + 0.5) / samples;

         int n = 0;

         for(int i = 0; i < edge_count; i++)
           {
            //--- half-open [ytop, ybot), exactly as in Part 3: a
            //--- vertex shared by two edges counts exactly once
            if(yc >= m_edges.m_edges[i].ytop &&
               yc <  m_edges.m_edges[i].ybot)
              {
               m_cross_x[n]   = m_edges.m_edges[i].XAt(yc);
               m_cross_dir[n] = m_edges.m_edges[i].dir;
               n++;
              }
           }

         if(n < 2)
            continue;

         SortCrossings(n);

         //--- sweep with the winding number, as before - but a span
         //--- is now ACCUMULATED rather than painted, and what the
         //--- winding number MEANS is now the caller's choice
         int winding = 0;

         for(int k = 0; k < n - 1; k++)
           {
            winding += m_cross_dir[k];

            //--- the fill rule, and the only line in this file
            //--- that Part 5 actually adds. (winding & 1) is a
            //--- valid parity test even though winding is a SIGNED
            //--- sum: every crossing adds +1 or -1, and both of
            //--- those flip the low bit, so the parity of the sum
            //--- equals the parity of the count.
            const bool inside = (rule == CAIRO_NONZERO)
                                ? (winding != 0)
                                : ((winding & 1) != 0);

            if(inside)
               AddSpan(m_cross_x[k], m_cross_x[k + 1],
                       weight, ix0, ix1);
           }
        }

      //-------------------------------------------------------------
      //  COMPOSITE THE FINISHED ROW.
      //
      //  Every column now holds a number from 0 to 1: how much of
      //  that pixel the shape covers. Hand it to CairoBlendOver and
      //  the anti-aliasing happens for free, because coverage and
      //  alpha are the same thing.
      //-------------------------------------------------------------
      const int row_base = iy * width;

      for(int x = ix0; x <= ix1; x++)
        {
         double a = m_coverage[x];

         //--- untouched pixel: leave the destination alone. This is
         //--- what stops a shape disturbing anything outside itself,
         //--- even within its own bounding box.
         if(a <= 0.0)
            continue;

         //--- Sub-spans that overlap within one sub-scanline can
         //--- push the sum slightly past 1.0 - a self-overlapping
         //--- path does exactly that. Clamp, rather than letting a
         //--- coverage of 1.3 brighten the pixel.
         if(a > 1.0)
            a = 1.0;

         //--- PART 9, AND THE WHOLE FEATURE IN ONE LINE.
         //---
         //--- Shape coverage says how much of this pixel the shape
         //--- reached. Clip coverage says how much of it drawing is
         //--- allowed to reach. A pixel half covered by the shape and
         //--- half allowed by the clip is a quarter painted - which
         //--- is a multiplication and nothing else, and which is why
         //--- a clip comes out anti-aliased without one line of code
         //--- here that mentions anti-aliasing.
         if(clip != NULL)
           {
            a *= clip.CoverageAt(x, iy);

            if(a <= 0.0)
               continue;
           }

         const int idx = row_base + x;

         //--- THE PART 8 LINE.
         //---
         //--- Until now this read `argb` - one color for the whole
         //--- shape. The paint is now asked what color belongs at
         //--- THIS pixel. A solid paint ignores the coordinates and
         //--- returns its color; a gradient computes one. The row
         //--- loop cannot tell the difference and does not need to.
         buffer[idx] = CairoBlendOver(buffer[idx],
                                      paint.ColorAt(x, iy), a);
        }
     }
  }
//+------------------------------------------------------------------+
//| The flat-color form, kept so that every caller written against   |
//| Parts 3 to 7 still compiles.                                     |
//|                                                                  |
//| It is a wrapper, not a shortcut. There is no faster path through |
//| the rasterizer for a solid color, because there was never a      |
//| slower one: CCairoSolidPaint::ColorAt returns a member and is    |
//| the cheapest possible implementation of the contract.            |
//|                                                                  |
//| m_solid is a member rather than a local, so that the common case |
//| constructs nothing per fill.                                     |
//|                                                                  |
//+------------------------------------------------------------------+
void CCairoRasterizer::Fill(CCairoPath &path, const uint argb,
                            uint &buffer[],
                            const int width, const int height,
                            const ENUM_CAIRO_FILLRULE rule,
                            CCairoClip *clip)
  {
   m_solid.SetColor(argb);

   Fill(path, GetPointer(m_solid), buffer, width, height, rule, clip);
  }

//+-------------------------------------------------------------------+
//|  ClipToPath - narrow a clip to the inside of a path.              |
//|                                                                   |
//|  THIS IS Fill() WITH THE LAST LINE CHANGED, and that is the point |
//|  worth noticing. The bounding box, the sub-scanlines, the crossing|
//|  search, the insertion sort and the winding sweep are the same    |
//|  machinery doing the same job. The only difference is where the   |
//|  coverage goes: a fill sends it to CairoBlendOver and gets a      |
//|  picture, a clip sends it to the mask and gets a permission map.  |
//|                                                                   |
//|  The new mask holds old_coverage * path_coverage, which is why the|
//|  clip hands the old value over through PrevCoverageAt() instead of|
//|  letting this loop overwrite it in place. Clipping to a rounded   |
//|  panel and then to a circle inside it leaves exactly the lens     |
//|  where the two overlap, with both edges still smooth.             |
//|                                                                   |
//|  Returns false when nothing is left to draw into. That is a       |
//|  legitimate outcome rather than an error - a row scrolled fully   |
//|  out of its viewport clips to nothing, and every draw inside it   |
//|  then costs the one comparison at the top of Fill().              |
//+-------------------------------------------------------------------+
bool CCairoRasterizer::ClipToPath(CCairoPath &path, CCairoClip &clip,
                                  const ENUM_CAIRO_FILLRULE rule)
  {
//--- the same refusals Fill() opens with, for the same reason:
//--- geometry we cannot trust produces a clip we cannot trust, and
//--- the safe answer for a clip is to allow nothing
   if(!path.IsValid())
     {
      clip.SetEmpty();
      return false;
     }

   path.BuildEdges(m_edges);

   const int edge_count = m_edges.m_count;

   if(edge_count == 0)
     {
      clip.SetEmpty();
      return false;
     }

//--- The mask has to cover the path's own box, narrowed by whatever
//--- the clip already allowed. BeginIntersect() does that
//--- intersection, allocates the mask and reports back when the
//--- result is nothing at all.
   if(!clip.BeginIntersect(path.Bounds()))
      return false;

   const int ix0 = clip.PixelLeft();
   const int ix1 = clip.PixelRight();
   const int iy0 = clip.PixelTop();
   const int iy1 = clip.PixelBottom();

//--- The coverage accumulator is indexed by ABSOLUTE column, the same
//--- as in Fill(), so it has to reach the rightmost column the mask
//--- covers rather than merely be as wide as the mask.
   if(!EnsureCapacity(ix1 + 1, edge_count))
     {
      clip.EndIntersect();
      clip.SetEmpty();
      return false;
     }

   int samples = CairoAaSamples;

   if(samples < 1)
      samples = 1;

   const double weight = 1.0 / samples;

   for(int iy = iy0; iy < iy1; iy++)
     {
      for(int x = ix0; x <= ix1; x++)
         m_coverage[x] = 0.0;

      for(int s = 0; s < samples; s++)
        {
         const double yc = iy + (s + 0.5) / samples;

         int n = 0;

         for(int i = 0; i < edge_count; i++)
            if(yc >= m_edges.m_edges[i].ytop &&
               yc <  m_edges.m_edges[i].ybot)
              {
               m_cross_x[n]   = m_edges.m_edges[i].XAt(yc);
               m_cross_dir[n] = m_edges.m_edges[i].dir;
               n++;
              }

         if(n < 2)
            continue;

         SortCrossings(n);

         int winding = 0;

         for(int k = 0; k < n - 1; k++)
           {
            winding += m_cross_dir[k];

            const bool inside = (rule == CAIRO_NONZERO)
                                ? (winding != 0)
                                : ((winding & 1) != 0);

            if(inside)
               AddSpan(m_cross_x[k], m_cross_x[k + 1],
                       weight, ix0, ix1);
           }
        }

      //-------------------------------------------------------------
      //  THE ONE LOOP THAT IS NOT Fill().
      //
      //  A pixel the path never reached keeps the zero the mask was
      //  allocated with, and that is the right answer: outside the
      //  new path, nothing may be drawn. So this loop only has to
      //  write the pixels the path DID reach.
      //-------------------------------------------------------------
      for(int x = ix0; x <= ix1; x++)
        {
         double a = m_coverage[x];

         if(a <= 0.0)
            continue;

         if(a > 1.0)
            a = 1.0;

         clip.SetMaskValue(x, iy, clip.PrevCoverageAt(x, iy) * a);
        }
     }

   clip.EndIntersect();

   return !clip.IsEmpty();
  }

#endif // CAIRO5_RASTER_MQH
