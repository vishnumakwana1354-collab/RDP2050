//+------------------------------------------------------------------+
//|                                                Demo08_Paint.mq5  |
//|                              Copyright 2026, Sandro Begashvili   |
//|                   https://www.mql5.com/en/users/sandrobegashvil  |
//|                          Telegram: https://t.me/MrMQL5Developer  |
//|            Cairo-Style Graphics in MQL5 (Part 8) - the only demo |
//|                                                                  |
//|  ONE VIRTUAL METHOD, AND EVERY SHAPE GAINS GRADIENTS.            |
//|                                                                  |
//|  The library is six files after this part. The new one,          |
//|  Paint.mqh, holds the SOURCE half of Part 1's Cairo model: an    |
//|  object that answers "what color is at (x, y)?".                 |
//|                                                                  |
//|  Panels:                                                         |
//|                                                                  |
//|    A. one SHAPE, three paints - only the object passed to Fill   |
//|       is different                                               |
//|    B. one PAINT, three shapes - the point of the whole article   |
//|    C. linear gradients at eight angles, all reaching full color  |
//|       in the far corner                                          |
//|    D. multi-stop ramps, and alpha stops over a checkerboard      |
//|    E. radial gradients: center, radius, glow, elliptical bounds  |
//|    F. CCairoFillStyle switching kind behind one handle           |
//|    G. what it is all for - a card with a gradient header, a      |
//|       fading area chart, a glowing dot and gradient bars         |
//|                                                                  |
//|  Nothing in Path.mqh changed to make any of this work, and the   |
//|  scanline loop changed by one line.                              |
//|                                                                  |
//|  Attach to any chart. Everything is removed again on deinit.     |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Sandro Begashvili"
#property link      "https://www.mql5.com/en/users/sandrobegashvil"
#property description "Part 8: paint sources - solid colors, linear and radial gradients"
#property description "Free to use and extend - please credit the author on mql5.com"
#property version   "1.00"
#property strict

#include <CairoG2D/Config.mqh>
#include <CairoG2D/Color.mqh>
#include <CairoG2D/Path.mqh>
#include <CairoG2D/Paint.mqh>
#include <CairoG2D/Raster.mqh>
#include <CairoG2D/Surface.mqh>
#include <CairoG2D/DemoTheme.mqh>

#define UI_X      10
#define UI_Y      20
#define UI_W     980
#define UI_H     880

//--- every color is a role from the shared light theme
#define C_BACK    DEMO_BG
#define C_CARD    DEMO_PANEL
#define C_LINE    DEMO_BORDER
#define C_INK     DEMO_INK
#define C_BLUE    DEMO_BLUE
#define C_GREEN   DEMO_GREEN
#define C_AMBER   DEMO_AMBER
#define C_RED     DEMO_RED
#define C_DEEP    DEMO_INK_SOFT
#define C_MUTED   DEMO_GREY

//--- captions are annotation for the article figures, not drawing.
//--- Turn them off and the panel is still exactly one chart object.
input bool InpShowCaptions  = true;   // Draw the explanatory captions
input bool InpSetLightChart = true;   // Switch the chart to Black On White

CCairoSurface    g_surface;
CCairoRasterizer g_ras;

//+------------------------------------------------------------------+
//| Shorthand fills.                                                 |
//|                                                                  |
//| Two overloads, mirroring the two the rasterizer now has. The     |
//| uint one is not a shortcut past anything - it ends up in the     |
//| same scanline loop, with a CCairoSolidPaint answering the same   |
//| question a gradient would.                                       |
//+------------------------------------------------------------------+
void Fill(CCairoPath &p, CCairoPaint *paint,
          const ENUM_CAIRO_FILLRULE rule = CAIRO_NONZERO)
  {
   g_ras.Fill(p, paint, g_surface.m_px,
              g_surface.Width(), g_surface.Height(), rule);
  }

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void Fill(CCairoPath &p, const uint argb,
          const ENUM_CAIRO_FILLRULE rule = CAIRO_NONZERO)
  {
   g_ras.Fill(p, argb, g_surface.m_px,
              g_surface.Width(), g_surface.Height(), rule);
  }

//+------------------------------------------------------------------+
//| A tint of a theme color, so the light panels stay light.         |
//|                                                                  |
//| CairoLerp is Part 1's, and mixing toward the white background is |
//| how a strong accent becomes a background wash without a second   |
//| palette having to be invented for it.                            |
//+------------------------------------------------------------------+
uint Tint(const uint argb, const double t)
  {
   return CairoLerp(DEMO_BG, argb, t);
  }

//+------------------------------------------------------------------+
//| A rounded rectangle with a true ring border - Part 7's helper,   |
//| unchanged, because nothing about borders changed today.          |
//+------------------------------------------------------------------+
void RoundRectBordered(const double x, const double y,
                       const double w, const double h,
                       const double r,
                       const uint fill_argb, const uint border_argb,
                       const double bw = 1.0)
  {
   if(CAIRO_A(fill_argb) > 0)
     {
      CCairoPath body;
      body.AddRoundRect(x, y, w, h, r);
      Fill(body, fill_argb);
     }

   CCairoPath edge;
   edge.AddRoundRect(x, y, w, h, r);
   edge.AddRoundRect(x + bw, y + bw, w - bw * 2, h - bw * 2,
                     MathMax(0.0, r - bw));
   Fill(edge, border_argb, CAIRO_EVENODD);
  }

//+------------------------------------------------------------------+
//| A grouping card.                                                 |
//+------------------------------------------------------------------+
void Card(const double x, const double y, const double w, const double h)
  {
   RoundRectBordered(x, y, w, h, 10, C_CARD, C_LINE, 1.0);
  }

//+------------------------------------------------------------------+
//| A five-pointed star, so that panel B has a shape which is not a  |
//| rectangle and not a circle.                                      |
//+------------------------------------------------------------------+
void AddStar(CCairoPath &p, const double cx, const double cy,
             const double r_out, const double r_in)
  {
   double xs[10], ys[10];

   for(int i = 0; i < 10; i++)
     {
      const double r = (i % 2 == 0) ? r_out : r_in;
      const double a = -M_PI * 0.5 + M_PI * i / 5.0;

      xs[i] = cx + r * MathCos(a);
      ys[i] = cy + r * MathSin(a);
     }

   p.AddPolygon(xs, ys, 10);
  }

//+------------------------------------------------------------------+
//| A. ONE SHAPE, THREE PAINTS                                       |
//|                                                                  |
//| The identical rounded rectangle, filled three times. The path is |
//| rebuilt at a new position each time, but the geometry call is    |
//| the same call with the same numbers - only the object handed to  |
//| Fill() differs.                                                  |
//+------------------------------------------------------------------+
void PanelOneShape(const double ox, const double oy)
  {
   Card(ox, oy, 440, 170);

//--- solid: a paint that ignores the pixel it is asked about
   CCairoPath a;
   a.AddRoundRect(ox + 26, oy + 34, 120, 120, 12);

   CCairoSolidPaint solid(C_BLUE);
   Fill(a, GetPointer(solid));

//--- linear: top to bottom, which is 90 degrees in screen angles
   CCairoPath b;
   b.AddRoundRect(ox + 162, oy + 34, 120, 120, 12);

   CCairoLinearGradient lin;
   lin.SetBounds(ox + 162, oy + 34, 120, 120);
   lin.SetAngle(90);
   lin.AddStop(0.0, C_BLUE);
   lin.AddStop(1.0, C_GREEN);
   Fill(b, GetPointer(lin));

//--- radial: an off-center highlight, the way a glossy control
//--- is shaded
   CCairoPath c;
   c.AddRoundRect(ox + 298, oy + 34, 120, 120, 12);

   CCairoRadialGradient rad;
   rad.SetBounds(ox + 298, oy + 34, 120, 120);
   rad.SetCenterNorm(0.35, 0.28);
   rad.SetRadiusNorm(0.80);
   rad.AddStop(0.0, Tint(C_BLUE, 0.12));
   rad.AddStop(1.0, C_BLUE);
   Fill(c, GetPointer(rad));
  }

//+------------------------------------------------------------------+
//| B. ONE PAINT, THREE SHAPES                                       |
//|                                                                  |
//| THE POINT OF THE WHOLE ARTICLE.                                  |
//|                                                                  |
//| A single gradient object fills a rounded rectangle, a star and a |
//| ring. The paint has no idea what it is filling; the shapes have  |
//| no idea what is filling them. The ring is the same even-odd      |
//| construction Part 5 introduced, and it needed no adjustment at   |
//| all to take a gradient.                                          |
//+------------------------------------------------------------------+
void PanelOnePaint(const double ox, const double oy)
  {
   Card(ox, oy, 440, 170);

   CCairoLinearGradient grad;
   grad.SetAngle(45);
   grad.AddStop(0.0, C_AMBER);
   grad.AddStop(0.5, C_RED);
   grad.AddStop(1.0, C_DEEP);

//--- rounded rectangle
   CCairoPath a;
   a.AddRoundRect(ox + 26, oy + 44, 116, 116, 16);
   grad.SetBounds(ox + 26, oy + 44, 116, 116);
   Fill(a, GetPointer(grad));

//--- star
   CCairoPath b;
   AddStar(b, ox + 216, oy + 102, 58, 24);
   grad.SetBounds(ox + 158, oy + 44, 116, 116);
   Fill(b, GetPointer(grad));

//--- ring, via the even-odd rule
   CCairoPath c;
   c.AddCircle(ox + 356, oy + 102, 58);
   c.AddCircle(ox + 356, oy + 102, 34);
   grad.SetBounds(ox + 298, oy + 44, 116, 116);
   Fill(c, GetPointer(grad), CAIRO_EVENODD);
  }

//+------------------------------------------------------------------+
//| C. EIGHT ANGLES                                                  |
//|                                                                  |
//| 0 to 315 degrees, in steps of 45.                                |
//|                                                                  |
//| Because SetAngle normalizes the projection against the box       |
//| CORNERS, t spans 0..1 across the tile at every one of them. The  |
//| diagonal tiles reach full color in their far corner rather than  |
//| part of the way across, which is what an unnormalized projection |
//| gets wrong.                                                      |
//+------------------------------------------------------------------+
void PanelAngles(const double ox, const double oy)
  {
   Card(ox, oy, 440, 180);

   for(int i = 0; i < 8; i++)
     {
      const double tx = ox + 24 + (i % 4) * 100;
      const double ty = oy + 26 + (i / 4) * 82;

      CCairoLinearGradient g;
      g.SetBounds(tx, ty, 88, 66);
      g.SetAngle(i * 45.0);
      g.AddStop(0.0, Tint(C_BLUE, 0.10));
      g.AddStop(1.0, C_BLUE);

      CCairoPath p;
      p.AddRoundRect(tx, ty, 88, 66, 8);
      Fill(p, GetPointer(g));
     }
  }

//+------------------------------------------------------------------+
//| D. STOPS                                                         |
//|                                                                  |
//| Top: a five-stop ramp, with the stops added deliberately OUT OF  |
//| ORDER. AddStop sorts on insert, so the ramp comes out correct    |
//| and the log prints the count.                                    |
//|                                                                  |
//| Bottom: ALPHA stops. CairoLerp interpolates the alpha channel    |
//| along with the colors, so a fully transparent stop fades a shape |
//| OUT rather than fading it toward black. The checkerboard is      |
//| there so the fade is visible against something rather than       |
//| guessed at.                                                      |
//+------------------------------------------------------------------+
void PanelStops(const double ox, const double oy)
  {
   Card(ox, oy, 440, 180);

   CCairoLinearGradient ramp;
   ramp.SetBounds(ox + 24, oy + 26, 392, 62);
   ramp.SetAngle(0);
   ramp.AddStop(1.00, C_DEEP);
   ramp.AddStop(0.00, C_RED);
   ramp.AddStop(0.50, C_GREEN);
   ramp.AddStop(0.25, C_AMBER);
   ramp.AddStop(0.75, C_BLUE);

   CCairoPath bar;
   bar.AddRoundRect(ox + 24, oy + 26, 392, 62, 8);
   Fill(bar, GetPointer(ramp));

   PrintFormat("D. five stops added out of order -> StopCount = %d",
               ramp.StopCount());

//--- the checkerboard the fade is measured against
   for(int r = 0; r < 4; r++)
      for(int c = 0; c < 22; c++)
        {
         if((r + c) % 2 != 0)
            continue;

         CCairoPath sq;
         sq.AddRect(ox + 24 + c * 18, oy + 104 + r * 18, 18, 18);
         Fill(sq, C_LINE);
        }

//--- opaque green on the left, the same green at alpha 0 on the
//--- right. Nothing else in the library can express this.
   CCairoLinearGradient fade;
   fade.SetBounds(ox + 24, oy + 104, 392, 72);
   fade.SetAngle(0);
   fade.AddStop(0.0, CairoWithOpacity(C_GREEN, 1.0));
   fade.AddStop(1.0, CairoWithOpacity(C_GREEN, 0.0));

   CCairoPath fade_bar;
   fade_bar.AddRoundRect(ox + 24, oy + 104, 392, 72, 8);
   Fill(fade_bar, GetPointer(fade));
  }

//+------------------------------------------------------------------+
//| E. RADIAL GRADIENTS                                              |
//|                                                                  |
//| Three circles differing only in SetCenterNorm and SetRadiusNorm, |
//| then a glow, then the wide bar.                                  |
//|                                                                  |
//| The bar is the one to look at: distance is measured in the box's |
//| normalized space, so in a wide, short box the gradient comes out |
//| ELLIPTICAL and follows the shape. That is almost always what is  |
//| meant by a highlight, and it is free.                            |
//+------------------------------------------------------------------+
void PanelRadial(const double ox, const double oy)
  {
   Card(ox, oy, 440, 200);

//--- ONE ramp, used by every gradient in this panel.
//---
//--- All three stops sit on the SAME hue: a near-white highlight,
//--- the palette blue at full saturation, and that blue darkened
//--- toward the ink color. Darkening rather than desaturating is
//--- what keeps it clean - a ramp from a saturated blue to a grey
//--- passes through washed-out colors on the way and reads as
//--- dirt, which is the classic way a hand-picked gradient goes
//--- wrong. Shading toward the ink keeps every intermediate color
//--- recognizably blue.
   const uint core = Tint(C_BLUE, 0.08);               // the lit point
   const uint deep = CairoLerp(C_BLUE, C_INK, 0.62);   // the shadow

   double cu[3] = { 0.50, 0.30, 0.50 };
   double cv[3] = { 0.50, 0.30, 0.50 };
   double rr[3] = { 0.50, 0.80, 0.25 };

   for(int i = 0; i < 3; i++)
     {
      const double tx = ox + 24 + i * 100;

      CCairoRadialGradient g;
      g.SetBounds(tx, oy + 24, 88, 88);
      g.SetCenterNorm(cu[i], cv[i]);
      g.SetRadiusNorm(rr[i]);
      g.AddStop(0.00, core);
      g.AddStop(0.45, C_BLUE);
      g.AddStop(1.00, deep);

      CCairoPath p;
      p.AddCircle(tx + 44, oy + 68, 44);
      Fill(p, GetPointer(g));
     }

//--- a glow: three stops that vary ONLY in alpha.
//---
//--- Note what is NOT done here: the core is not lightened toward
//--- white. On a light card that would erase it, because a glow is
//--- read as a glow through SATURATION against its background, not
//--- through brightness. Lightening the center works on a dark
//--- panel and destroys it on this one.
//---
//--- The middle stop is what separates a glow from a fog. Holding
//--- the alpha high to 30% of the radius gives a solid core, and
//--- the fall to zero over the remaining 70% gives the halo. Two
//--- stops alone ramp linearly the whole way and read as a smudge.
   CCairoRadialGradient glow;
   glow.SetBounds(ox + 324, oy + 24, 88, 88);
   glow.SetCenterNorm(0.5, 0.5);
   glow.SetRadiusNorm(0.5);
   glow.AddStop(0.00, CairoWithOpacity(C_AMBER, 1.00));
   glow.AddStop(0.30, CairoWithOpacity(C_AMBER, 0.85));
   glow.AddStop(1.00, CairoWithOpacity(C_AMBER, 0.00));

   CCairoPath halo;
   halo.AddCircle(ox + 368, oy + 68, 44);
   Fill(halo, GetPointer(glow));

//--- the elliptical highlight in a wide, short box.
//---
//--- Deliberately the SAME three stops and the same centered
//--- radius as the first circle above. Nothing about the gradient
//--- changed; only the box did. Everything elliptical about the
//--- result comes from the bounds being 392 x 48 instead of
//--- 88 x 88, which is the whole point of measuring the distance
//--- in normalized space.
   CCairoRadialGradient wide;
   wide.SetBounds(ox + 24, oy + 126, 392, 48);
   wide.SetCenterNorm(0.5, 0.5);
   wide.SetRadiusNorm(0.5);
   wide.AddStop(0.00, core);
   wide.AddStop(0.45, C_BLUE);
   wide.AddStop(1.00, deep);

   CCairoPath wide_bar;
   wide_bar.AddRoundRect(ox + 24, oy + 126, 392, 48, 12);
   Fill(wide_bar, GetPointer(wide));
  }

//+------------------------------------------------------------------+
//| F. CCairoFillStyle                                               |
//|                                                                  |
//| ONE handle, switched between all four kinds. Every switch frees  |
//| whatever the previous kind allocated, so a widget can cycle      |
//| solid -> linear -> radial -> none across theme changes without   |
//| leaking an object.                                               |
//|                                                                  |
//| The fourth tile is the interesting one: a style set to None()    |
//| makes Paint() return NULL, the rasterizer returns before it      |
//| builds a single edge, and the card shows through. That is how an |
//| outlined widget with no background is expressed, and it costs    |
//| nothing rather than costing a pass over every pixel with a       |
//| transparent color.                                               |
//+------------------------------------------------------------------+
void PanelFillStyle(const double ox, const double oy)
  {
   Card(ox, oy, 440, 200);

   CCairoFillStyle style;

   for(int i = 0; i < 4; i++)
     {
      const double tx = ox + 24 + i * 100;
      const double ty = oy + 46;

      //--- reconfigure the SAME style object each time round
      if(i == 0)
        {
         style.Solid(C_GREEN);
        }
      else
         if(i == 1)
           {
            CCairoLinearGradient *g = style.Linear();
            g.SetAngle(90);
            g.AddStop(0.0, C_AMBER);
            g.AddStop(1.0, C_RED);
           }
         else
            if(i == 2)
              {
               CCairoRadialGradient *g = style.Radial();
               g.SetCenterNorm(0.40, 0.32);
               g.SetRadiusNorm(0.70);
               g.AddStop(0.0, Tint(C_DEEP, 0.25));
               g.AddStop(1.0, C_DEEP);
              }
            else
              {
               style.None();
              }

      //--- Paint() binds the gradient bounds to the shape at DRAW
      //--- time, so the caller never has to remember to do it
      CCairoPath p;
      p.AddRoundRect(tx, ty, 88, 88, 14);
      Fill(p, style.Paint((int)tx, (int)ty, 88, 88));

      //--- a border, so the "none" tile is still a visible tile
      CCairoPath edge;
      edge.AddRoundRect(tx,     ty,     88,     88,     14);
      edge.AddRoundRect(tx + 2, ty + 2, 88 - 4, 88 - 4, 12);
      Fill(edge, C_MUTED, CAIRO_EVENODD);

      const bool skipped =
         (style.Paint((int)tx, (int)ty, 88, 88) == NULL);

      PrintFormat("F. tile %d -> style type %d, paint is %s",
                  i, (int)style.Type(),
                  skipped ? "NULL (fill skipped)" : "valid");
     }
  }

//+------------------------------------------------------------------+
//| G. WHAT IT IS ALL FOR                                            |
//|                                                                  |
//| A card with a gradient header, an area chart whose fill fades to |
//| nothing at the baseline, a status dot with a glow around it, and |
//| gradient progress bars.                                          |
//|                                                                  |
//| Every one of these was out of reach one article ago, and not one |
//| of them needed a new shape.                                      |
//+------------------------------------------------------------------+
void PanelRealistic(const double ox, const double oy)
  {
   const double w = 890, h = 170;

   CCairoPath body;
   body.AddRoundRect(ox, oy, w, h, 14);
   Fill(body, C_BACK);

//--- the header, rounded at the top only - Part 7's per-corner
//--- radii, filled with Part 8's gradient
   CCairoLinearGradient head;
   head.SetBounds(ox, oy, w, 44);
   head.SetAngle(0);
   head.AddStop(0.0, Tint(C_BLUE, 0.22));
   head.AddStop(1.0, Tint(C_BLUE, 0.04));

   CCairoPath header;
   header.AddRoundRect(ox, oy, w, 44, 14, 14, 0, 0);
   Fill(header, GetPointer(head));

//--- a glowing status dot: a solid core inside a radial halo
   CCairoRadialGradient halo_g;
   halo_g.SetBounds(ox + 8, oy + 4, 36, 36);
   halo_g.SetCenterNorm(0.5, 0.5);
   halo_g.SetRadiusNorm(0.5);
   halo_g.AddStop(0.0, CairoWithOpacity(C_GREEN, 0.55));
   halo_g.AddStop(1.0, CairoWithOpacity(C_GREEN, 0.00));

   CCairoPath halo;
   halo.AddCircle(ox + 26, oy + 22, 18);
   Fill(halo, GetPointer(halo_g));

   CCairoPath dot;
   dot.AddCircle(ox + 26, oy + 22, 6);
   Fill(dot, C_GREEN);

//--- the area chart
   const int n = 56;

   double vx[], vy[], ax[], ay[];

   ArrayResize(vx, n);
   ArrayResize(vy, n);
   ArrayResize(ax, n + 2);
   ArrayResize(ay, n + 2);

   const double gx = ox + 24, gy = oy + 60, gw = 500, gh = 92;

   double v = 0.45;

   for(int i = 0; i < n; i++)
     {
      v += MathSin(i * 0.62) * 0.032 + MathCos(i * 0.21) * 0.019 + 0.004;

      if(v < 0.06)
         v = 0.06;
      if(v > 0.94)
         v = 0.94;

      vx[i] = gx + gw * i / (n - 1.0);
      vy[i] = gy + gh * (1.0 - v);

      ax[i] = vx[i];
      ay[i] = vy[i];
     }

//--- close the outline down to the baseline, so the polygon is
//--- the area under the curve rather than the curve itself
   ax[n]     = gx + gw;
   ay[n]     = gy + gh;
   ax[n + 1] = gx;
   ay[n + 1] = gy + gh;

   CCairoLinearGradient area;
   area.SetBounds(gx, gy, gw, gh);
   area.SetAngle(90);
   area.AddStop(0.0, CairoWithOpacity(C_BLUE, 0.55));
   area.AddStop(1.0, CairoWithOpacity(C_BLUE, 0.00));

   CCairoPath fill_area;
   fill_area.AddPolygon(ax, ay, n + 2);
   Fill(fill_area, GetPointer(area));

//--- the line on top: one path, one fill, the Part 5 way
   CCairoPath line;

   for(int i = 0; i < n - 1; i++)
      line.AddThickLine(vx[i], vy[i], vx[i + 1], vy[i + 1], 2.0);

   Fill(line, C_BLUE);

//--- gradient progress bars
   double progress[3] = { 0.78, 0.52, 0.91 };
   uint   from[3], to[3];

   from[0] = C_GREEN;
   to[0] = Tint(C_GREEN, 0.45);
   from[1] = C_AMBER;
   to[1] = Tint(C_AMBER, 0.45);
   from[2] = C_BLUE;
   to[2] = C_DEEP;

   for(int i = 0; i < 3; i++)
     {
      const double py = oy + 66 + i * 34;
      const double pw = 300;

      CCairoPath track;
      track.AddRoundRect(ox + 560, py, pw, 14, 7);
      Fill(track, Tint(C_MUTED, 0.35));

      CCairoLinearGradient g;
      g.SetBounds(ox + 560, py, pw * progress[i], 14);
      g.SetAngle(0);
      g.AddStop(0.0, from[i]);
      g.AddStop(1.0, to[i]);

      CCairoPath pfill;
      pfill.AddRoundRect(ox + 560, py, pw * progress[i], 14, 7);
      Fill(pfill, GetPointer(g));
     }

//--- the card border
   CCairoPath edge;
   edge.AddRoundRect(ox,     oy,     w,     h,     14);
   edge.AddRoundRect(ox + 1, oy + 1, w - 2, h - 2, 13);
   Fill(edge, C_LINE, CAIRO_EVENODD);
  }

//+------------------------------------------------------------------+
//| WHAT DOES THE VIRTUAL CALL COST?                                 |
//|                                                                  |
//| The honest question to ask about this design: ColorAt is now a   |
//| virtual call in the innermost loop of the renderer, once per     |
//| composited pixel. Measure it rather than assuming.               |
//|                                                                  |
//| The same shape, filled the same number of times, once with a     |
//| solid paint and once with a linear gradient. Nothing is drawn to |
//| the visible panel - this runs into a scratch buffer of its own.  |
//+------------------------------------------------------------------+
void Benchmark()
  {
   const int    reps = 200;
   const int    bw   = 400;
   const int    bh   = 200;

   uint scratch[];

   if(ArrayResize(scratch, bw * bh) < 0)
      return;

   ArrayInitialize(scratch, 0);

   CCairoPath shape;
   shape.AddRoundRect(10, 10, bw - 20, bh - 20, 24);

   CCairoSolidPaint solid(C_BLUE);

   CCairoLinearGradient grad;
   grad.SetBounds(10, 10, bw - 20, bh - 20);
   grad.SetAngle(45);
   grad.AddStop(0.0, C_BLUE);
   grad.AddStop(1.0, C_GREEN);

   const ulong s0 = GetMicrosecondCount();
   for(int i = 0; i < reps; i++)
      g_ras.Fill(shape, GetPointer(solid), scratch, bw, bh);
   const ulong s1 = GetMicrosecondCount();

   for(int i = 0; i < reps; i++)
      g_ras.Fill(shape, GetPointer(grad), scratch, bw, bh);
   const ulong s2 = GetMicrosecondCount();

   PrintFormat("bench: %d fills of a %dx%d rounded rect", reps, bw, bh);
   PrintFormat("bench: solid    %6d us  (%5.0f us per fill)",
               (int)(s1 - s0), (s1 - s0) / (double)reps);
   PrintFormat("bench: gradient %6d us  (%5.0f us per fill)",
               (int)(s2 - s1), (s2 - s1) / (double)reps);
  }

//+------------------------------------------------------------------+
//| Compose                                                          |
//+------------------------------------------------------------------+
void Render()
  {
   g_surface.Clear(C_BACK);

   Print("=== Part 8: paint - one virtual method ===");

   PanelOneShape(10,  10);
   PanelOnePaint(460,  10);
   PanelAngles(10, 190);
   PanelStops(460, 190);
   PanelRadial(10, 380);
   PanelFillStyle(460, 380);
   PanelRealistic(10, 590);

   g_surface.Flush();
  }

//+------------------------------------------------------------------+
//| The captions. Chart pixels, so UI_X / UI_Y have to be added.     |
//+------------------------------------------------------------------+
void Captions()
  {
   DemoLabel("a", UI_X + 24, UI_Y + 16,
             "A. One shape, three paints - only the object passed "
             "to Fill differs");

   DemoLabel("b", UI_X + 489, UI_Y + 16,
             "B. One paint, three shapes - neither side knows about "
             "the other");

   DemoLabel("c", UI_X + 24, UI_Y + 196,
             "C. Eight angles - every tile reaches full color in its "
             "far corner");

   DemoLabel("d", UI_X + 489, UI_Y + 196,
             "D. Five stops added out of order, and an alpha fade over "
             "a checkerboard");

   DemoLabel("e", UI_X + 24, UI_Y + 382,
             "E. Radial: center, radius, a glow, and an elliptical "
             "highlight");

   DemoLabel("f", UI_X + 489, UI_Y + 382,
             "F. One CCairoFillStyle, four kinds - the last one draws "
             "nothing");

   DemoLabel("g", UI_X + 54, UI_Y + 605,
             "G. A card: gradient header, fading area fill, glowing "
             "dot, gradient bars");
  }

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
   if(InpSetLightChart)
      DemoUseLightChart();

   if(!g_surface.Create("cairo_demo08", UI_X, UI_Y, UI_W, UI_H))
     {
      Print("Cairo5: failed to create the surface");
      return INIT_FAILED;
     }

   const ulong t0 = GetMicrosecondCount();
   Render();
   const ulong t1 = GetMicrosecondCount();

   if(InpShowCaptions)
      Captions();

   ChartRedraw();

   PrintFormat("whole %dx%d frame in %d us, 1 chart object",
               UI_W, UI_H, (int)(t1 - t0));

   Benchmark();

   return INIT_SUCCEEDED;
  }

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   g_surface.Destroy();
   DemoLabelsClear();
   ChartRedraw();
  }

//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
  }
//+------------------------------------------------------------------+

