//+------------------------------------------------------------------+
//|                                            Demo05_FillRules.mq5  |
//|                              Copyright 2026, Sandro Begashvili   |
//|                   https://www.mql5.com/en/users/sandrobegashvil  |
//|                          Telegram: https://t.me/MrMQL5Developer  |
//|            Cairo-Style Graphics in MQL5 (Part 5) - the only demo |
//|                                                                  |
//|  HOLES, RINGS, BORDERS AND STROKES.                              |
//|                                                                  |
//|  Everything new on this screen comes from two additions:         |
//|                                                                  |
//|      Raster.mqh   a `rule` parameter - NONZERO or EVENODD        |
//|      Path.mqh     AddThickLine - a segment with width, as a quad |
//|                                                                  |
//|  Panels:                                                         |
//|                                                                  |
//|    A.  the same path under both rules, side by side              |
//|    B.  the letter "A" finally rendering as a letter              |
//|    C.  borders: the wrong way and the right way                  |
//|    D.  rings at five thicknesses, and nested bands               |
//|    E.  strokes: a polyline built from quads, filled in ONE pass  |
//|    F.  THE FAILURE CASE - a stroke with mixed winding, which     |
//|        punches a hole at every joint. Worth seeing once.         |
//|                                                                  |
//|  The Part 2 helpers are used throughout: ReservePoints() where   |
//|  the vertex count is known in advance, Clear() to rebuild one    |
//|  path instead of allocating hundreds, Release() when a path is   |
//|  finished with, and IsValid() to report that no allocation was   |
//|  refused along the way.                                          |
//|                                                                  |
//|  Attach to any chart. Everything is removed again on deinit.     |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Sandro Begashvili"
#property link      "https://www.mql5.com/en/users/sandrobegashvil"
#property description "Part 5: non-zero and even-odd fill rules, holes, borders and strokes"
#property description "Free to use and extend - please credit the author's mql5.com profile"
#property version   "1.00"
#property strict

#include <CairoG2D/Config.mqh>
#include <CairoG2D/Color.mqh>
#include <CairoG2D/Path.mqh>
#include <CairoG2D/Raster.mqh>
#include <CairoG2D/Surface.mqh>
#include <CairoG2D/DemoTheme.mqh>

#define UI_X      20
#define UI_Y      20
#define UI_W     960
#define UI_H     700

//--- every color is a role from the shared light theme
#define C_BACK    DEMO_BG
#define C_CARD    DEMO_PANEL
#define C_BLUE    DEMO_BLUE
#define C_GREEN   DEMO_GREEN
#define C_AMBER   DEMO_AMBER
#define C_RED     DEMO_RED
#define C_GREY    DEMO_GREY
#define C_SOFT    DEMO_INK_SOFT

//--- the "we do not know what is underneath" checkerboard
#define C_CHECKER CairoRgb( 231, 235, 239 )

//--- captions are annotation for the article figures, not drawing.
//--- Turn them off and the panel is still exactly one chart object.
input bool InpShowCaptions  = true;   // Draw the explanatory captions
input bool InpSetLightChart = true;   // Switch the chart to Black On White

CCairoSurface    g_surface;
CCairoRasterizer g_ras;

//+------------------------------------------------------------------+
//| One call for every shape in this demo. The only difference from  |
//| Part 4 is that the fill rule now travels with it.                |
//+------------------------------------------------------------------+
void Fill(CCairoPath &p, const uint argb,
          const ENUM_CAIRO_FILLRULE rule = CAIRO_NONZERO)
  {
   g_ras.Fill(p, argb, g_surface.m_px,
              g_surface.Width(), g_surface.Height(), rule);
  }

//+------------------------------------------------------------------+
//| A regular polygon, standing in for the circles Part 7 brings.    |
//|                                                                  |
//| `reverse` walks the vertices backwards, which flips the winding  |
//| direction without changing a single coordinate - exactly what is |
//| needed to demonstrate what the non-zero rule reacts to.          |
//+------------------------------------------------------------------+
void AddNGon(CCairoPath &p, const double cx, const double cy,
             const double r, const int n, const bool reverse = false)
  {
   if(n < 3)
      return;

   double xs[], ys[];

//--- Part 2's contract: a resize is checked, never assumed
   if(ArrayResize(xs, n) < n)
      return;
   if(ArrayResize(ys, n) < n)
      return;

//--- the vertex count is known before the loop starts
   p.ReservePoints(p.PointCount() + n);

   for(int i = 0; i < n; i++)
     {
      //--- walking i backwards reverses the winding direction
      const int    k = reverse ? (n - 1 - i) : i;
      const double a = 2.0 * M_PI * k / n;

      xs[i] = cx + r * MathCos(a);
      ys[i] = cy + r * MathSin(a);
     }

   p.AddPolygon(xs, ys, n);
  }

//+------------------------------------------------------------------+
//| A checkerboard, so that "transparent" is visible on paper.       |
//|                                                                  |
//| This is not library code. It stands in for whatever the caller   |
//| had already drawn underneath - a chart, a gradient, another      |
//| widget - so that a fill which paints over it can be caught.      |
//+------------------------------------------------------------------+
void Checkerboard(const double ox, const double oy,
                  const double w, const double h, const double cell)
  {
   const int cols = (int)MathCeil(w / cell);
   const int rows = (int)MathCeil(h / cell);

   CCairoPath sq;

   for(int r = 0; r < rows; r++)
      for(int c = 0; c < cols; c++)
        {
         if(((r + c) & 1) == 0)
            continue;

         const double cw = MathMin(cell, w - c * cell);
         const double ch = MathMin(cell, h - r * cell);

         //--- ONE path, emptied and refilled. Clear() keeps the
         //--- memory it has already been given, so the hundreds of
         //--- squares below cost a single allocation between them.
         sq.Clear();
         sq.AddRect(ox + c * cell, oy + r * cell, cw, ch);
         Fill(sq, C_CHECKER);
        }

//--- and this is the scaffolding, not the panel, so hand the
//--- memory back rather than hold it for the life of the chart
   sq.Release();
  }

//+------------------------------------------------------------------+
//| A. THE SAME PATH, BOTH RULES                                     |
//|                                                                  |
//| Three overlapping discs, all wound the SAME way, in one path.    |
//|                                                                  |
//|   left    NONZERO - the winding number reaches 2 and 3 in the    |
//|           overlaps. Never zero, so they merge into one blob.     |
//|                                                                  |
//|   right   EVENODD - the overlaps have been crossed an even number|
//|           of times, so they fall OUT. The classic three-ring     |
//|           interference pattern appears.                          |
//|                                                                  |
//| Identical geometry. Identical call. One enum different.          |
//+------------------------------------------------------------------+
void PanelBothRules(const double ox, const double oy)
  {
   for(int side = 0; side < 2; side++)
     {
      const double bx = ox + side * 230;

      CCairoPath p;
      AddNGon(p, bx +  70, oy +  55, 50, 96);
      AddNGon(p, bx + 120, oy +  55, 50, 96);
      AddNGon(p, bx +  95, oy + 100, 50, 96);

      Fill(p, (side == 0) ? C_BLUE  : C_AMBER,
           (side == 0) ? CAIRO_NONZERO : CAIRO_EVENODD);
     }
  }

//+------------------------------------------------------------------+
//| B. THE LETTER "A", AT LAST                                       |
//|                                                                  |
//| In Part 3 this glyph filled solid, because both contours were    |
//| wound the same way and the non-zero rule merged them.            |
//|                                                                  |
//| Three versions here:                                             |
//|                                                                  |
//|   1  NONZERO, both contours wound the same way - solid, wrong    |
//|   2  NONZERO, counter reversed by hand - correct, but the caller |
//|      had to know about winding                                   |
//|   3  EVENODD, both contours wound the same way - correct, and the|
//|      caller did not have to think about it at all                |
//|                                                                  |
//| Version 3 is why font rendering and SVG reach for even-odd, or   |
//| an equivalent: artwork should not have to encode a rendering     |
//| detail in its vertex order.                                      |
//+------------------------------------------------------------------+
void AddGlyphA(CCairoPath &p, const double ox, const double oy,
               const bool reverse_counter)
  {
//--- outer outline
   p.MoveTo(ox +  58, oy +   8);
   p.LineTo(ox + 112, oy + 132);
   p.LineTo(ox +  86, oy + 132);
   p.LineTo(ox +  75, oy + 104);
   p.LineTo(ox +  41, oy + 104);
   p.LineTo(ox +  30, oy + 132);
   p.LineTo(ox +   4, oy + 132);
   p.Close();

//--- the counter: the triangular hole in the middle
   if(reverse_counter)
     {
      p.MoveTo(ox + 58, oy + 46);
      p.LineTo(ox + 68, oy + 80);
      p.LineTo(ox + 48, oy + 80);
     }
   else
     {
      p.MoveTo(ox + 48, oy + 80);
      p.LineTo(ox + 68, oy + 80);
      p.LineTo(ox + 58, oy + 46);
     }

   p.Close();
  }

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void PanelGlyph(const double ox, const double oy)
  {
   CCairoPath a1;
   AddGlyphA(a1, ox, oy, false);
   Fill(a1, C_GREY, CAIRO_NONZERO);

   CCairoPath a2;
   AddGlyphA(a2, ox + 130, oy, true);
   Fill(a2, C_GREEN, CAIRO_NONZERO);

   CCairoPath a3;
   AddGlyphA(a3, ox + 260, oy, false);
   Fill(a3, C_BLUE, CAIRO_EVENODD);
  }

//+------------------------------------------------------------------+
//| C. BORDERS: THE WRONG WAY AND THE RIGHT WAY                      |
//|                                                                  |
//| THE MOST USEFUL PANEL IN THIS DEMO.                              |
//|                                                                  |
//| left    the common approach: fill a big rectangle in the border  |
//|         color, then fill a smaller one in the BACKGROUND color   |
//|         on top. It looks correct over an opaque card - and it is |
//|         wrong for two reasons this panel exposes.                |
//|                                                                  |
//| right   one path holding both outlines, filled once with EVENODD.|
//|                                                                  |
//| The second row draws both again over a checkerboard, standing in |
//| for whatever the caller had already drawn. The fake border       |
//| paints an opaque patch over it, because it has to paint          |
//| SOMETHING there. The real ring leaves the interior untouched.    |
//|                                                                  |
//| The other problem is subtler and shows under magnification: the  |
//| fake border blends two anti-aliased edges on top of each other   |
//| along the inner boundary, so that boundary comes out slightly    |
//| muddier than the outer one. The ring has one clean edge per      |
//| side.                                                            |
//+------------------------------------------------------------------+
void PanelBorders(const double ox, const double oy)
  {
//--- ROW 1: over an opaque card, where the two look identical
   CCairoPath card;
   card.AddRect(ox, oy, 420, 100);
   Fill(card, C_CARD);

   CCairoPath outer;
   outer.AddRect(ox + 20, oy + 18, 160, 64);
   Fill(outer, C_AMBER);

   CCairoPath inner;
   inner.AddRect(ox + 26, oy + 24, 148, 52);
   Fill(inner, C_CARD);                // "the background color"

   CCairoPath ring;
   ring.AddRect(ox + 240, oy + 18, 160, 64);
   ring.AddRect(ox + 246, oy + 24, 148, 52);
   Fill(ring, C_GREEN, CAIRO_EVENODD);

//--- ROW 2: over something the caller does not control, where the
//--- fake version cannot hide
   Checkerboard(ox, oy + 120, 420, 100, 10);

   CCairoPath fake2_out;
   fake2_out.AddRect(ox + 20, oy + 138, 160, 64);
   Fill(fake2_out, C_AMBER);

   CCairoPath fake2_in;
   fake2_in.AddRect(ox + 26, oy + 144, 148, 52);
   Fill(fake2_in, C_CARD);             // an opaque patch on nothing

   CCairoPath ring2;
   ring2.AddRect(ox + 240, oy + 138, 160, 64);
   ring2.AddRect(ox + 246, oy + 144, 148, 52);
   Fill(ring2, C_GREEN, CAIRO_EVENODD);
  }

//+------------------------------------------------------------------+
//| D. RINGS AT FIVE THICKNESSES, AND NESTED BANDS                   |
//|                                                                  |
//| The inset distance IS the border width. Nothing else changes: a  |
//| hairline and a fat band are the same two lines of code.          |
//|                                                                  |
//| The nested rectangles on the right show that ANY number of       |
//| alternating outlines works - crossing count 1 is inside, 2 is    |
//| outside, 3 is inside again.                                      |
//+------------------------------------------------------------------+
void PanelRings(const double ox, const double oy)
  {
   double widths[5] = { 1.0, 2.0, 4.0, 8.0, 16.0 };

   for(int i = 0; i < 5; i++)
     {
      const double cx = ox + 50 + i * 100;
      const double w  = widths[i];

      CCairoPath ring;
      AddNGon(ring, cx, oy + 50, 42,     72);
      AddNGon(ring, cx, oy + 50, 42 - w, 72);

      Fill(ring, CairoLerp(C_BLUE, C_GREEN, i / 4.0), CAIRO_EVENODD);
     }

   CCairoPath nested;
   nested.AddRect(ox + 540, oy +  6, 140, 90);
   nested.AddRect(ox + 552, oy + 18, 116, 66);
   nested.AddRect(ox + 564, oy + 30,  92, 42);
   nested.AddRect(ox + 576, oy + 42,  68, 18);
   Fill(nested, C_AMBER, CAIRO_EVENODD);
  }

//+------------------------------------------------------------------+
//| E. STROKES BUILT FROM FILLS                                      |
//|                                                                  |
//| The engine has no stroker. A polyline with width is just many    |
//| thin quads - one per segment - plus a small shape at each joint  |
//| so the corners are not notched.                                  |
//|                                                                  |
//| ALL OF IT GOES INTO ONE PATH AND IS FILLED ONCE, with NONZERO.   |
//| Every quad is wound the same way, so the overlaps at the joints  |
//| have winding 2 - still non-zero, still inside - and they union   |
//| seamlessly.                                                      |
//|                                                                  |
//| Filling them separately would be both slower and WRONG: with a   |
//| translucent color, every joint would come out visibly darker,    |
//| because two quads would be blended one after the other over the  |
//| same pixels. One pass means one blend. The color here is 75%     |
//| opaque specifically so that you can check.                       |
//+------------------------------------------------------------------+
void PanelStroke(const double ox, const double oy)
  {
   const int    n = 34;
   const double thickness = 7.0;

   double vx[], vy[];

   if(ArrayResize(vx, n) < n)
      return;
   if(ArrayResize(vy, n) < n)
      return;

   for(int i = 0; i < n; i++)
     {
      vx[i] = ox + i * 12.0;
      vy[i] = oy + 55 + MathSin(i * 0.42) * 40
              + MathCos(i * 0.17) * 10;
     }

//--- ONE path for the whole polyline. The total is known, so the
//--- whole thing is one allocation instead of sixty-five.
   CCairoPath stroke;
   stroke.ReserveContours((n - 1) + (n - 2));
   stroke.ReservePoints((n - 1) * 4 + (n - 2) * 12);

   for(int i = 0; i < n - 1; i++)
      stroke.AddThickLine(vx[i], vy[i], vx[i + 1], vy[i + 1],
                          thickness);

//--- a small regular polygon at each interior joint, rounding it
   for(int i = 1; i < n - 1; i++)
      AddNGon(stroke, vx[i], vy[i], thickness * 0.5, 12);

   Fill(stroke, CairoWithOpacity(C_GREEN, 0.75), CAIRO_NONZERO);

   PrintFormat("E. stroke: %d segments + %d joints = %d contours, "
               "%d vertices, ONE fill, valid = %s",
               n - 1, n - 2, stroke.ContourCount(),
               stroke.PointCount(),
               stroke.IsValid() ? "true" : "false");
  }

//+------------------------------------------------------------------+
//| F. THE FAILURE CASE                                              |
//|                                                                  |
//| The same polyline, with every SECOND quad wound backwards.       |
//|                                                                  |
//| The overlap at each joint now sums to +1 - 1 = 0. The non-zero   |
//| rule reads that as OUTSIDE, and a hole appears at every single   |
//| joint.                                                           |
//|                                                                  |
//| This is why Part 2 insisted, without explanation at the time,    |
//| that every shape helper must wind its outline consistently. It   |
//| is a spectacular bug, and far easier to recognize on sight than  |
//| to derive from first principles at two in the morning.           |
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//| The same quad AddThickLine builds, emitted the other way round.  |
//|                                                                  |
//| READ THIS ONE CAREFULLY, because the obvious way to reverse a    |
//| segment does NOT work. Calling                                   |
//|                                                                  |
//|     AddThickLine( x1, y1, x0, y0, thickness )                    |
//|                                                                  |
//| swaps the endpoints, which negates the direction (dx, dy) - and  |
//| therefore negates the normal as well. Both the normal AND the    |
//| order the corners come out in are flipped, and the two flips     |
//| cancel: you get back the identical quad, wound the identical     |
//| way.                                                             |
//|                                                                  |
//| What actually reverses the winding is emitting the four corners  |
//| in the opposite ORDER, which is what this helper does. It exists |
//| only to produce the bug on purpose.                              |
//+------------------------------------------------------------------+
void AddThickLineReversed(CCairoPath &p, const double x0, const double y0,
                          const double x1, const double y1,
                          const double thickness)
  {
   const double dx  = x1 - x0;
   const double dy  = y1 - y0;
   const double len = MathSqrt(dx * dx + dy * dy);

   if(len < 1e-9)
      return;

   const double nx = -dy / len * (thickness * 0.5);
   const double ny =  dx / len * (thickness * 0.5);

//--- corners 4, 3, 2, 1 instead of 1, 2, 3, 4
   p.MoveTo(x1 + nx, y1 + ny);
   p.LineTo(x1 - nx, y1 - ny);
   p.LineTo(x0 - nx, y0 - ny);
   p.LineTo(x0 + nx, y0 + ny);
   p.Close();
  }

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void PanelMixedWinding(const double ox, const double oy)
  {
   const int    n = 34;
   const double thickness = 7.0;

   CCairoPath bad;

   for(int i = 0; i < n - 1; i++)
     {
      const double x0 = ox + i * 12.0;
      const double y0 = oy + 55 + MathSin(i * 0.42) * 40
                        + MathCos(i * 0.17) * 10;
      const double x1 = ox + (i + 1) * 12.0;
      const double y1 = oy + 55 + MathSin((i + 1) * 0.42) * 40
                        + MathCos((i + 1) * 0.17) * 10;

      if(i % 2 == 0)
         bad.AddThickLine(x0, y0, x1, y1, thickness);
      else
         AddThickLineReversed(bad, x0, y0, x1, y1, thickness);
     }

   Fill(bad, C_RED, CAIRO_NONZERO);
  }

//+------------------------------------------------------------------+
//| Compose                                                          |
//+------------------------------------------------------------------+
void Render()
  {
   g_surface.Clear(C_BACK);

   Print("=== Part 5: fill rules, holes, borders and strokes ===");

   PanelBothRules(30,  40);
   PanelGlyph(520,  40);
   PanelBorders(30, 230);
   PanelStroke(490, 230);
   PanelMixedWinding(490, 350);
   PanelRings(30, 500);

   g_surface.Flush();
  }

//+------------------------------------------------------------------+
//| The captions. Chart pixels, so UI_X / UI_Y have to be added.     |
//+------------------------------------------------------------------+
void Captions()
  {
   DemoLabel("a", UI_X + 30, UI_Y + 18,
             "A. One path, both rules: NONZERO merges, EVENODD cancels");

   DemoLabel("b", UI_X + 520, UI_Y + 18,
             "B. The letter A: solid, reversed counter, even-odd");

   DemoLabel("c", UI_X + 30, UI_Y + 208,
             "C. Fake border and true ring - identical on a card");
   DemoLabel("c2", UI_X + 30, UI_Y + 336,
             "...and over anything else, the fake one paints a patch",
             DEMO_INK_SOFT, 8);

   DemoLabel("e", UI_X + 490, UI_Y + 208,
             "E. 33 quads + 32 joints, one path, one fill, 75% opaque");

   DemoLabel("f", UI_X + 490, UI_Y + 328,
             "F. The same stroke with alternating winding - it fails",
             DEMO_RED);

   DemoLabel("d", UI_X + 30, UI_Y + 478,
             "D. Ring width 1, 2, 4, 8, 16 px, and alternating bands");
  }

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
   if(InpSetLightChart)
      DemoUseLightChart();

   if(!g_surface.Create("cairo_demo05", UI_X, UI_Y, UI_W, UI_H))
     {
      Print("Cairo5: failed to create the surface");
      return INIT_FAILED;
     }

   const ulong t0 = GetMicrosecondCount();
   Render();
   const ulong t1 = GetMicrosecondCount();

   if(InpShowCaptions)
      Captions();

   ChartRedraw();

   PrintFormat("whole %dx%d frame in %d us",
               UI_W, UI_H, (int)(t1 - t0));

   return INIT_SUCCEEDED;
  }

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   g_surface.Destroy();
   DemoLabelsClear();
   ChartRedraw();
  }

//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
  }
//+------------------------------------------------------------------+
