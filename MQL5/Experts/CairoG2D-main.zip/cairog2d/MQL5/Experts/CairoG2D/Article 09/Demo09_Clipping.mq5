//+-------------------------------------------------------------------+
//|                                            Demo09_Clipping.mq5    |
//|                              Copyright 2026, Sandro Begashvili    |
//|                   https://www.mql5.com/en/users/sandrobegashvil   |
//|                          Telegram: https://t.me/MrMQL5Developer   |
//|            Cairo-Style Graphics in MQL5 (Part 9) - the only demo  |
//|                                                                   |
//|  ONE MULTIPLICATION, AND DRAWING LEARNS WHERE TO STOP.            |
//|                                                                   |
//|  The library is seven files after this part. The new one,         |
//|  Clip.mqh, holds the MASK half of Part 1's Cairo model as a       |
//|  permission map: for every pixel, how much of it drawing is       |
//|  allowed to reach.                                                |
//|                                                                   |
//|  Six panels, two columns, three rows:                             |
//|                                                                   |
//|    A. the same star twice - unclipped, then clipped to a          |
//|       rectangle. Only one object was passed differently.          |
//|    B. a clip edge at x.5, magnified: the boundary is              |
//|       anti-aliased because it is the same coverage number         |
//|    C. clipping to a PATH, and nesting two clips into a lens       |
//|    D. Bounds() - every shape, and the rectangle around it         |
//|    E. a scrolling list, which is the reason this part exists      |
//|    F. Contains() - the winding rule asked about one point         |
//|                                                                   |
//|  NOTHING INSIDE THE BITMAP IS TEXT. The rows of panel E carry     |
//|  drawn pills rather than chart labels, because a chart label is   |
//|  a separate object that floats above the bitmap and knows         |
//|  nothing about the clip - it would not scroll and would not be    |
//|  cut at the viewport edge, which is precisely the thing the       |
//|  panel exists to show. Part 15 is where text joins the engine.    |
//|                                                                   |
//|  Nothing in Paint.mqh, Color.mqh or Surface.mqh changed to make   |
//|  any of this work, and the scanline loop changed by one line.     |
//|                                                                   |
//|  Attach to any chart. Everything is removed again on deinit.      |
//+-------------------------------------------------------------------+
#property copyright "Copyright 2026, Sandro Begashvili"
#property link      "https://www.mql5.com/en/users/sandrobegashvil"
#property description "Part 9: clipping, bounds and hit testing"
#property description "Free to use and extend - please credit the author on mql5.com"
#property version   "1.00"
#property strict

#include <CairoG2D/Config.mqh>
#include <CairoG2D/Color.mqh>
#include <CairoG2D/Surface.mqh>
#include <CairoG2D/Path.mqh>
#include <CairoG2D/Paint.mqh>
#include <CairoG2D/Clip.mqh>
#include <CairoG2D/Raster.mqh>
#include <CairoG2D/DemoTheme.mqh>

#define UI_X      10
#define UI_Y      20
#define UI_W     960
#define UI_H     700

//--- the two columns and the three rows, named once
#define COL_L     0
#define COL_R    470
#define ROW_1     10
#define ROW_2    220
#define ROW_3    450

#define PAN_W    460
#define PAN_H1   190
#define PAN_H2   210

#define C_BACK    DEMO_BG
#define C_CARD    DEMO_PANEL
#define C_LINE    DEMO_BORDER
#define C_INK     DEMO_INK
#define C_BLUE    DEMO_BLUE
#define C_GREEN   DEMO_GREEN
#define C_AMBER   DEMO_AMBER
#define C_RED     DEMO_RED
#define C_DEEP    DEMO_INK_SOFT
#define C_MUTED   DEMO_GREY

//--- captions are annotation for the article figures, not drawing.
//--- Turn them off and the panel is still exactly one chart object.
input bool InpShowCaptions  = true;   // Draw the explanatory captions
input bool InpSetLightChart = true;   // Switch the chart to Black On White
input int  InpScroll        = 30;     // Panel E: scroll offset, in pixels

CCairoSurface    g_surface;
CCairoRasterizer g_ras;

//--- ONE clip object for the whole demo, reset between panels. A clip
//--- can only ever be narrowed, so the way back out is a Reset() or a
//--- CopyFrom() - never an "unclip".
CCairoClip       g_clip;

//+-------------------------------------------------------------------+
//| Shorthand fills.                                                  |
//|                                                                   |
//| Both now forward the demo's clip. Passing it everywhere and       |
//| resetting it between panels is the honest way round: a drawing    |
//| helper that silently ignored the clip would be a helper that      |
//| could not be used inside a panel.                                 |
//+-------------------------------------------------------------------+
void Fill(CCairoPath &p, CCairoPaint *paint,
          const ENUM_CAIRO_FILLRULE rule = CAIRO_NONZERO)
  {
   g_ras.Fill(p, paint, g_surface.m_px,
              g_surface.Width(), g_surface.Height(), rule,
              GetPointer(g_clip));
  }

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void Fill(CCairoPath &p, const uint argb,
          const ENUM_CAIRO_FILLRULE rule = CAIRO_NONZERO)
  {
   g_ras.Fill(p, argb, g_surface.m_px,
              g_surface.Width(), g_surface.Height(), rule,
              GetPointer(g_clip));
  }

//+-------------------------------------------------------------------+
//| Open the clip up to the whole surface again.                      |
//+-------------------------------------------------------------------+
void ClipAll()
  {
   g_clip.Reset(g_surface.Width(), g_surface.Height());
  }

//+-------------------------------------------------------------------+
//| A tint of a theme color, so the light panels stay light.          |
//+-------------------------------------------------------------------+
uint Tint(const uint argb, const double t)
  {
   return CairoLerp(DEMO_BG, argb, t);
  }

//+-------------------------------------------------------------------+
//| A rounded rectangle with a true ring border - Part 7's helper.    |
//+-------------------------------------------------------------------+
void RoundRectBordered(const double x, const double y,
                       const double w, const double h,
                       const double r,
                       const uint fill_argb, const uint border_argb,
                       const double bw = 1.0)
  {
   CCairoPath body;

   body.AddRoundRect(x, y, w, h, r);
   Fill(body, fill_argb);

   CCairoPath ring;

   ring.AddRoundRect(x, y, w, h, r);
   ring.AddRoundRect(x + bw, y + bw, w - bw * 2.0, h - bw * 2.0,
                     MathMax(0.0, r - bw));
   Fill(ring, border_argb, CAIRO_EVENODD);
  }

//+-------------------------------------------------------------------+
//| The card every panel sits on.                                     |
//+-------------------------------------------------------------------+
void Card(const double x, const double y, const double w, const double h)
  {
   RoundRectBordered(x, y, w, h, 6.0, C_CARD, C_LINE, 1.0);
  }

//+-------------------------------------------------------------------+
//| A five-pointed star, Part 5's helper.                             |
//+-------------------------------------------------------------------+
void AddStar(CCairoPath &p, const double cx, const double cy,
             const double r_out, const double r_in)
  {
   double xs[10], ys[10];

   for(int i = 0; i < 10; i++)
     {
      const double r = (i % 2 == 0) ? r_out : r_in;
      const double a = -M_PI * 0.5 + M_PI * i / 5.0;

      xs[i] = cx + r * MathCos(a);
      ys[i] = cy + r * MathSin(a);
     }

   p.AddPolygon(xs, ys, 10);
  }

//+-------------------------------------------------------------------+
//| A dashed outline, drawn as short filled quads, to show WHERE a    |
//| clip boundary is without the clip itself being visible.           |
//+-------------------------------------------------------------------+
void GuideRect(const SCairoRect &r, const uint argb)
  {
   CCairoPath p;

   const double step = 8.0;

   for(double x = r.Left(); x < r.Right(); x += step)
     {
      const double x1 = MathMin(x + step * 0.55, r.Right());

      p.AddThickLine(x, r.Top(),    x1, r.Top(),    1.0);
      p.AddThickLine(x, r.Bottom(), x1, r.Bottom(), 1.0);
     }

   for(double y = r.Top(); y < r.Bottom(); y += step)
     {
      const double y1 = MathMin(y + step * 0.55, r.Bottom());

      p.AddThickLine(r.Left(),  y, r.Left(),  y1, 1.0);
      p.AddThickLine(r.Right(), y, r.Right(), y1, 1.0);
     }

   Fill(p, argb);
  }

//+-------------------------------------------------------------------+
//| A. ONE SHAPE, ONE CLIP.                                           |
//|                                                                   |
//| The star on the left and the star on the right are built by the   |
//| same four lines. The only difference is that the clip was         |
//| narrowed to a rectangle before the second one was filled.         |
//+-------------------------------------------------------------------+
void PanelOneClip(const double ox, const double oy)
  {
   Card(ox, oy, PAN_W, PAN_H1);

//--- left: no clip at all
   CCairoPath a;

   AddStar(a, ox + 110, oy + 100, 70, 29);
   Fill(a, Tint(C_BLUE, 0.75));

//--- right: the same star, inside a rectangle
   const SCairoRect window = CairoRect(ox + 270, oy + 57, 130, 86);

   GuideRect(window, C_MUTED);

   g_clip.IntersectRect(window);

   CCairoPath b;

   AddStar(b, ox + 340, oy + 100, 70, 29);
   Fill(b, Tint(C_BLUE, 0.75));

   ClipAll();
  }

//+-------------------------------------------------------------------+
//| B. THE EDGE IS ANTI-ALIASED, BECAUSE IT IS COVERAGE.              |
//|                                                                   |
//| Three bars, clipped at x.0, x.5 and x.25. The clip boundary does  |
//| not have to land on a pixel, and where it does not, the column it |
//| passes through is painted in proportion.                          |
//+-------------------------------------------------------------------+
void PanelSoftEdge(const double ox, const double oy)
  {
   Card(ox, oy, PAN_W, PAN_H1);

   const double frac[3] = {0.0, 0.5, 0.25};

   for(int i = 0; i < 3; i++)
     {
      const double y = oy + 38 + i * 48;
      const double edge = ox + 300.0 + frac[i];

      g_clip.IntersectRect(CairoRect(ox + 30, y, edge - (ox + 30), 30));

      CCairoPath bar;

      bar.AddRect(ox + 30, y, 300, 30);
      Fill(bar, C_BLUE);

      ClipAll();

      //--- a 6x magnification of the three columns around the edge,
      //--- read back out of the surface itself
      for(int dx = -1; dx <= 1; dx++)
        {
         const int sx = (int)MathFloor(edge) + dx;
         const int sy = (int)(y + 15);
         const uint px = g_surface.m_px[sy * g_surface.Width() + sx];

         CCairoPath cell;

         cell.AddRect(ox + 352 + (dx + 1) * 30, y, 28, 30);
         Fill(cell, px);
        }
     }
  }

//+-------------------------------------------------------------------+
//| Diagonal stripes - something with an obvious geometry of its own, |
//| so that the cut is visibly the clip's and not the shape's.        |
//+-------------------------------------------------------------------+
void Stripes(const double x, const double y,
             const double w, const double h, const uint argb)
  {
   CCairoPath bg;

   bg.AddRect(x, y, w, h);
   Fill(bg, Tint(argb, 0.18));

   CCairoPath p;

   for(double k = -h; k < w + h; k += 18.0)
      p.AddThickLine(x + k, y, x + k + h, y + h, 7.0);

   Fill(p, Tint(argb, 0.85));
  }

//+-------------------------------------------------------------------+
//| C. CLIPPING TO A PATH, AND NESTING TWO CLIPS.                     |
//|                                                                   |
//| Left: a circle used as a window rather than as a shape. What is   |
//| drawn through it is a diagonal stripe pattern, which has no idea  |
//| it is being cut.                                                  |
//|                                                                   |
//| Right: a rectangle, then a circle on top of it. What is left is   |
//| the lens where the two agree, with both of its edges still        |
//| smooth - the mask holds old_coverage * new_coverage, not a choice |
//| between the two. The saved copy is what puts the rectangle back,  |
//| and the faint wash is what the rectangle alone allows.            |
//+-------------------------------------------------------------------+
void PanelPathClip(const double ox, const double oy)
  {
   Card(ox, oy, PAN_W, PAN_H2);

//--- the "avatar": stripes through a circle
   CCairoPath disc;

   disc.AddCircle(ox + 105, oy + 108, 66);

   g_ras.ClipToPath(disc, g_clip, CAIRO_NONZERO);
   Stripes(ox + 30, oy + 33, 150, 150, C_BLUE);
   ClipAll();

//--- nesting: a rectangle, then a circle inside it
   const SCairoRect window = CairoRect(ox + 240, oy + 52, 170, 112);

   GuideRect(window, C_MUTED);

   g_clip.IntersectRect(window);

//--- save it, so the circle can be undone afterwards
   CCairoClip saved;

   saved.CopyFrom(GetPointer(g_clip));

   CCairoPath lens;

   lens.AddCircle(ox + 325, oy + 108, 78);

   g_ras.ClipToPath(lens, g_clip, CAIRO_NONZERO);

   CCairoPath wash;

   wash.AddRect(ox + 220, oy + 30, 220, 160);
   Fill(wash, C_AMBER);

//--- back to the rectangle alone, and fill the rest of it
   g_clip.CopyFrom(GetPointer(saved));

   CCairoPath rest;

   rest.AddRect(ox + 220, oy + 30, 220, 160);
   Fill(rest, Tint(C_AMBER, 0.22));

   ClipAll();
  }

//+-------------------------------------------------------------------+
//| D. Bounds() - WHERE A SHAPE IS.                                   |
//|                                                                   |
//| Four shapes, each with the rectangle Bounds() returned drawn      |
//| around it. The star's box touches its five points and nothing     |
//| else; the circle's box touches it at four places. Neither was     |
//| measured by hand.                                                 |
//+-------------------------------------------------------------------+
void PanelBounds(const double ox, const double oy)
  {
   Card(ox, oy, PAN_W, PAN_H2);

   CCairoPath shapes[4];

   AddStar(shapes[0], ox + 78,  oy + 76,  46, 19);
   shapes[1].AddCircle(ox + 198, oy + 76, 42);
   shapes[2].AddRoundRect(ox + 278, oy + 36, 128, 80, 24.0);
   shapes[3].AddEllipse(ox + 118, oy + 158, 80, 36);

   CCairoPath spiral;

   spiral.MoveTo(ox + 250, oy + 172);
   spiral.CurveTo(ox + 288, oy + 118, ox + 372, oy + 206,
                  ox + 406, oy + 146);

   for(int i = 0; i < 4; i++)
     {
      Fill(shapes[i], Tint(C_BLUE, 0.55));
      GuideRect(shapes[i].Bounds(), C_DEEP);
     }

//--- a curve, to make the point that the box is exact AFTER
//--- flattening rather than a bound on the control points
   CCairoPath stroke;

   stroke.AddThickLine(ox + 250, oy + 172, ox + 278, oy + 158, 3.0);
   Fill(stroke, C_AMBER);

   GuideRect(spiral.Bounds(), C_AMBER);
  }

//+-------------------------------------------------------------------+
//| E. THE REASON THIS PART EXISTS.                                   |
//|                                                                   |
//| A list of rows, scrolled. Every row is drawn at its true          |
//| position, including the ones above and below the viewport; the    |
//| clip is what makes the two at the boundary end halfway through    |
//| instead of spilling over the panel.                               |
//|                                                                   |
//| THE ROW "LABEL" IS A DRAWN PILL, not a chart label. A chart       |
//| label is a second object floating above the bitmap: it would not  |
//| move with the scroll and the clip could not cut it, which is the  |
//| one thing this panel is here to demonstrate.                      |
//+-------------------------------------------------------------------+
void PanelScrollList(const double ox, const double oy)
  {
   Card(ox, oy, PAN_W, PAN_H2);

   const double vx = ox + 24, vy = oy + 36;
   const double vw = 412, vh = 156;

//--- the viewport, drawn first so the rows sit on it
   RoundRectBordered(vx, vy, vw, vh, 4.0, DEMO_BG, C_LINE, 1.0);

   g_clip.IntersectRect(CairoRect(vx + 1, vy + 1, vw - 2, vh - 2));

   const double row_h = 38.0;
   const double name_w[8] = {64, 72, 58, 68, 62, 76, 56, 70};
   const double pnl[8]    = {128.40, -62.10, 310.75, 44.20,
                             -15.80, 92.35, -204.00, 57.60
                            };

   for(int i = 0; i < 8; i++)
     {
      const double y = vy + 6 + i * row_h - InpScroll;

      //--- NOT skipped when off-screen. The clip is what stops it,
      //--- and the point of the panel is that it does.
      CCairoPath row;

      row.AddRoundRect(vx + 8, y, vw - 16, row_h - 8, 4.0);
      Fill(row, (i % 2 == 0) ? C_CARD : DEMO_BG);

      CCairoPath dot;

      dot.AddCircle(vx + 26, y + (row_h - 8) * 0.5, 6.0);
      Fill(dot, pnl[i] >= 0.0 ? C_GREEN : C_RED);

      //--- the row's "name", drawn rather than written
      CCairoPath name;

      name.AddRoundRect(vx + 44, y + 10, name_w[i], 10, 5.0);
      Fill(name, Tint(C_DEEP, 0.55));

      CCairoPath bar;

      const double mag = MathMin(1.0, MathAbs(pnl[i]) / 320.0);

      bar.AddRoundRect(vx + 240, y + 9, 150 * mag, 12, 3.0);
      Fill(bar, Tint(pnl[i] >= 0.0 ? C_GREEN : C_RED, 0.8));
     }

   ClipAll();
  }

//+-------------------------------------------------------------------+
//| F. Contains() - IS THE POINT INSIDE?                              |
//|                                                                   |
//| A ring, built from two circles. The same grid of test points is   |
//| asked twice: once under the non-zero rule, where both contours    |
//| wind the same way and there is no hole, and once under even-odd,  |
//| where there is. The markers agree with the pixels because the hit |
//| test and the fill are the same arithmetic.                        |
//+-------------------------------------------------------------------+
void PanelHitTest(const double ox, const double oy)
  {
   Card(ox, oy, PAN_W, PAN_H2);

   for(int side = 0; side < 2; side++)
     {
      const bool even_odd = (side == 1);
      const double cx = ox + 118 + side * 224;
      const double cy = oy + 108;

      CCairoPath ring;

      ring.AddCircle(cx, cy, 80);
      ring.AddCircle(cx, cy, 41);

      Fill(ring, Tint(C_GREEN, 0.5),
           even_odd ? CAIRO_EVENODD : CAIRO_NONZERO);

      //--- the test grid
      for(int gx = 0; gx < 7; gx++)
         for(int gy = 0; gy < 7; gy++)
           {
            const double px = cx - 84 + gx * 28;
            const double py = cy - 84 + gy * 28;

            const bool in = ring.Contains(px, py, even_odd);

            CCairoPath m;

            if(in)
               m.AddCircle(px, py, 4.0);
            else
              {
               m.AddThickLine(px - 3, py - 3, px + 3, py + 3, 1.6);
               m.AddThickLine(px - 3, py + 3, px + 3, py - 3, 1.6);
              }

            Fill(m, in ? C_INK : C_MUTED);
           }
     }
  }

//+-------------------------------------------------------------------+
//| Every panel, in order.                                            |
//+-------------------------------------------------------------------+
void Render()
  {
   g_surface.Clear(C_BACK);

   ClipAll();

   PanelOneClip(COL_L, ROW_1);
   PanelSoftEdge(COL_R, ROW_1);
   PanelPathClip(COL_L, ROW_2);
   PanelBounds(COL_R, ROW_2);
   PanelScrollList(COL_L, ROW_3);
   PanelHitTest(COL_R, ROW_3);

   g_surface.Flush();
  }

//+-------------------------------------------------------------------+
//| The captions. Chart labels, not drawing - Part 9 still has no     |
//| text of its own, and these sit in the panels' own top margin so   |
//| that nothing inside a panel is ever covered by one.               |
//+-------------------------------------------------------------------+
void Captions()
  {

   DemoLabel("a", UI_X + COL_L + 12, UI_Y + ROW_1 + 6,
             "A. one clip", (color)C_INK, 10);
   DemoLabel("b", UI_X + COL_R + 12, UI_Y + ROW_1 + 6,
             "B. a soft edge", (color)C_INK, 10);
   DemoLabel("c", UI_X + COL_L + 12, UI_Y + ROW_2 + 6,
             "C. a path, then two clips", (color)C_INK, 10);
   DemoLabel("d", UI_X + COL_R + 12, UI_Y + ROW_2 + 6,
             "D. Bounds()", (color)C_INK, 10);
   DemoLabel("e", UI_X + COL_L + 12, UI_Y + ROW_3 + 6,
             "E. a scrolling list", (color)C_INK, 10);
   DemoLabel("f", UI_X + COL_R + 12, UI_Y + ROW_3 + 6,
             "F. Contains()", (color)C_INK, 10);
  }

//+-------------------------------------------------------------------+
//| Create the surface, draw once, report.                            |
//+-------------------------------------------------------------------+
int OnInit()
  {
   if(InpSetLightChart)
      DemoUseLightChart();

   if(!g_surface.Create("cairo_demo09", UI_X, UI_Y, UI_W, UI_H))
     {
      Print("Cairo5: failed to create the surface");
      return INIT_FAILED;
     }

   const ulong t0 = GetMicrosecondCount();

   Render();

   const ulong t1 = GetMicrosecondCount();

   if(InpShowCaptions)
      Captions();

   PrintFormat("Cairo5 Part 9: one frame in %d us, %d x %d pixels, "
               "1 chart object", (int)(t1 - t0), UI_W, UI_H);

   ChartRedraw();

   return INIT_SUCCEEDED;
  }

//+-------------------------------------------------------------------+
//| Give everything back.                                             |
//+-------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   g_surface.Destroy();
   g_clip.Release();

   DemoLabelsClear();

   ChartRedraw();
  }

//+-------------------------------------------------------------------+
//| The panel is static; nothing is redrawn on a tick.                |
//+-------------------------------------------------------------------+
void OnTick()
  {
  }
//+-------------------------------------------------------------------+
