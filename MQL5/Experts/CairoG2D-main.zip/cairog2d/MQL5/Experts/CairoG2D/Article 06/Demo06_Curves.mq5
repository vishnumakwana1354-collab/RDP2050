//+------------------------------------------------------------------+
//|                                               Demo06_Curves.mq5  |
//|                              Copyright 2026, Sandro Begashvili   |
//|                   https://www.mql5.com/en/users/sandrobegashvil  |
//|                          Telegram: https://t.me/MrMQL5Developer  |
//|            Cairo-Style Graphics in MQL5 (Part 6) - the only demo |
//|                                                                  |
//|  MAKING THE FLATTENER VISIBLE.                                   |
//|                                                                  |
//|  Every panel draws a curve and then marks the vertices the       |
//|  flattener actually produced, by reading them back with          |
//|  CCairoPath::PointX / PointY - the inspection accessors we added |
//|  in Part 2 for exactly this purpose.                             |
//|                                                                  |
//|  What to look for:                                               |
//|                                                                  |
//|    A. a cubic with its control polygon - the curve is pulled     |
//|       towards the control points and never touches them          |
//|    B. the SAME curve at four tolerances; watch the vertex count  |
//|       in the log collapse while the shape stays convincing       |
//|    C. ADAPTIVE subdivision: the dots CLUSTER where the curve     |
//|       bends and thin out where it is nearly straight             |
//|    D. a quadratic drawn twice - once with QuadTo, once with the  |
//|       hand-converted cubic - landing on identical pixels         |
//|    E. what curves are actually for: real shapes                  |
//|                                                                  |
//|  Attach to any chart. Everything is removed again on deinit.     |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Sandro Begashvili"
#property link      "https://www.mql5.com/en/users/sandrobegashvil"
#property description "Part 6: cubic and quadratic Bezier curves, adaptively flattened"
#property description "Free to use and extend - please credit the author on mql5.com"
#property version   "1.00"
#property strict

#include <CairoG2D/Config.mqh>
#include <CairoG2D/Color.mqh>
#include <CairoG2D/Path.mqh>
#include <CairoG2D/Raster.mqh>
#include <CairoG2D/Surface.mqh>
#include <CairoG2D/DemoTheme.mqh>

#define UI_X      10
#define UI_Y      20
#define UI_W     960
#define UI_H     820

//--- every color is a role from the shared light theme
#define C_BACK    DEMO_BG
#define C_CARD    DEMO_PANEL
#define C_LINE    DEMO_BORDER
#define C_CURVE   DEMO_BLUE
#define C_HULL    DEMO_GREY
#define C_NODE    DEMO_AMBER
#define C_CTRL    DEMO_RED
#define C_GREEN   DEMO_GREEN
#define C_PURPLE  DEMO_INK_SOFT


CCairoSurface    g_surface;
CCairoRasterizer g_ras;

//+------------------------------------------------------------------+
//| Shorthand fill.                                                  |
//+------------------------------------------------------------------+
void Fill(CCairoPath &p, const uint argb,
          const ENUM_CAIRO_FILLRULE rule = CAIRO_NONZERO)
  {
   g_ras.Fill(p, argb, g_surface.m_px,
              g_surface.Width(), g_surface.Height(), rule);
  }

//+------------------------------------------------------------------+
//| A grouping card, with a true ring border (Part 5).               |
//+------------------------------------------------------------------+
void Card(const double x, const double y, const double w, const double h)
  {
   CCairoPath body;
   body.AddRect(x, y, w, h);
   Fill(body, C_CARD);

   CCairoPath edge;
   edge.AddRect(x,     y,     w,     h);
   edge.AddRect(x + 1, y + 1, w - 2, h - 2);
   Fill(edge, C_LINE, CAIRO_EVENODD);
  }

//+------------------------------------------------------------------+
//| DEMO HELPER, not library code.                                   |
//|                                                                  |
//| Draw a path's flattened outline as a stroke.                     |
//|                                                                  |
//| We have no stroker and no circles yet, so each segment becomes a |
//| thick quad (Part 5) and each joint gets a small SQUARE rather    |
//| than a round cap. Everything goes into ONE path and is filled    |
//| ONCE with the non-zero rule, so the joints union cleanly.        |
//+------------------------------------------------------------------+
void StrokeOutline(CCairoPath &src, const double thickness,
                   const uint argb, const bool closed)
  {
   const int n = src.PointCount();

   if(n < 2)
      return;

   CCairoPath stroke;

   const int last = closed ? n : n - 1;

   for(int i = 0; i < last; i++)
     {
      const int j = (i + 1) % n;

      stroke.AddThickLine(src.PointX(i), src.PointY(i),
                          src.PointX(j), src.PointY(j),
                          thickness);
     }

//--- square joints, wound the same way as the quads
   const double h = thickness * 0.5;

   for(int i = 0; i < n; i++)
      stroke.AddRect(src.PointX(i) - h, src.PointY(i) - h,
                     thickness, thickness);

   Fill(stroke, argb);
  }

//+------------------------------------------------------------------+
//| DEMO HELPER. Mark every flattened vertex with a small square.    |
//+------------------------------------------------------------------+
void MarkVertices(CCairoPath &src, const double r, const uint argb)
  {
   CCairoPath dots;

   for(int i = 0; i < src.PointCount(); i++)
      dots.AddRect(src.PointX(i) - r, src.PointY(i) - r,
                   r * 2, r * 2);

   Fill(dots, argb);
  }

//+------------------------------------------------------------------+
//| DEMO HELPER. A dashed guide line, for the control polygon.       |
//+------------------------------------------------------------------+
void GuideLine(const double x0, const double y0,
               const double x1, const double y1, const uint argb)
  {
   const double dx   = x1 - x0;
   const double dy   = y1 - y0;
   const double len  = MathSqrt(dx * dx + dy * dy);
   const int    dash = (int)MathMax(2, len / 9.0);

   CCairoPath p;

   for(int i = 0; i < dash; i += 2)
     {
      const double t0 = (double)i / dash;
      const double t1 = (double)(i + 1) / dash;

      p.AddThickLine(x0 + dx * t0, y0 + dy * t0,
                     x0 + dx * t1, y0 + dy * t1, 1.4);
     }

   Fill(p, argb);
  }

//+------------------------------------------------------------------+
//| A. ANATOMY OF A CUBIC BEZIER                                     |
//|                                                                  |
//| Four points define it. The curve PASSES THROUGH the two green    |
//| endpoints and is PULLED TOWARDS the two red control points, which|
//| it never reaches. The dashed control polygon shows the pull.     |
//+------------------------------------------------------------------+
void PanelAnatomy(const double ox, const double oy)
  {
   Card(ox, oy, 440, 260);

   const double p0x = ox +  40, p0y = oy + 210;
   const double c1x = ox +  70, c1y = oy +  40;
   const double c2x = ox + 340, c2y = oy +  30;
   const double p3x = ox + 400, p3y = oy + 200;

   GuideLine(p0x, p0y, c1x, c1y, C_HULL);
   GuideLine(c1x, c1y, c2x, c2y, C_HULL);
   GuideLine(c2x, c2y, p3x, p3y, C_HULL);

//--- the curve: ONE CurveTo call
   CCairoPath curve;
   curve.MoveTo(p0x, p0y);
   curve.CurveTo(c1x, c1y, c2x, c2y, p3x, p3y);

   StrokeOutline(curve, 3.0, C_CURVE, false);

//--- endpoints: the curve touches these
   CCairoPath ends;
   ends.AddRect(p0x - 5, p0y - 5, 10, 10);
   ends.AddRect(p3x - 5, p3y - 5, 10, 10);
   Fill(ends, C_GREEN);

//--- control points: the curve never touches these
   CCairoPath ctrl;
   ctrl.AddRect(c1x - 5, c1y - 5, 10, 10);
   ctrl.AddRect(c2x - 5, c2y - 5, 10, 10);
   Fill(ctrl, C_CTRL);

   PrintFormat("A. one CurveTo at tolerance %.2f px -> %d vertices",
               CairoFlattenTolerance, curve.PointCount());
  }

//+------------------------------------------------------------------+
//| B. THE SAME CURVE AT FOUR TOLERANCES                             |
//|                                                                  |
//| CairoFlattenTolerance is the maximum deviation, in pixels, that a|
//| segment may have from the true curve.                            |
//|                                                                  |
//| The screen shows the shapes; the LOG shows the real story - the  |
//| vertex counts, which is what the setting actually controls.      |
//+------------------------------------------------------------------+
void PanelTolerance(const double ox, const double oy)
  {
   Card(ox, oy, 440, 260);

   const double saved = CairoFlattenTolerance;

   double tolerances[4] = { 12.0, 3.0, 0.8, 0.05 };
   uint   colors[4];

   colors[0] = C_CTRL;
   colors[1] = C_NODE;
   colors[2] = C_GREEN;
   colors[3] = C_CURVE;

   for(int i = 0; i < 4; i++)
     {
      CairoFlattenTolerance = tolerances[i];

      const double y = oy + 40 + i * 55;

      CCairoPath c;
      c.MoveTo(ox +  30, y + 30);
      c.CurveTo(ox + 140, y - 40, ox + 250, y + 90, ox + 400, y + 10);

      StrokeOutline(c, 2.2, colors[i], false);
      MarkVertices(c, 2.4, CairoWithOpacity(DEMO_INK, 0.75));

      PrintFormat("B. tolerance %5.2f px -> %4d vertices",
                  tolerances[i], c.PointCount());
     }

   CairoFlattenTolerance = saved;
  }

//+------------------------------------------------------------------+
//| C. ADAPTIVE SUBDIVISION                                          |
//|                                                                  |
//| THE FIGURE THAT EXPLAINS THE ALGORITHM.                          |
//|                                                                  |
//| One path with a very tight bend at one end and a nearly straight |
//| run at the other. The dots are the flattener's output.           |
//|                                                                  |
//| They are DENSE in the bend and SPARSE in the straight part,      |
//| because the recursion only splits where the chord test fails. A  |
//| fixed "32 segments per curve" loop would space them evenly -     |
//| wasting segments on the straight part and starving the bend.     |
//+------------------------------------------------------------------+
void PanelAdaptive(const double ox, const double oy)
  {
   Card(ox, oy, 440, 270);

   CCairoPath c;
   c.MoveTo(ox +  30, oy + 240);
   c.CurveTo(ox + 320, oy + 235, ox +  55, oy +  35, ox + 210, oy +  40);
   c.CurveTo(ox + 350, oy +  45, ox + 400, oy + 120, ox + 405, oy + 235);

   StrokeOutline(c, 2.5, C_CURVE, false);
   MarkVertices(c, 3.0, C_NODE);

   PrintFormat("C. adaptive: %d vertices, spaced by curvature not by count",
               c.PointCount());
  }

//+------------------------------------------------------------------+
//| D. QUADRATIC vs CUBIC                                            |
//|                                                                  |
//| A quadratic has ONE control point. QuadTo raises it to an exactly|
//| equivalent cubic:                                                |
//|                                                                  |
//|     C1 = P0 + 2/3 * (Q - P0)                                     |
//|     C2 = P2 + 2/3 * (Q - P2)                                     |
//|                                                                  |
//| Below, the same curve is drawn twice: thick and purple with      |
//| QuadTo, then thin and green with the hand-converted cubic on top.|
//| If the conversion is exact - and it is - the purple never shows  |
//| through along the middle of the green line.                      |
//+------------------------------------------------------------------+
void PanelQuadratic(const double ox, const double oy)
  {
   Card(ox, oy, 440, 270);

   const double p0x = ox +  40, p0y = oy + 220;
   const double qx  = ox + 220, qy  = oy +  30;
   const double p2x = ox + 400, p2y = oy + 220;

   GuideLine(p0x, p0y, qx, qy, C_HULL);
   GuideLine(qx, qy, p2x, p2y, C_HULL);

//--- the quadratic
   CCairoPath q;
   q.MoveTo(p0x, p0y);
   q.QuadTo(qx, qy, p2x, p2y);
   StrokeOutline(q, 6.0, C_PURPLE, false);

//--- the same curve, converted by hand, drawn thinner on top
   const double c1x = p0x + 2.0 / 3.0 * (qx - p0x);
   const double c1y = p0y + 2.0 / 3.0 * (qy - p0y);
   const double c2x = p2x + 2.0 / 3.0 * (qx - p2x);
   const double c2y = p2y + 2.0 / 3.0 * (qy - p2y);

   CCairoPath c;
   c.MoveTo(p0x, p0y);
   c.CurveTo(c1x, c1y, c2x, c2y, p2x, p2y);
   StrokeOutline(c, 2.0, C_GREEN, false);

//--- the single control point
   CCairoPath ctrl;
   ctrl.AddRect(qx - 5, qy - 5, 10, 10);
   Fill(ctrl, C_CTRL);

   PrintFormat("D. QuadTo -> %d vertices, hand-converted cubic -> "
               "%d vertices (identical)",
               q.PointCount(), c.PointCount());
  }

//+------------------------------------------------------------------+
//| E. WHAT CURVES ARE ACTUALLY FOR                                  |
//|                                                                  |
//| Closed, FILLED shapes that were impossible three articles ago.   |
//|                                                                  |
//| A heart, a leaf, a wave-topped card, and a smooth blob - each    |
//| one a handful of CurveTo calls, all of them filled by the same   |
//| rasterizer that has not changed since Part 4.                    |
//+------------------------------------------------------------------+
void PanelShapes(const double ox, const double oy)
  {
   Card(ox, oy, 890, 220);

//--- a heart
   CCairoPath heart;
   heart.MoveTo(ox + 110, oy + 190);
   heart.CurveTo(ox +  10, oy + 120, ox +  25, oy +  40, ox +  75, oy +  40);
   heart.CurveTo(ox + 100, oy +  40, ox + 110, oy +  62, ox + 110, oy +  62);
   heart.CurveTo(ox + 110, oy +  62, ox + 120, oy +  40, ox + 145, oy +  40);
   heart.CurveTo(ox + 195, oy +  40, ox + 210, oy + 120, ox + 110, oy + 190);
   heart.Close();
   Fill(heart, C_CTRL);

//--- a leaf: two curves meeting at two points
   CCairoPath leaf;
   leaf.MoveTo(ox + 260, oy + 180);
   leaf.CurveTo(ox + 250, oy +  60, ox + 330, oy +  30, ox + 400, oy +  40);
   leaf.CurveTo(ox + 410, oy + 110, ox + 360, oy + 180, ox + 260, oy + 180);
   leaf.Close();
   Fill(leaf, C_GREEN);

//--- a card with a wave along its top edge
   CCairoPath wave;
   wave.MoveTo(ox + 450, oy + 190);
   wave.LineTo(ox + 450, oy +  80);
   wave.CurveTo(ox + 505, oy +  20, ox + 565, oy + 130, ox + 620, oy +  70);
   wave.CurveTo(ox + 660, oy +  28, ox + 690, oy +  95, ox + 700, oy +  75);
   wave.LineTo(ox + 700, oy + 190);
   wave.Close();
   Fill(wave, CairoWithOpacity(C_CURVE, 0.85));

//--- a smooth blob, and a ring version of it beside it, to show
//--- curves and fill rules composing
   CCairoPath blob;
   blob.MoveTo(ox + 800, oy +  40);
   blob.CurveTo(ox + 880, oy +  40, ox + 880, oy + 110, ox + 850, oy + 140);
   blob.CurveTo(ox + 820, oy + 170, ox + 740, oy + 160, ox + 745, oy + 100);
   blob.CurveTo(ox + 748, oy +  62, ox + 770, oy +  40, ox + 800, oy +  40);
   blob.Close();

   blob.MoveTo(ox + 800, oy +  70);
   blob.CurveTo(ox + 855, oy +  70, ox + 855, oy + 105, ox + 832, oy + 122);
   blob.CurveTo(ox + 810, oy + 140, ox + 770, oy + 132, ox + 773, oy + 100);
   blob.CurveTo(ox + 776, oy +  80, ox + 782, oy +  70, ox + 800, oy +  70);
   blob.Close();

   Fill(blob, C_PURPLE, CAIRO_EVENODD);
  }

//+------------------------------------------------------------------+
//| Compose                                                          |
//+------------------------------------------------------------------+
void Render()
  {
   g_surface.Clear(C_BACK);

   Print("=== Part 6: curves, flattened at tolerance ",
         CairoFlattenTolerance, " px ===");

   PanelAnatomy(10,  10);
   PanelTolerance(460,  10);
   PanelAdaptive(10, 280);
   PanelQuadratic(460, 280);
   PanelShapes(10, 560);

   g_surface.Flush();
  }

//+------------------------------------------------------------------+
//| The captions. Chart pixels, so UI_X / UI_Y have to be added.     |
//+------------------------------------------------------------------+
void Captions()
  {
   DemoLabel("a", UI_X + 19, UI_Y + 16,
             "A. One CurveTo: green endpoints on it, red controls "
             "off it");

   DemoLabel("b", UI_X + 479, UI_Y + 16,
             "B. Tolerance 12, 3, 0.8 and 0.05 px - counts in the "
             "log");

   DemoLabel("c", UI_X + 19, UI_Y + 286,
             "C. Adaptive: dots cluster in the bend, thin out on "
             "the straight");

   DemoLabel("d", UI_X + 479, UI_Y + 286,
             "D. QuadTo under a hand-converted cubic - nothing "
             "shows through");

   DemoLabel("e", UI_X + 19, UI_Y + 566,
             "E. What curves are for - and the rasterizer never "
             "changed");
  }

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {

   DemoUseLightChart();

   if(!g_surface.Create("cairo_demo06", UI_X, UI_Y, UI_W, UI_H))
     {
      Print("Cairo5: failed to create the surface");
      return INIT_FAILED;
     }

   const ulong t0 = GetMicrosecondCount();
   Render();
   const ulong t1 = GetMicrosecondCount();


   Captions();

   ChartRedraw();

   PrintFormat("whole %dx%d frame in %d us",
               UI_W, UI_H, (int)(t1 - t0));

   return INIT_SUCCEEDED;
  }

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   g_surface.Destroy();
   DemoLabelsClear();
   ChartRedraw();
  }

//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
  }
//+------------------------------------------------------------------+
