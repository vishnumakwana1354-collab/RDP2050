//+------------------------------------------------------------------+
//|                                            Demo02_PathViewer.mq5 |
//|                              Copyright 2026, Sandro Begashvili   |
//|                   https://www.mql5.com/en/users/sandrobegashvil  |
//|                          Telegram: https://t.me/MrMQL5Developer  |
//|            Cairo-Style Graphics in MQL5 (Part 2) - the only demo |
//|                                                                  |
//|  SEEING GEOMETRY WE CANNOT YET FILL.                             |
//|                                                                  |
//|  At this point the library contains three files:                 |
//|                                                                  |
//|      Color.mqh     the ARGB color type                           |
//|      Surface.mqh   a pixel buffer bound to one chart object      |
//|      Path.mqh      points, contours, MoveTo / LineTo / Close     |
//|                                                                  |
//|  A path is pure geometry. It has no color and produces no        |
//|  pixels, so there is nothing in the library that can DRAW one -  |
//|  filling is Part 3.                                              |
//|                                                                  |
//|  What we CAN do is INSPECT a path and plot what it describes.    |
//|  The helpers below - PlotSegment, PlotMarker, PlotPath - live in |
//|  this demo, NOT in the library. They are throwaway debug code,   |
//|  and they are deliberately crude: PlotSegment is a plain         |
//|  interpolation that writes hard-edged pixels, exactly the kind   |
//|  of per-shape drawing routine this library exists to avoid.      |
//|                                                                  |
//|  Attach to any chart. Everything is removed again on deinit.     |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Sandro Begashvili"
#property link      "https://www.mql5.com/en/users/sandrobegashvil"
#property description "Part 2: paths, contours and vertices, as an inspectable wireframe"
#property description "Free to use and extend - please credit the author's mql5.com profile"
#property version   "1.00"
#property strict

#include "include/Cairo/Color.mqh"
#include "include/Cairo/Path.mqh"
#include "include/Cairo/Surface.mqh"
#include "include/DemoTheme.mqh"

//--- panel geometry, in chart pixels from the upper-left corner
#define UI_X      40
#define UI_Y      40
#define UI_W     900
#define UI_H     560

//+-------------------------------------------------------------------+
//| THE WIREFRAME PALETTE.                                            |
//|                                                                   |
//| Every color here is a role from DemoTheme.mqh, so this demo says  |
//| the same things with color that every other demo in the series    |
//| does. Only the grid is local: it has to be lighter than anything  |
//| in the shared palette, because it must sit behind the geometry    |
//| without competing with it.                                        |
//+-------------------------------------------------------------------+
#define C_GRID    CairoRgb( 231, 235, 239 )   // the faint measuring grid
#define C_EDGE    DEMO_BLUE                   // a segment the path stored
#define C_CLOSE   DEMO_RED                    // the closing segment of a closed contour
#define C_VERTEX  DEMO_AMBER                  // every vertex
#define C_START   DEMO_GREEN                  // the first vertex of a contour

//--- captions are annotation for the article figures, not drawing.
//--- Turn them off and the panel is still exactly one chart object.
input bool InpShowCaptions  = true;           // Draw the explanatory captions
input bool InpSetLightChart = true;           // Switch the chart to Black On White

CCairoSurface g_surface;

//+-------------------------------------------------------------------+
//| Write one pixel (unchanged from Part 1).                          |
//+-------------------------------------------------------------------+
void SetPixel(const int x, const int y, const uint argb)
  {
   if(x < 0 || y < 0 || x >= g_surface.Width() || y >= g_surface.Height())
      return;

   g_surface.m_px[ y * g_surface.Width() + x ] = argb;
  }

//+-------------------------------------------------------------------+
//| DEMO CODE, NOT LIBRARY CODE.                                      |
//|                                                                   |
//| Plot a straight segment by stepping along it and rounding to the  |
//| nearest pixel. Hard-edged and ugly on a diagonal - which is       |
//| honest, because that is what a naive plot looks like.             |
//+-------------------------------------------------------------------+
void PlotSegment(const double x0, const double y0,
                 const double x1, const double y1, const uint argb)
  {
   const double dx = x1 - x0;
   const double dy = y1 - y0;

//--- step once per pixel along the longer axis
   const int steps = (int)MathMax(MathAbs(dx), MathAbs(dy)) + 1;

   for(int i = 0; i <= steps; i++)
     {
      const double t = (double)i / steps;

      SetPixel((int)MathRound(x0 + dx * t),
               (int)MathRound(y0 + dy * t), argb);
     }
  }

//+-------------------------------------------------------------------+
//| DEMO CODE. A small filled square, to mark a vertex.               |
//+-------------------------------------------------------------------+
void PlotMarker(const double cx, const double cy, const int r, const uint argb)
  {
   for(int y = -r; y <= r; y++)
      for(int x = -r; x <= r; x++)
         SetPixel((int)MathRound(cx) + x,
                  (int)MathRound(cy) + y, argb);
  }

//+-------------------------------------------------------------------+
//| THE HEART OF THIS DEMO.                                           |
//|                                                                   |
//| Walk a path contour by contour and plot what it describes:        |
//|                                                                   |
//|    * every stored segment, in blue                                |
//|    * the closing segment, in red - drawn only for contours the    |
//|      author actually closed. The path never stored that segment;  |
//|      it stored the FACT that the contour is closed, and this is   |
//|      the difference made visible                                  |
//|    * every vertex, in amber                                       |
//|    * the FIRST vertex of each contour, in green - so you can see  |
//|      exactly where each MoveTo happened                           |
//|                                                                   |
//| Notice that this function knows nothing about rectangles, stars   |
//| or glyphs. It only knows about contours and vertices. That is the |
//| first hint of the design pay-off: once geometry is uniform,       |
//| everything downstream stops caring what shape it came from.       |
//|                                                                   |
//| WHY THE CHECKED ACCESSORS HERE                                    |
//|                                                                   |
//| Every index below could be handed to the fast PointX / PointY     |
//| pair instead, and they would all be in range. This function uses  |
//| GetContourInfo and GetPoint anyway, because that is the honest    |
//| model for code that receives a path it did not build: ask, and be |
//| told no. The rasteriser in Part 3 walks the arrays with the fast  |
//| pair, and it has earned the right to - it built the loop bounds   |
//| itself. Copy this function, not that one, when you write your own |
//| tools on top of a path.                                           |
//+-------------------------------------------------------------------+
void PlotPath(CCairoPath &path)
  {
//--- two questions worth asking once, before drawing anything.
//--- A path that failed to allocate is short of vertices; a path
//--- carrying a NaN plots as a shape that silently is not there.
   if(!path.IsValid())
     {
      Print("PlotPath: incomplete path - an allocation was refused");
      return;
     }

   if(!path.IsFinite())
     {
      Print("PlotPath: the path holds a coordinate that is not a number");
      return;
     }

   int  start  = 0;
   int  count  = 0;
   bool closed = false;

   SCairoPoint a, b;

   for(int c = 0; c < path.ContourCount(); c++)
     {
      //--- where does this contour start, how long is it, was it closed
      if(!path.GetContourInfo(c, start, count, closed))
         continue;

      if(count < 2)
         continue;

      //--- the stored segments
      for(int i = 0; i < count - 1; i++)
         if(path.GetPoint(start + i, a) && path.GetPoint(start + i + 1, b))
            PlotSegment(a.x, a.y, b.x, b.y, C_EDGE);

      //--- the closing segment, drawn only because Close() was called
      if(closed)
         if(path.GetPoint(start + count - 1, a) && path.GetPoint(start, b))
            PlotSegment(a.x, a.y, b.x, b.y, C_CLOSE);

      //--- the vertices
      for(int i = 1; i < count; i++)
         if(path.GetPoint(start + i, a))
            PlotMarker(a.x, a.y, 2, C_VERTEX);

      //--- and where this contour began
      if(path.GetPoint(start, a))
         PlotMarker(a.x, a.y, 3, C_START);
     }
  }

//+-------------------------------------------------------------------+
//| A faint background grid, so positions can be judged by eye.       |
//+-------------------------------------------------------------------+
void PlotGrid(const int step)
  {
   for(int x = 0; x < g_surface.Width(); x += step)
      for(int y = 0; y < g_surface.Height(); y++)
         SetPixel(x, y, C_GRID);

   for(int y = 0; y < g_surface.Height(); y += step)
      for(int x = 0; x < g_surface.Width(); x++)
         SetPixel(x, y, C_GRID);
  }

//+-------------------------------------------------------------------+
//| A. THE SIMPLEST PATH                                              |
//|                                                                   |
//| One rectangle: one MoveTo, three LineTo calls and a Close. Four   |
//| vertices, one contour - and a red segment that no vertex          |
//| describes, drawn because the contour is marked closed.            |
//+-------------------------------------------------------------------+
void CaseRect(const double ox, const double oy)
  {
   CCairoPath p;
   p.AddRect(ox, oy, 170, 110);

   PlotPath(p);

   PrintFormat("A. rectangle       : %d contour(s), %d vertices",
               p.ContourCount(), p.PointCount());

//--- what Close() left behind: the pen is back at the first vertex,
//--- and it is lifted, so the next LineTo would open a new contour
   PrintFormat("     after Close(): pen at %.1f, %.1f  pen down = %s",
               p.CurrentX(), p.CurrentY(),
               p.HasCurrentPoint() ? "true" : "false");
  }

//+-------------------------------------------------------------------+
//| B. AN ARBITRARY POLYGON                                           |
//|                                                                   |
//| Ten computed vertices make a five-pointed star. The library has   |
//| no idea what a star is - it received ten points and stored them.  |
//+-------------------------------------------------------------------+
void CaseStar(const double ox, const double oy)
  {
   double xs[10], ys[10];

   for(int i = 0; i < 10; i++)
     {
      const double r = (i % 2 == 0) ? 68.0 : 28.0;
      const double a = -M_PI * 0.5 + M_PI * i / 5.0;

      xs[i] = ox + 85 + r * MathCos(a);
      ys[i] = oy + 75 + r * MathSin(a);
     }

   CCairoPath p;
   p.AddPolygon(xs, ys, 10);

   PlotPath(p);

   PrintFormat("B. star            : %d contour(s), %d vertices",
               p.ContourCount(), p.PointCount());
  }

//+-------------------------------------------------------------------+
//| C. TWO CONTOURS IN ONE PATH                                       |
//|                                                                   |
//| THE IMPORTANT CASE.                                               |
//|                                                                   |
//| Two rectangles, one inside the other, in a SINGLE path. Two green |
//| markers mean two MoveTo calls, and therefore two contours.        |
//|                                                                   |
//| Right now this is just two outlines. In Part 3 it becomes a solid |
//| block; in Part 5, with the even-odd rule, the same path becomes a |
//| frame with a genuine hole through the middle. The geometry does   |
//| not change at all - only the rule used to interpret it.           |
//+-------------------------------------------------------------------+
void CaseTwoContours(const double ox, const double oy)
  {
   CCairoPath p;

//--- two contours, eight vertices, and we know it before we start
   p.ReserveContours(2);
   p.ReservePoints(8);

   p.AddRect(ox,      oy,      190, 130);
   p.AddRect(ox + 22, oy + 22, 146,  86);

   PlotPath(p);

   PrintFormat("C. frame           : %d contour(s), %d vertices"
               "  <- one path, two outlines",
               p.ContourCount(), p.PointCount());

   for(int c = 0; c < p.ContourCount(); c++)
      PrintFormat("     contour %d: starts at index %d, %d vertices, closed = %s",
                  c, p.ContourStart(c), p.ContourLength(c),
                  p.IsContourClosed(c) ? "true" : "false");
  }

//+-------------------------------------------------------------------+
//| D. A MULTI-PART GLYPH                                             |
//|                                                                   |
//| The letter "A": an outer outline plus the triangular counter. A   |
//| font glyph is exactly this and nothing more, which is why the     |
//| same storage will eventually be able to render text.              |
//+-------------------------------------------------------------------+
void CaseGlyph(const double ox, const double oy)
  {
   CCairoPath p;

//--- outer outline
   p.MoveTo(ox +  70, oy +   8);
   p.LineTo(ox + 128, oy + 140);
   p.LineTo(ox + 100, oy + 140);
   p.LineTo(ox +  88, oy + 110);
   p.LineTo(ox +  52, oy + 110);
   p.LineTo(ox +  40, oy + 140);
   p.LineTo(ox +  12, oy + 140);
   p.Close();

//--- the counter - the hole in the middle of the A
   p.MoveTo(ox +  60, oy +  86);
   p.LineTo(ox +  80, oy +  86);
   p.LineTo(ox +  70, oy +  50);
   p.Close();

   PlotPath(p);

   PrintFormat("D. glyph 'A'       : %d contour(s), %d vertices",
               p.ContourCount(), p.PointCount());
  }

//+-------------------------------------------------------------------+
//| E. SUB-PIXEL COORDINATES ARE REAL                                 |
//|                                                                   |
//| Six identical small rectangles, each shifted a further 1/6 of a   |
//| pixel to the right. The PATH stores those positions exactly.      |
//|                                                                   |
//| Our crude plotter rounds them away, so on screen several of them  |
//| land on the same pixel column - which is the limitation Part 4    |
//| removes. The log tells the truth that the pixels cannot.          |
//|                                                                   |
//| This case also shows the intended way to reuse a path. ONE path   |
//| object is built six times: Clear() empties it without giving the  |
//| memory back, so the first rectangle pays for the allocation and   |
//| the other five reuse it. That is exactly the pattern an EA that   |
//| redraws on every tick should follow. Release() at the end is the  |
//| opposite call, and it is only right here because this path is     |
//| genuinely finished with.                                          |
//+-------------------------------------------------------------------+
void CaseSubPixel(const double ox, const double oy)
  {
   Print("E. sub-pixel offsets stored in the path:");

   CCairoPath p;

   for(int i = 0; i < 6; i++)
     {
      const double x = ox + i * 40 + i / 6.0;

      p.Clear();                      // reset the geometry, keep the memory
      p.AddRect(x, oy, 26, 90);

      PlotPath(p);

      //--- index 0 is the vertex AddRect just wrote, so the fast
      //--- unchecked accessor is safe here by construction
      PrintFormat("     rect %d: x = %.4f  (plotted at pixel column %d)",
                  i, p.PointX(0), (int)MathRound(p.PointX(0)));
     }

   p.Release();                        // done with it - hand the memory back
  }

//+-------------------------------------------------------------------+
//| F. AN OPEN CONTOUR                                                |
//|                                                                   |
//| A path does NOT have to be a closed shape. Close() is simply      |
//| never called here, and the path REMEMBERS that: no red segment    |
//| appears, and nothing in this demo had to be told to leave it out. |
//| Compare with case A, where four vertices and one Close produce a  |
//| fifth, unstored side.                                             |
//|                                                                   |
//| Every price series drawn as a line is this shape.                 |
//+-------------------------------------------------------------------+
void CaseOpenPolyline(const double ox, const double oy)
  {
   CCairoPath wave;
   wave.ReservePoints(23);            // we know the count in advance

   wave.MoveTo(ox, oy);

   for(int i = 1; i <= 22; i++)
      wave.LineTo(ox + i * 11, oy + MathSin(i * 0.55) * 52);

//--- no Close() here, deliberately

   PlotPath(wave);

   PrintFormat("F. open polyline   : %d contour(s), %d vertices, closed = %s",
               wave.ContourCount(), wave.PointCount(),
               wave.IsContourClosed(0) ? "true" : "false");
  }

//+-------------------------------------------------------------------+
//| G. THE SAME VERTICES, TWO WAYS                                    |
//|                                                                   |
//| AddPolyline and AddPolygon are handed identical arrays. The only  |
//| difference between them is a single Close() inside the library,   |
//| and the result is two contours in one path that share a shape and |
//| disagree about what it means:                                     |
//|                                                                   |
//|    the upper zig-zag  - AddPolyline, open, no red segment         |
//|    the lower zig-zag  - AddPolygon, closed, red segment across    |
//|                                                                   |
//| This is the whole open-versus-closed distinction in one picture.  |
//| Nothing about the vertices says which is which; the path stores   |
//| the answer because the caller stated it.                          |
//+-------------------------------------------------------------------+
void CasePolylineVsPolygon(const double ox, const double oy)
  {
   double xs[5], ys[5];

   for(int i = 0; i < 5; i++)
     {
      xs[i] = ox + i * 55;
      ys[i] = oy + ((i % 2 == 0) ? -34.0 : 0.0);
     }

   CCairoPath p;
   p.ReserveContours(2);
   p.ReservePoints(10);

//--- open: the vertices, and nothing else
   p.AddPolyline(xs, ys, 5);

//--- the same five vertices, shifted down and closed this time
   for(int i = 0; i < 5; i++)
      ys[i] += 90.0;

   p.AddPolygon(xs, ys, 5);

   PlotPath(p);

   int  start, count;
   bool closed;

   PrintFormat("G. polyline+polygon: %d contour(s), %d vertices",
               p.ContourCount(), p.PointCount());

   for(int c = 0; c < p.ContourCount(); c++)
      if(p.GetContourInfo(c, start, count, closed))
         PrintFormat("     contour %d: %d vertices from index %d, closed = %s  <- %s",
                     c, count, start, closed ? "true" : "false",
                     closed ? "AddPolygon" : "AddPolyline");
  }

//+-------------------------------------------------------------------+
//| Compose the frame.                                                |
//|                                                                   |
//| Every call below writes into memory. Exactly one line - the final |
//| Flush - touches the terminal.                                     |
//+-------------------------------------------------------------------+
void Render()
  {
   g_surface.Clear(DEMO_BG);
   PlotGrid(20);

   Print("=== Part 2: paths built, nothing filled ===");

   CaseRect(40,  46);
   CaseStar(260,  46);
   CaseTwoContours(470,  40);
   CaseGlyph(700,  30);
   CaseSubPixel(40, 246);
   CaseOpenPolyline(320, 430);
   CasePolylineVsPolygon(600, 420);

   g_surface.Flush();
  }

//+-------------------------------------------------------------------+
//| The captions, positioned by adding the panel origin to a          |
//| panel-relative coordinate, so each label follows its region.      |
//+-------------------------------------------------------------------+
void Captions()
  {
   DemoLabel("a", UI_X +  40, UI_Y +  20, "A. Rectangle - 1 contour");
   DemoLabel("b", UI_X + 260, UI_Y +  20, "B. Star - 10 vertices");
   DemoLabel("c", UI_X + 470, UI_Y +  14, "C. Frame - 2 contours");
   DemoLabel("d", UI_X + 700, UI_Y +  10, "D. Glyph 'A' - 2 contours");

   DemoLabel("e", UI_X +  40, UI_Y + 218,
             "E. Sub-pixel offsets: each rectangle is 1/6 px further right");

   DemoLabel("f", UI_X + 320, UI_Y + 356,
             "F. Open contour - no Close()");

   DemoLabel("g", UI_X + 600, UI_Y + 356,
             "G. AddPolyline vs AddPolygon");

   DemoLabel("k1", UI_X +  40, UI_Y + 388, "blue: a stored segment",
             DEMO_BLUE,  8);
   DemoLabel("k2", UI_X +  40, UI_Y + 406, "red: the closing segment - Close() was called",
             DEMO_RED,   8);
   DemoLabel("k3", UI_X +  40, UI_Y + 424, "amber: a vertex",
             DEMO_AMBER, 8);
   DemoLabel("k4", UI_X +  40, UI_Y + 442, "green: the first vertex - a MoveTo",
             DEMO_GREEN, 8);
  }

//+-------------------------------------------------------------------+
//| Expert initialization function                                    |
//+-------------------------------------------------------------------+
int OnInit()
  {
   if(InpSetLightChart)
      DemoUseLightChart();

   if(!g_surface.Create("cairo_demo02", UI_X, UI_Y, UI_W, UI_H))
     {
      Print("Cairo5: failed to create the surface");
      return INIT_FAILED;
     }

   Render();

   if(InpShowCaptions)
      Captions();

   ChartRedraw();

   return INIT_SUCCEEDED;
  }

//+-------------------------------------------------------------------+
//| Expert deinitialization function                                  |
//+-------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   g_surface.Destroy();
   DemoLabelsClear();
   ChartRedraw();
  }

//+-------------------------------------------------------------------+
//| Expert tick function                                              |
//+-------------------------------------------------------------------+
void OnTick()
  {
  }
//+-------------------------------------------------------------------+
