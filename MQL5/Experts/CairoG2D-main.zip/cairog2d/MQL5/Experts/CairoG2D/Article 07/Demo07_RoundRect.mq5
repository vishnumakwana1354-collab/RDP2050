//+------------------------------------------------------------------+
//|                                            Demo07_RoundRect.mq5  |
//|                              Copyright 2026, Sandro Begashvili   |
//|                   https://www.mql5.com/en/users/sandrobegashvil  |
//|                          Telegram: https://t.me/MrMQL5Developer  |
//|            Cairo-Style Graphics in MQL5 (Part 7) - the only demo |
//|                                                                  |
//|  THE SHAPES AN INTERFACE IS ACTUALLY MADE OF.                    |
//|                                                                  |
//|  The geometry layer is finished after this article. Panels:      |
//|                                                                  |
//|    A. the corner matrix - nine tiles, nine radius combinations,  |
//|       each ONE AddRoundRect call                                 |
//|    B. the radius clamp, with the radius actually used drawn      |
//|       underneath each bar                                        |
//|    C. arcs: the same sweep at three radii, plus the segment      |
//|       counts the sagitta formula chose                           |
//|    D. circles, rings, pie slices, gauges and a donut             |
//|    E. real widgets: tabs, buttons, a segmented control, progress |
//|       bars, a toast, chat bubbles, badges                        |
//|                                                                  |
//|  Everything here is built from AddRoundRect, AddCircle, ArcTo and|
//|  the two fill rules. There is no widget code in the library and  |
//|  there never will be.                                            |
//|                                                                  |
//|  Attach to any chart. Everything is removed again on deinit.     |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Sandro Begashvili"
#property link      "https://www.mql5.com/en/users/sandrobegashvil"
#property description "Part 7: arcs, circles and rounded rectangles, one radius per corner"
#property description "Free to use and extend - please credit the author on mql5.com"
#property version   "1.00"
#property strict

#include <CairoG2D/Config.mqh>
#include <CairoG2D/Color.mqh>
#include <CairoG2D/Path.mqh>
#include <CairoG2D/Raster.mqh>
#include <CairoG2D/Surface.mqh>
#include <CairoG2D/DemoTheme.mqh>

#define UI_X      10
#define UI_Y      20
#define UI_W     980
#define UI_H     880

//--- every color is a role from the shared light theme
#define C_BACK    DEMO_BG
#define C_CARD    DEMO_PANEL
#define C_LINE    DEMO_BORDER
#define C_BLUE    DEMO_BLUE
#define C_GREEN   DEMO_GREEN
#define C_AMBER   DEMO_AMBER
#define C_RED     DEMO_RED
#define C_PURPLE  DEMO_INK_SOFT
#define C_MUTED   DEMO_GREY

//--- captions are annotation for the article figures, not drawing.
//--- Turn them off and the panel is still exactly one chart object.
input bool InpShowCaptions  = true;   // Draw the explanatory captions
input bool InpSetLightChart = true;   // Switch the chart to Black On White

CCairoSurface    g_surface;
CCairoRasterizer g_ras;

//+------------------------------------------------------------------+
//| Shorthand fill.                                                  |
//+------------------------------------------------------------------+
void Fill(CCairoPath &p, const uint argb,
          const ENUM_CAIRO_FILLRULE rule = CAIRO_NONZERO)
  {
   g_ras.Fill(p, argb, g_surface.m_px,
              g_surface.Width(), g_surface.Height(), rule);
  }

//+------------------------------------------------------------------+
//| A rounded rectangle with a TRUE ring border.                     |
//|                                                                  |
//| One path, two outlines, even-odd - the Part 5 technique, now with|
//| rounded corners.                                                 |
//|                                                                  |
//| Note the inner radii are reduced by the border width. Concentric |
//| rounded rectangles need CONCENTRIC radii: keep the same radius on|
//| both and the corner band comes out thicker than the straight     |
//| band, which is subtle but visible.                               |
//+------------------------------------------------------------------+
void RoundRectBordered(const double x, const double y,
                       const double w, const double h,
                       const double r_tl, const double r_tr,
                       const double r_br, const double r_bl,
                       const uint fill_argb, const uint border_argb,
                       const double bw = 1.5)
  {
   if(CAIRO_A(fill_argb) > 0)
     {
      CCairoPath body;
      body.AddRoundRect(x, y, w, h, r_tl, r_tr, r_br, r_bl);
      Fill(body, fill_argb);
     }

   CCairoPath edge;
   edge.AddRoundRect(x, y, w, h, r_tl, r_tr, r_br, r_bl);
   edge.AddRoundRect(x + bw, y + bw, w - bw * 2, h - bw * 2,
                     MathMax(0.0, r_tl - bw),
                     MathMax(0.0, r_tr - bw),
                     MathMax(0.0, r_br - bw),
                     MathMax(0.0, r_bl - bw));
   Fill(edge, border_argb, CAIRO_EVENODD);
  }

//+------------------------------------------------------------------+
//| A grouping card.                                                 |
//+------------------------------------------------------------------+
void Card(const double x, const double y, const double w, const double h)
  {
   RoundRectBordered(x, y, w, h, 10, 10, 10, 10, C_CARD, C_LINE, 1.0);
  }

//+------------------------------------------------------------------+
//| A. THE CORNER MATRIX                                             |
//|                                                                  |
//| Nine tiles, nine different combinations of the four radii, every |
//| one of them a SINGLE AddRoundRect call.                          |
//|                                                                  |
//| Corner order is CSS order: top-left, top-right, bottom-right,    |
//| bottom-left.                                                     |
//+------------------------------------------------------------------+
void PanelCornerMatrix(const double ox, const double oy)
  {
   Card(ox, oy, 400, 325);

   double radii[9][4];

//--- row 1: the classics
   radii[0][0] =  0;
   radii[0][1] =  0;
   radii[0][2] =  0;
   radii[0][3] =  0;   // square
   radii[1][0] =  8;
   radii[1][1] =  8;
   radii[1][2] =  8;
   radii[1][3] =  8;   // card
   radii[2][0] = 26;
   radii[2][1] = 26;
   radii[2][2] = 26;
   radii[2][3] = 26;   // very round

//--- row 2: one side only
   radii[3][0] = 20;
   radii[3][1] = 20;
   radii[3][2] =  0;
   radii[3][3] =  0;   // tab
   radii[4][0] =  0;
   radii[4][1] =  0;
   radii[4][2] = 20;
   radii[4][3] = 20;   // bottom tab
   radii[5][0] = 20;
   radii[5][1] =  0;
   radii[5][2] =  0;
   radii[5][3] = 20;   // left cap

//--- row 3: asymmetric
   radii[6][0] = 24;
   radii[6][1] =  4;
   radii[6][2] = 24;
   radii[6][3] =  4;   // leaf
   radii[7][0] = 18;
   radii[7][1] = 18;
   radii[7][2] = 18;
   radii[7][3] =  0;   // chat bubble
   radii[8][0] =  0;
   radii[8][1] = 22;
   radii[8][2] =  0;
   radii[8][3] = 22;   // ticket

   uint cols[9];

   cols[0] = C_MUTED;
   cols[1] = C_BLUE;
   cols[2] = C_PURPLE;
   cols[3] = C_GREEN;
   cols[4] = C_GREEN;
   cols[5] = C_AMBER;
   cols[6] = C_RED;
   cols[7] = C_BLUE;
   cols[8] = C_PURPLE;

   const double tw = 120, th = 90, gap = 8;

   for(int i = 0; i < 9; i++)
     {
      const double tx = ox + 12 + (i % 3) * (tw + gap);
      const double ty = oy + 25 + (i / 3) * (th + gap);

      RoundRectBordered(tx, ty, tw, th,
                        radii[i][0], radii[i][1],
                        radii[i][2], radii[i][3],
                        CairoWithOpacity(cols[i], 0.18),
                        cols[i], 2.0);
     }
  }

//+------------------------------------------------------------------+
//| B. THE RADIUS CLAMP                                              |
//|                                                                  |
//| Six bars, all 38 pixels tall, asking for radii of 0, 8, 16, 24,  |
//| 40 and 500.                                                      |
//|                                                                  |
//| Under each one, an amber marker whose LENGTH is the radius that  |
//| was actually used. Half the height is 19, so the last THREE are  |
//| identical - 24, 40 and 500 all come out at 19 - and none of them |
//| is broken. Without the clamp, the 500 case would self-intersect  |
//| and fill a bow-tie.                                              |
//+------------------------------------------------------------------+
void PanelClamp(const double ox, const double oy)
  {
   Card(ox, oy, 400, 325);

   double asked[6] = { 0, 8, 16, 24, 40, 500 };

   for(int i = 0; i < 6; i++)
     {
      const double y = oy + 24 + i * 50;

      RoundRectBordered(ox + 10, y, 370, 38,
                        asked[i], asked[i], asked[i], asked[i],
                        CairoWithOpacity(C_BLUE, 0.16),
                        C_BLUE, 2.0);

      //--- the radius the clamp actually allowed
      const double used = MathMin(asked[i], MathMin(380.0, 38.0) * 0.5);

      CCairoPath bar;
      bar.AddRect(ox + 24, y + 42, MathMax(used, 1.0), 3);
      Fill(bar, C_AMBER);

      PrintFormat("B. asked for r = %5.0f  ->  used %5.1f", asked[i], used);
     }
  }

//+------------------------------------------------------------------+
//| C. ARCS AND THE SAGITTA                                          |
//|                                                                  |
//| The same 90-degree sweep at three radii. The segment count comes |
//| from the sagitta formula, not from a guess, so all three are     |
//| equally smooth - and the log shows how differently they are      |
//| subdivided to achieve that.                                      |
//+------------------------------------------------------------------+
void PanelArcs(const double ox, const double oy)
  {
   Card(ox, oy, 400, 250);

   double radii[3] = { 30.0, 60.0, 100.0 };
   uint   cols[3];

   cols[0] = C_GREEN;
   cols[1] = C_AMBER;
   cols[2] = C_BLUE;

//--- three quarter-arcs sharing a center, drawn as bands
   for(int i = 0; i < 3; i++)
     {
      const double r = radii[i];

      CCairoPath band;
      band.MoveTo(ox + 40 + r, oy + 220);
      band.ArcTo(ox + 40, oy + 220, r, 0.0, -90.0);
      band.LineTo(ox + 40, oy + 220 - (r - 8));
      band.ArcTo(ox + 40, oy + 220, r - 8, -90.0, 0.0);
      band.Close();

      Fill(band, cols[i]);

      //--- how many vertices did the formula choose?
      CCairoPath probe;
      probe.MoveTo(ox + 40 + r, oy + 220);
      probe.ArcTo(ox + 40, oy + 220, r, 0.0, -90.0);

      PrintFormat("C. arc r = %5.1f px, 90 deg -> %d vertices",
                  r, probe.PointCount());
     }

//--- and a full circle, which is the same machinery closed up
   CCairoPath circ;
   circ.AddCircle(ox + 270, oy + 130, 80);
   Fill(circ, CairoWithOpacity(C_PURPLE, 0.35));

   PrintFormat("C. circle r = 80 px -> %d vertices", circ.PointCount());

//--- the same circle at a deliberately coarse tolerance, so the
//--- facets are visible and the setting is not just a number
   const double saved = CairoFlattenTolerance;
   CairoFlattenTolerance = 6.0;

   CCairoPath coarse;
   coarse.AddCircle(ox + 270, oy + 130, 46);
   Fill(coarse, C_PURPLE);

   PrintFormat("C. same circle at tolerance 6.0 px -> %d vertices "
               "(visibly faceted)",
               coarse.PointCount());

   CairoFlattenTolerance = saved;
  }

//+------------------------------------------------------------------+
//| D. RINGS, GAUGES AND A DONUT                                     |
//|                                                                  |
//| A progress ring is a full ring (two circles, even-odd) plus a    |
//| value BAND: sweep the outer radius forward, then the inner radius|
//| backward, and close. No stroker required, and the same trick     |
//| makes every donut segment.                                       |
//+------------------------------------------------------------------+
void ArcBand(const double cx, const double cy,
             const double r_out, const double r_in,
             const double deg_from, const double deg_to,
             const uint argb)
  {
   CCairoPath band;

   band.MoveTo(cx + r_out * MathCos(deg_from * M_PI / 180.0),
               cy + r_out * MathSin(deg_from * M_PI / 180.0));
   band.ArcTo(cx, cy, r_out, deg_from, deg_to);
   band.LineTo(cx + r_in * MathCos(deg_to * M_PI / 180.0),
               cy + r_in * MathSin(deg_to * M_PI / 180.0));
   band.ArcTo(cx, cy, r_in, deg_to, deg_from);
   band.Close();

   Fill(band, argb);
  }

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void PanelGauges(const double ox, const double oy)
  {
   Card(ox, oy, 400, 250);

//--- three progress rings
   double fracs[3] = { 0.74, 0.42, 0.95 };
   uint   cols[3];

   cols[0] = C_GREEN;
   cols[1] = C_AMBER;
   cols[2] = C_BLUE;

   for(int i = 0; i < 3; i++)
     {
      const double cx = ox + 80 + i * 110;
      const double cy = oy + 90;

      //--- the unfilled track
      CCairoPath track;
      track.AddCircle(cx, cy, 44);
      track.AddCircle(cx, cy, 34);
      Fill(track, C_LINE, CAIRO_EVENODD);

      //--- the value band, starting at 12 o'clock
      ArcBand(cx, cy, 44, 34, -90.0,
              -90.0 + 360.0 * fracs[i], cols[i]);
     }

//--- a donut chart underneath
   const double dcx = ox + 215;
   const double dcy = oy + 195;

   ArcBand(dcx, dcy, 48, 28,  -90,   30, C_BLUE);
   ArcBand(dcx, dcy, 48, 28,   30,  140, C_GREEN);
   ArcBand(dcx, dcy, 48, 28,  140,  225, C_PURPLE);
   ArcBand(dcx, dcy, 48, 28,  225,  270, C_RED);
  }

//+------------------------------------------------------------------+
//| E. REAL WIDGETS FROM ONE PRIMITIVE                               |
//|                                                                  |
//| Everything below is AddRoundRect plus the even-odd rule. There is|
//| no widget code in the library, and there never will be - a       |
//| "button" is a rounded rectangle that someone decided to call a   |
//| button.                                                          |
//+------------------------------------------------------------------+
void PanelWidgets(const double ox, const double oy)
  {
   Card(ox, oy, 810, 240);


//--- Tabs: rounded on top only, the active one flush with the
//--- content area below it.

   const double tab_y = oy + 22;

   for(int i = 0; i < 4; i++)
     {
      const double tx     = ox + 14 + i * 76;
      const bool   active = (i == 1);

      CCairoPath tab;
      tab.AddRoundRect(tx, active ? tab_y : tab_y + 4, 70,
                       active ? 40 : 36, 10, 10, 0, 0);
      Fill(tab, active ? C_CARD
           : CairoWithOpacity(C_MUTED, 0.18));

      if(active)
        {
         CCairoPath stripe;
         stripe.AddRoundRect(tx, tab_y, 70, 3, 3, 3, 0, 0);
         Fill(stripe, C_BLUE);
        }
     }

//--- the content area the tabs sit on: square where they meet it
   RoundRectBordered(ox + 14, tab_y + 40, 298, 60, 0, 0, 8, 8,
                     C_CARD, C_LINE, 1.0);


//--- Buttons: filled, outlined, and pill-shaped.

   const double btn_y = tab_y + 110;

   CCairoPath primary;
   primary.AddRoundRect(ox + 14, btn_y, 90, 40, 8);
   Fill(primary, C_BLUE);

//--- an outlined button: no fill at all, so the card shows through
   RoundRectBordered(ox + 118, btn_y, 90, 40, 8, 8, 8, 8,
                     CAIRO_TRANSPARENT, C_BLUE, 1.5);

//--- a pill: radius clamped to half the height
   CCairoPath pill;
   pill.AddRoundRect(ox + 222, btn_y, 90, 40, 999);
   Fill(pill, C_GREEN);


//--- A segmented control and progress bars.

   const double seg_x = ox + 420;

   CCairoPath track;
   track.AddRoundRect(seg_x, tab_y, 280, 36, 10);
   Fill(track, CairoWithOpacity(C_MUTED, 0.18));

   CCairoPath sel;
   sel.AddRoundRect(seg_x + 98, tab_y + 3, 84, 30, 8);
   Fill(sel, C_BLUE);

   double progress[3] = { 0.72, 0.45, 0.93 };
   uint   pcols[3];

   pcols[0] = C_GREEN;
   pcols[1] = C_AMBER;
   pcols[2] = C_BLUE;

   for(int i = 0; i < 3; i++)
     {
      const double py = tab_y + 54 + i * 26;

      CCairoPath ptrack;
      ptrack.AddRoundRect(seg_x, py, 280, 12, 6);
      Fill(ptrack, CairoWithOpacity(C_MUTED, 0.25));

      CCairoPath pfill;
      pfill.AddRoundRect(seg_x, py, 280 * progress[i], 12, 6);
      Fill(pfill, pcols[i]);
     }


//--- A toast with an accent bar that shares the card's left radii,
//--- and two chat bubbles.

   const double tx2 = ox + 420;
   const double ty2 = tab_y + 140;

   RoundRectBordered(tx2, ty2, 330, 66, 0, 12, 12, 0,
                     CairoRgb(240, 246, 252), C_LINE, 1.0);

   CCairoPath accent;
   accent.AddRoundRect(tx2, ty2, 5, 66, 12, 0, 0, 12);
   Fill(accent, C_GREEN);

   for(int i = 0; i < 2; i++)
     {
      CCairoPath line;
      line.AddRoundRect(tx2 + 26, ty2 + 18 + i * 22,
                        220 - i * 70, 10, 5);
      Fill(line, CairoWithOpacity(C_MUTED, 0.8 - i * 0.25));
     }

//--- chat bubbles: three rounded corners, one square, and the
//--- square one points at whoever is speaking
   CCairoPath bubble_in;
   bubble_in.AddRoundRect(ox + 14, btn_y + 54, 145, 44, 16, 16, 16, 2);
   Fill(bubble_in, CairoWithOpacity(C_MUTED, 0.20));

   CCairoPath bubble_out;
   bubble_out.AddRoundRect(ox + 165, btn_y + 54, 145, 44, 16, 16, 2, 16);
   Fill(bubble_out, C_BLUE);

//--- badges with "ticket" corners
   for(int i = 0; i < 3; i++)
     {
      CCairoPath badge;
      badge.AddRoundRect(ox + 730, tab_y + i * 40, 72, 36,
                         4, 16, 4, 16);

      const uint bc = (i == 0) ? C_GREEN
                      : (i == 1) ? C_AMBER : C_PURPLE;

      Fill(badge, CairoWithOpacity(bc, 0.30));
     }
  }

//+------------------------------------------------------------------+
//| Compose                                                          |
//+------------------------------------------------------------------+
void Render()
  {
   g_surface.Clear(C_BACK);

   Print("=== Part 7: arcs, circles and rounded rectangles ===");

   PanelCornerMatrix(10,  10);
   PanelClamp(420,  10);
   PanelArcs(10, 345);
   PanelGauges(420, 345);
   PanelWidgets(10, 605);

   g_surface.Flush();
  }

//+------------------------------------------------------------------+
//| The captions. Chart pixels, so UI_X / UI_Y have to be added.     |
//+------------------------------------------------------------------+
void Captions()
  {
   DemoLabel("a", UI_X + 22, UI_Y + 14,
             "A. Nine corner combinations, nine single "
             "AddRoundRect calls");

   DemoLabel("b", UI_X + 432, UI_Y + 14,
             "B. Radii 0 to 500 on a 38 px bar - the amber mark "
             "is what was used");

   DemoLabel("c", UI_X + 22, UI_Y + 355,
             "C. One sweep at three radii - segment counts in "
             "the log");

   DemoLabel("d", UI_X + 432, UI_Y + 355,
             "D. Rings, gauges and a donut, all from ArcTo and "
             "even-odd");

   DemoLabel("e", UI_X + 22, UI_Y + 607,
             "E. Real widgets - and not one line of widget code "
             "in the library");
  }

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
   if(InpSetLightChart)
      DemoUseLightChart();

   if(!g_surface.Create("cairo_demo07", UI_X, UI_Y, UI_W, UI_H))
     {
      Print("Cairo5: failed to create the surface");
      return INIT_FAILED;
     }

   const ulong t0 = GetMicrosecondCount();
   Render();
   const ulong t1 = GetMicrosecondCount();

   if(InpShowCaptions)
      Captions();

   ChartRedraw();

   PrintFormat("whole %dx%d frame in %d us, 1 chart object",
               UI_W, UI_H, (int)(t1 - t0));

   return INIT_SUCCEEDED;
  }

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   g_surface.Destroy();
   DemoLabelsClear();
   ChartRedraw();
  }

//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
  }
//+------------------------------------------------------------------+
