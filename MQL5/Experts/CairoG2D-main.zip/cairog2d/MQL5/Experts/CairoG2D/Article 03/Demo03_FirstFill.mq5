//+------------------------------------------------------------------+
//|                                             Demo03_FirstFill.mq5 |
//|                              Copyright 2026, Sandro Begashvili   |
//|                   https://www.mql5.com/en/users/sandrobegashvil  |
//|                          Telegram: https://t.me/MrMQL5Developer  |
//|            Cairo-Style Graphics in MQL5 (Part 3) - the only demo |
//|                                                                  |
//|  THE FIRST SOLID SHAPES.                                         |
//|                                                                  |
//|  The library is now four files:                                  |
//|                                                                  |
//|      Color.mqh     the ARGB color type                           |
//|      Surface.mqh   a pixel buffer bound to one chart object      |
//|      Path.mqh      points, contours, and now EDGES               |
//|      Raster.mqh    one function that fills any outline           |
//|                                                                  |
//|  Everything below is drawn by the SAME call:                     |
//|                                                                  |
//|      g_ras.Fill( path, color, buffer, W, H );                    |
//|                                                                  |
//|  A rectangle, a star, a glyph, a 300-sided polygon, a shape      |
//|  nobody has named - one function, no per-shape code. Compare     |
//|  that with Part 1, where a triangle and a circle needed two      |
//|  completely separate routines.                                   |
//|                                                                  |
//|  Look closely at the diagonals: they are staircases. That is     |
//|  this version asking a yes/no question, and Part 4 fixes it.     |
//|                                                                  |
//|  Attach to any chart. Everything is removed again on deinit.     |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Sandro Begashvili"
#property link      "https://www.mql5.com/en/users/sandrobegashvil"
#property description "Part 3: the first filled polygon, via an edge list and a scanline fill"
#property description "Free to use and extend - please credit the author's mql5.com profile"
#property version   "1.00"
#property strict

#include <CairoG2D/Color.mqh>
#include <CairoG2D/Path.mqh>
#include <CairoG2D/Raster.mqh>
#include <CairoG2D/Surface.mqh>
#include <CairoG2D/DemoTheme.mqh>

//--- panel geometry, in chart pixels from the upper-left corner
#define UI_X      40
#define UI_Y      40
#define UI_W     920
#define UI_H     640

//--- captions are annotation for the article figures, not drawing.
//--- Turn them off and the panel is still exactly one chart object.
input bool InpShowCaptions  = true;   // Draw the explanatory captions
input bool InpSetLightChart = true;   // Switch the chart to Black On White

CCairoSurface    g_surface;
CCairoRasterizer g_ras;

//+-------------------------------------------------------------------+
//| One call for every shape in this demo.                            |
//|                                                                   |
//| Note what is NOT in the argument list: any hint of what kind of   |
//| shape this is. The rasterizer receives a path and a color.        |
//|                                                                   |
//| The IsValid() test is the whole cost of the health flag the path  |
//| carries. If any allocation while the path was built was refused,  |
//| the path is incomplete, and drawing half a shape is worse than    |
//| drawing none. One comparison per shape buys that.                 |
//+-------------------------------------------------------------------+
void Fill(CCairoPath &p, const uint argb)
  {
   if(!p.IsValid())
     {
      Print("Cairo5: path incomplete - out of memory while building it");
      return;
     }

   g_ras.Fill(p, argb, g_surface.m_px,
              g_surface.Width(), g_surface.Height());
  }

//+-------------------------------------------------------------------+
//| A. THE SHAPES WE COULD ALREADY DESCRIBE                           |
//|                                                                   |
//| Exactly the paths built in Part 2 - but now they are solid.       |
//| Nothing about the paths changed. We simply added something that   |
//| knows how to turn edges into pixels.                              |
//+-------------------------------------------------------------------+
void RowBasics(const double oy)
  {
//--- rectangle
   CCairoPath rect;
   rect.AddRect(40, oy, 150, 100);
   Fill(rect, DEMO_BLUE);

//--- triangle
   CCairoPath tri;
   tri.AddTriangle(230, oy + 100, 305, oy, 380, oy + 100);
   Fill(tri, DEMO_GREEN);

//--- star: ten computed vertices
   double sx[10], sy[10];

   for(int i = 0; i < 10; i++)
     {
      const double r = (i % 2 == 0) ? 55.0 : 23.0;
      const double a = -M_PI * 0.5 + M_PI * i / 5.0;

      sx[i] = 480 + r * MathCos(a);
      sy[i] = oy + 55 + r * MathSin(a);
     }

   CCairoPath star;
   star.AddPolygon(sx, sy, 10);
   Fill(star, DEMO_AMBER);

//--- an arbitrary blob nobody has a name for, to make the point
//--- that the rasterizer does not care. This one is built with
//--- AddPolyline, so the path records it as an OPEN contour -
//--- and it still fills solid, because BuildEdges joins the last
//--- vertex back to the first for every contour. Fill has no
//--- other option; the flag is there for the stroking in a later
//--- part, which does have a choice to make.
   double bx[7], by[7];

   bx[0] = 590;
   by[0] = oy + 20;
   bx[1] = 690;
   by[1] = oy;
   bx[2] = 730;
   by[2] = oy + 60;
   bx[3] = 690;
   by[3] = oy + 105;
   bx[4] = 640;
   by[4] = oy + 70;
   bx[5] = 615;
   by[5] = oy + 100;
   bx[6] = 575;
   by[6] = oy + 65;

   CCairoPath blob;
   blob.AddPolyline(bx, by, 7);

   PrintFormat("the blob: %d contour, closed = %s - and it fills anyway",
               blob.ContourCount(),
               blob.IsContourClosed(0) ? "true" : "false");

   Fill(blob, DEMO_INK_SOFT);

//--- and a 300-sided polygon, which is what a circle really is.
//--- Part 7 will compute these vertices for us; today we do it
//--- by hand, and the rasterizer cannot tell the difference.
   const int n = 300;

   double cx[], cy[];

   ArrayResize(cx, n);
   ArrayResize(cy, n);

   for(int i = 0; i < n; i++)
     {
      const double a = 2.0 * M_PI * i / n;

      cx[i] = 830 + 52 * MathCos(a);
      cy[i] = oy + 55 + 52 * MathSin(a);
     }

   CCairoPath circle;
   circle.ReservePoints(n);            // the count is known: one allocation
   circle.AddPolygon(cx, cy, n);
   Fill(circle, DEMO_RED);
  }

//+-------------------------------------------------------------------+
//| B. THE WINDING NUMBER, MADE VISIBLE                               |
//|                                                                   |
//| THE IMPORTANT EXPERIMENT IN THIS DEMO.                            |
//|                                                                   |
//| Two overlapping squares in ONE path, drawn twice:                 |
//|                                                                   |
//|   left   both contours wound the SAME way. In the overlap the     |
//|          winding number reaches 2 - not zero, therefore inside -  |
//|          so the two squares MERGE into one solid blob.            |
//|                                                                   |
//|   right  the second contour wound the OPPOSITE way. Now the       |
//|          overlap sums to +1 -1 = 0, therefore outside, and a HOLE |
//|          appears exactly where they cross.                        |
//|                                                                   |
//| Same geometry. Same fill call. Only the direction of the second   |
//| outline differs, and it changes the result completely.            |
//+-------------------------------------------------------------------+
void RowWinding(const double oy)
  {
//--- LEFT: both squares clockwise on screen
   CCairoPath same;

   same.ReserveContours(2);
   same.ReservePoints(8);

   same.MoveTo(60, oy);
   same.LineTo(170, oy);
   same.LineTo(170, oy + 110);
   same.LineTo(60, oy + 110);
   same.Close();

   same.MoveTo(120, oy +  55);
   same.LineTo(230, oy +  55);
   same.LineTo(230, oy + 165);
   same.LineTo(120, oy + 165);
   same.Close();

   Fill(same, DEMO_BLUE);

//--- RIGHT: the second square traced in REVERSE
   CCairoPath opposite;

   opposite.MoveTo(360, oy);
   opposite.LineTo(470, oy);
   opposite.LineTo(470, oy + 110);
   opposite.LineTo(360, oy + 110);
   opposite.Close();

//--- note the vertex order: bottom-left, bottom-right, top-right,
//--- top-left - the opposite rotation to the contour above
   opposite.MoveTo(420, oy + 165);
   opposite.LineTo(530, oy + 165);
   opposite.LineTo(530, oy +  55);
   opposite.LineTo(420, oy +  55);
   opposite.Close();

   Fill(opposite, DEMO_GREEN);
  }

//+-------------------------------------------------------------------+
//| C. A MULTI-CONTOUR GLYPH                                          |
//|                                                                   |
//| The letter "A" from Part 2, now filled. Both contours are wound   |
//| the same way, so the counter does NOT become a hole - it fills    |
//| solid, which is not what a letter should look like.               |
//|                                                                   |
//| That is not a bug in this demo; it is the honest state of the     |
//| engine. Fixing it needs either the opposite winding (as on the    |
//| right) or the even-odd rule, and the even-odd rule is Part 5.     |
//+-------------------------------------------------------------------+
void RowGlyph(const double ox, const double oy)
  {
   CCairoPath p;

   p.MoveTo(ox +  70, oy +   8);
   p.LineTo(ox + 128, oy + 140);
   p.LineTo(ox + 100, oy + 140);
   p.LineTo(ox +  88, oy + 110);
   p.LineTo(ox +  52, oy + 110);
   p.LineTo(ox +  40, oy + 140);
   p.LineTo(ox +  12, oy + 140);
   p.Close();

   p.MoveTo(ox +  60, oy +  86);
   p.LineTo(ox +  80, oy +  86);
   p.LineTo(ox +  70, oy +  50);
   p.Close();

   Fill(p, DEMO_INK_SOFT);

//--- the same glyph with the counter REVERSED, which does produce
//--- a proper letter A
   CCairoPath q;

   q.MoveTo(ox + 220, oy +   8);
   q.LineTo(ox + 278, oy + 140);
   q.LineTo(ox + 250, oy + 140);
   q.LineTo(ox + 238, oy + 110);
   q.LineTo(ox + 202, oy + 110);
   q.LineTo(ox + 190, oy + 140);
   q.LineTo(ox + 162, oy + 140);
   q.Close();

//--- counter traced the other way round
   q.MoveTo(ox + 220, oy +  50);
   q.LineTo(ox + 230, oy +  86);
   q.LineTo(ox + 210, oy +  86);
   q.Close();

   Fill(q, DEMO_AMBER);
  }

//+-------------------------------------------------------------------+
//| D. THE STAIRCASE, MADE OBVIOUS                                    |
//|                                                                   |
//| A fan of thin triangles at shallow angles. Every one of them has  |
//| a hard, stepped edge, because a pixel is either painted or it is  |
//| not. The shallower the angle, the longer the treads.              |
//|                                                                   |
//| This is the exact figure to compare against Part 4.               |
//+-------------------------------------------------------------------+
void RowStaircase(const double ox, const double oy)
  {
//--- ONE path for all seven triangles. Clear() empties it without
//--- giving the memory back, so the first triangle pays for the
//--- allocation and the other six reuse it. This is the loop a
//--- dashboard runs on every tick, in miniature.
   CCairoPath t;

   for(int i = 0; i < 7; i++)
     {
      const double a = -M_PI * 0.5 + M_PI * 0.5 * i / 6.0;

      t.Clear();
      t.AddTriangle(ox, oy + 120,
                    ox + 150 * MathCos(a),
                    oy + 120 + 150 * MathSin(a),
                    ox + 150 * MathCos(a + 0.09),
                    oy + 120 + 150 * MathSin(a + 0.09));

      Fill(t, CairoLerp(DEMO_BLUE, DEMO_AMBER, i / 6.0));
     }

//--- the shape is finished with, so hand the memory back
   t.Release();
  }

//+-------------------------------------------------------------------+
//| Compose the frame.                                                |
//+-------------------------------------------------------------------+
void Render()
  {
   g_surface.Clear(DEMO_BG);

   RowBasics(40);
   RowWinding(220);
   RowGlyph(580, 220);
   RowStaircase(120, 430);

//--- one shape with a great many edges, to show that complexity
//--- costs time inside our buffer and nothing at all on the chart
   const int n = 2000;

   double xs[], ys[];

   ArrayResize(xs, n);
   ArrayResize(ys, n);

   for(int i = 0; i < n; i++)
     {
      const double a = 2.0 * M_PI * i / n;
      const double r = 70.0 + 22.0 * MathSin(a * 11.0);

      xs[i] = 700 + r * MathCos(a);
      ys[i] = 510 + r * MathSin(a);
     }

   CCairoPath flower;
   flower.AddPolygon(xs, ys, n);

//--- these vertices came out of arithmetic, so check them once
//--- before they reach the rasterizer. A NaN found here has an
//--- address; the same NaN found by the fill is a blank panel.
   if(!flower.IsFinite())
      Print("Cairo5: the flower has a coordinate that is not a number");
   else
     {
      const ulong t0 = GetMicrosecondCount();
      Fill(flower, DEMO_BLUE);
      const ulong t1 = GetMicrosecondCount();

      PrintFormat("a %d-edge path filled in %d us", n, (int)(t1 - t0));
     }

   g_surface.Flush();
  }

//+-------------------------------------------------------------------+
//| The captions, in chart coordinates.                               |
//+-------------------------------------------------------------------+
void Captions()
{
    DemoLabel( "a", UI_X + 40, UI_Y + 16,
               "A. Six shapes");

    DemoLabel( "b", UI_X + 60, UI_Y + 196,
               "B. Different winding");

    DemoLabel( "c", UI_X + 580, UI_Y + 196,
               "C. The glyph");

    DemoLabel( "d", UI_X + 40, UI_Y + 406,
               "D. Shallow angles" );

    DemoLabel( "e", UI_X + 600, UI_Y + 406,
               "E. A 2000-edge path" );
}

//+-------------------------------------------------------------------+
//| Expert initialization function                                    |
//+-------------------------------------------------------------------+
int OnInit()
  {
   if(InpSetLightChart)
      DemoUseLightChart();

   if(!g_surface.Create("cairo_demo03", UI_X, UI_Y, UI_W, UI_H))
     {
      Print("Cairo5: failed to create the surface");
      return INIT_FAILED;
     }

   Print("=== Part 3: one Fill() for every shape ===");

   const ulong t0 = GetMicrosecondCount();
   Render();
   const ulong t1 = GetMicrosecondCount();

   if(InpShowCaptions)
      Captions();

   ChartRedraw();

   PrintFormat("whole %dx%d frame in %d us, 1 chart object",
               UI_W, UI_H, (int)(t1 - t0));

   return INIT_SUCCEEDED;
  }

//+-------------------------------------------------------------------+
//| Expert deinitialization function                                  |
//+-------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   g_surface.Destroy();
   DemoLabelsClear();
   ChartRedraw();
  }

//+-------------------------------------------------------------------+
//| Expert tick function                                              |
//+-------------------------------------------------------------------+
void OnTick()
  {
  }
//+-------------------------------------------------------------------+
