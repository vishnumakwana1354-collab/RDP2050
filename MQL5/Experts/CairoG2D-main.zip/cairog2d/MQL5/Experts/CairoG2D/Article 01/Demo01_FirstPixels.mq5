//+-------------------------------------------------------------------+
//|                                            Demo01_FirstPixels.mq5 |
//|                              Copyright 2026, Sandro Begashvili    |
//|                   https://www.mql5.com/en/users/sandrobegashvil   |
//|                          Telegram: https://t.me/MrMQL5Developer   |
//|            Cairo-Style Graphics in MQL5 (Part 1) - the only demo  |
//|                                                                   |
//|  OUR FIRST PIXELS ON A CHART.                                     |
//|                                                                   |
//|  At this point in the series we have written exactly two library  |
//|  files:                                                           |
//|                                                                   |
//|      <CairoG2D/Color.mqh>    the ARGB color type                  |
//|      <CairoG2D/Surface.mqh>  a pixel buffer bound to one object   |
//|                                                                   |
//|  (<CairoG2D/DemoTheme.mqh> is not library code - it is the shared |
//|  light palette and the chart setup used by every demo, so the     |
//|  figures in the articles all look the same.)                      |
//|                                                                   |
//|  There is no path. There is no rasteriser. There is not even a    |
//|  function to draw a rectangle. Every pixel below is written by    |
//|  hand, in a loop, straight into the buffer - which is the point:  |
//|  it proves the pipeline end to end before we build anything on    |
//|  top of it.                                                       |
//|                                                                   |
//|      buffer  ->  ResourceCreate  ->  OBJ_BITMAP_LABEL             |
//|                                                                   |
//|  Everything from Part 2 onwards is about deciding WHICH pixels to |
//|  write and WHAT to put in them. The plumbing is finished today.   |
//|                                                                   |
//|  Attach to any chart. Everything is removed again on deinit.      |
//+-------------------------------------------------------------------+
#property copyright "Copyright 2026, Sandro Begashvili"
#property link      "https://www.mql5.com/en/users/sandrobegashvil"
#property description "Part 1: first pixels - a raw ARGB buffer pushed to the"
#property description "chart as one bitmap resource."
#property description "Free to use and extend - please credit"
#property description "https://www.mql5.com/en/users/sandrobegashvil"
#property version   "1.10"
#property strict

#include <CairoG2D/Color.mqh>
#include <CairoG2D/Surface.mqh>
#include <CairoG2D/DemoTheme.mqh>

//--- panel geometry, in chart pixels from the upper-left corner
#define UI_X      40
#define UI_Y      40
#define UI_W     720
#define UI_H     400

//--- captions are annotation for the article figures, not drawing.
//--- Turn them off and the panel is still exactly one chart object.
input bool InpShowCaptions  = true;   // Draw the explanatory captions
input bool InpSetLightChart = true;   // Switch the chart to Black On White

CCairoSurface g_surface;

//+-------------------------------------------------------------------+
//| Write one pixel, with bounds checking.                            |
//|                                                                   |
//| The buffer is ROW-MAJOR: pixel (x, y) lives at index y*width + x. |
//| That one line of arithmetic is the whole memory model of every    |
//| raster graphics system ever written.                              |
//|                                                                   |
//| Note this OVERWRITES rather than blends. Blending needs alpha     |
//| compositing, which we build in Part 4.                            |
//+-------------------------------------------------------------------+
void SetPixel(const int x, const int y, const uint argb)
  {
   if(x < 0 || y < 0 || x >= g_surface.Width() || y >= g_surface.Height())
      return;

   g_surface.m_px[ y * g_surface.Width() + x ] = argb;
  }

//+-------------------------------------------------------------------+
//| A. A SOLID RECTANGLE, THE HONEST WAY                              |
//|                                                                   |
//| Two nested loops. No cleverness at all.                           |
//|                                                                   |
//| Notice what is missing: any notion of a "shape". The buffer does  |
//| not know a rectangle was drawn, only that some pixels changed.    |
//| Everything this library eventually does is a better answer to the |
//| question these two loops answer crudely: WHICH pixels belong to   |
//| the thing I am drawing?                                           |
//+-------------------------------------------------------------------+
void RectSolid(const int x, const int y, const int w, const int h,
               const uint argb)
  {
   for(int row = y; row < y + h; row++)
      for(int col = x; col < x + w; col++)
         SetPixel(col, row, argb);
  }

//+-------------------------------------------------------------------+
//| A one-pixel outline, drawn as four thin rectangles because we     |
//| have no better tool yet. In Part 5 this becomes a single path     |
//| filled with the even-odd rule.                                    |
//+-------------------------------------------------------------------+
void RectOutline(const int x, const int y, const int w, const int h,
                 const uint argb)
  {
   RectSolid(x,         y,         w, 1, argb);
   RectSolid(x,         y + h - 1, w, 1, argb);
   RectSolid(x,         y,         1, h, argb);
   RectSolid(x + w - 1, y,         1, h, argb);
  }

//+-------------------------------------------------------------------+
//| B. A VERTICAL GRADIENT                                            |
//|                                                                   |
//| The same two loops, but the color is computed per row instead of  |
//| being constant. CairoLerp does the interpolation.                 |
//|                                                                   |
//| This is worth pausing on, because it is the seed of an idea the   |
//| whole library is built around: the color of a pixel can be a      |
//| FUNCTION of its position. In Part 8 that function gets a name -   |
//| a "paint" - and a solid color becomes the special case that       |
//| ignores its arguments.                                            |
//+-------------------------------------------------------------------+
void RectGradient(const int x, const int y, const int w, const int h,
                  const uint top, const uint bottom)
  {
   if(w <= 0 || h <= 0)
      return;

//--- a one-row gradient has no distance to interpolate ACROSS, and
//--- (h - 1) below would be zero. There is no sensible blend of two
//--- colors over a single row, so the top color wins.
   if(h == 1)
     {
      RectSolid(x, y, w, 1, top);
      return;
     }

   for(int row = 0; row < h; row++)
     {
      const uint c = CairoLerp(top, bottom, (double)row / (h - 1));

      for(int col = 0; col < w; col++)
         SetPixel(x + col, y + row, c);
     }
  }

//+-------------------------------------------------------------------+
//| C. A DIAGONAL EDGE, DECIDED PIXEL BY PIXEL                        |
//|                                                                   |
//| THE FIGURE THAT MOTIVATES THE ENTIRE SERIES.                      |
//|                                                                   |
//| We fill a triangle by asking, for every pixel: is my CENTRE on    |
//| the inside of this diagonal? It is a yes/no question, so the      |
//| answer is a hard edge - a staircase.                              |
//|                                                                   |
//| THE BOX IS DELIBERATELY WIDER THAN IT IS TALL. At 45 degrees the  |
//| edge steps down one pixel for every pixel across, and a run of    |
//| one is hard to see. A shallow slope - here about 1 in 3 - makes   |
//| each tread three pixels long, and the staircase becomes           |
//| impossible to miss. That is the whole reason this figure exists.  |
//|                                                                   |
//| The diagonal is drawn through the CENTRE of the top-left pixel    |
//| and the CENTRE of the bottom-right one, so the triangle reaches   |
//| both corners and fills its box exactly, with no clipped tip.      |
//|                                                                   |
//| This is what CCanvas::FillPolygon does, and what we replace in    |
//| Part 4 by asking a better question: HOW MUCH of this pixel is     |
//| inside? Zoom into the screenshot and the staircase is obvious.    |
//+-------------------------------------------------------------------+
void TriangleHardEdge(const int x, const int y, const int w, const int h,
                      const uint argb)
  {
   if(w < 2 || h < 2)
      return;

//--- rise over run, measured between the two corner pixel centres
   const double slope = (double)(h - 1) / (double)(w - 1);

   for(int row = 0; row < h; row++)
     {
      for(int col = 0; col < w; col++)
        {
         //--- the pixel's CENTRE, which is what makes this a
         //--- yes/no test rather than a measurement
         const double px = col + 0.5;
         const double py = row + 0.5;

         //--- below the diagonal, so inside the lower-left triangle?
         if(py - 0.5 >= (px - 0.5) * slope)
            SetPixel(x + col, y + row, argb);
        }
     }
  }

//+-------------------------------------------------------------------+
//| D. A CIRCLE, ALSO PIXEL BY PIXEL                                  |
//|                                                                   |
//| Same yes/no test, different question: is this pixel's centre      |
//| within r of the centre? Same result: a hard, jagged boundary.     |
//|                                                                   |
//| It also shows why per-shape drawing code does not scale. This     |
//| function shares nothing with TriangleHardEdge above. A rounded    |
//| rectangle would need a third function, an ellipse a fourth, a     |
//| star a fifth - each with its own edge-case bugs. Part 3 replaces  |
//| all of them with ONE function that fills any outline at all.      |
//+-------------------------------------------------------------------+
void CircleHardEdge(const int cx, const int cy, const int r,
                    const uint argb)
  {
   for(int row = cy - r; row <= cy + r; row++)
     {
      for(int col = cx - r; col <= cx + r; col++)
        {
         const double dx = (col + 0.5) - cx;
         const double dy = (row + 0.5) - cy;

         if(dx * dx + dy * dy <= (double)r * r)
            SetPixel(col, row, argb);
        }
     }
  }

//+-------------------------------------------------------------------+
//| E. THE ALPHA CHANNEL IS REAL                                      |
//|                                                                   |
//| A row of swatches at descending opacity, over a light chequer we  |
//| draw ourselves. The chequer shows through the transparent parts,  |
//| which is something no OBJ_RECTANGLE_LABEL can do at any setting.  |
//|                                                                   |
//| We are not BLENDING here - each pixel is simply stored with a     |
//| smaller alpha value and the terminal does the compositing.        |
//| Blending inside our own buffer is Part 4.                         |
//+-------------------------------------------------------------------+
void AlphaStrip(const int x, const int y, const int w, const int h)
  {
//--- a chequerboard, so the transparency is visible against
//--- something rather than guessed at
   for(int row = 0; row < h; row++)
      for(int col = 0; col < w; col++)
        {
         const bool dark = (((col / 10) + (row / 10)) % 2 == 0);

         SetPixel(x + col, y + row, dark ? CairoRgb(230, 233, 236)
                  : DEMO_BG);
        }

//--- eight swatches, from fully opaque down to fully transparent
   for(int i = 0; i < 8; i++)
     {
      const double opacity = 1.0 - i / 7.0;
      const uint   c       = CairoWithOpacity(DEMO_BLUE, opacity);

      RectSolid(x + 16 + i * 80, y + 16, 60, h - 32, c);
     }
  }

//+-------------------------------------------------------------------+
//| Compose the frame.                                                |
//+-------------------------------------------------------------------+
void Render()
  {
//--- start from a plain white panel: the chart uses the standard
//--- Black On White scheme, so the panel must not fight it
   g_surface.Clear(DEMO_BG);

//--- A: five flat rectangles, in the roles every demo agrees on
   RectSolid(20, 30, 124, 56, DEMO_BLUE);
   RectSolid(154, 30, 124, 56, DEMO_GREEN);
   RectSolid(288, 30, 124, 56, DEMO_RED);
   RectSolid(422, 30, 124, 56, DEMO_AMBER);
   RectSolid(556, 30, 124, 56, DEMO_GREY);

//--- B: a gradient, computed per row
   RectGradient(20, 130, 280, 88, DEMO_BG, DEMO_BLUE);
   RectOutline(20, 130, 280, 88, DEMO_BORDER);

//--- C and D: hard-edged shapes - the problem to be solved.
//--- The triangle is 200 x 68, a slope of about 1 in 3, so each
//--- step of the staircase is three pixels long.
   TriangleHardEdge(330, 140, 200, 68, DEMO_BLUE);
   CircleHardEdge(610, 174, 44,      DEMO_BLUE);

//--- E: alpha
   AlphaStrip(20, 258, 660, 116);
   RectOutline(20, 258, 660, 116, DEMO_BORDER);

//--- a frame around the whole panel, so it reads as one card
   RectOutline(0, 0, UI_W, UI_H, DEMO_BORDER);

//--- one upload: the terminal is left holding ONE object
   g_surface.Flush();
  }

//+-------------------------------------------------------------------+
//| The captions. Positions are panel coordinates plus the panel      |
//| origin, so a caption always sits where its region is.             |
//+-------------------------------------------------------------------+
void Captions()
  {
   DemoLabel("a", UI_X +  20, UI_Y +  10,
             "A. Solid fill - one color written into every pixel");

   DemoLabel("a1", UI_X +  20, UI_Y +  90, "BLUE / buy",    DEMO_INK_SOFT, 8);
   DemoLabel("a2", UI_X + 154, UI_Y +  90, "GREEN / pass",  DEMO_INK_SOFT, 8);
   DemoLabel("a3", UI_X + 288, UI_Y +  90, "RED / sell",    DEMO_INK_SOFT, 8);
   DemoLabel("a4", UI_X + 422, UI_Y +  90, "AMBER / limit", DEMO_INK_SOFT, 8);
   DemoLabel("a5", UI_X + 556, UI_Y +  90, "GREY / no data", DEMO_INK_SOFT, 8);

   DemoLabel("b", UI_X +  20, UI_Y + 112,
             "B. Color as a function of position");
   DemoLabel("c", UI_X + 330, UI_Y + 112, "C. Triangle, slope 1 in 3");
   DemoLabel("d", UI_X + 566, UI_Y + 112, "D. Circle");

   DemoLabel("cd", UI_X + 330, UI_Y + 228,
             "both edges decided by a yes/no test - look for the steps",
             DEMO_INK_SOFT, 8);

   DemoLabel("e", UI_X +  20, UI_Y + 238,
             "E. Real transparency - 100% opaque on the left, 0% on the right");
  }

//+-------------------------------------------------------------------+
//| Expert initialization function                                    |
//+-------------------------------------------------------------------+
int OnInit()
  {
   if(InpSetLightChart)
      DemoUseLightChart();

//--- NOT a bare "demo01". A dynamic resource belongs to the PROGRAM,
//--- not to the chart, so two copies of this EA on two charts would
//--- otherwise fight over one buffer. CairoSurfaceName folds the
//--- chart id and the subwindow in for us.
   const string surface = CairoSurfaceName("demo01");

   if(!g_surface.Create(surface, UI_X, UI_Y, UI_W, UI_H))
     {
      Print("Cairo G2D: failed to create the surface");
      return INIT_FAILED;
     }

//--- GetMicrosecondCount, never GetTickCount: the latter has a
//--- 15.625 ms resolution on Windows and would report this entire
//--- frame as either 0 ms or 15 ms, which tells you nothing
   const ulong t0 = GetMicrosecondCount();

   Render();

   const ulong t1 = GetMicrosecondCount();

   if(InpShowCaptions)
      Captions();

   ChartRedraw();

   PrintFormat("Cairo G2D Part 1: %d x %d = %d pixels written in %d us, "
               "using %d chart object for the drawing",
               UI_W, UI_H, UI_W * UI_H, (int)(t1 - t0), 1);

   return INIT_SUCCEEDED;
  }

//+-------------------------------------------------------------------+
//| Expert deinitialization function                                  |
//+-------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   g_surface.Destroy();
   DemoLabelsClear();
   ChartRedraw();
  }

//+-------------------------------------------------------------------+
//| Expert tick function                                              |
//+-------------------------------------------------------------------+
void OnTick()
  {
  }
//+-------------------------------------------------------------------+
