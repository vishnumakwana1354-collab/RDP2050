//+------------------------------------------------------------------+
//|                                         Demo04_AntiAliasing.mq5  |
//|                              Copyright 2026, Sandro Begashvili   |
//|                   https://www.mql5.com/en/users/sandrobegashvil  |
//|                          Telegram: https://t.me/MrMQL5Developer  |
//|            Cairo-Style Graphics in MQL5 (Part 4) - the only demo |
//|                                                                  |
//|  THE STAIRCASE DISAPPEARS.                                       |
//|                                                                  |
//|  The library is now five files:                                  |
//|                                                                  |
//|      Config.mqh    CairoAaSamples - the quality dial             |
//|      Color.mqh     ARGB, and now CairoBlendOver                  |
//|      Surface.mqh   a pixel buffer bound to one chart object      |
//|      Path.mqh      points, contours, edges                       |
//|      Raster.mqh    coverage instead of a yes/no test             |
//|                                                                  |
//|  Panels:                                                         |
//|                                                                  |
//|    A. the Part 3 diagonal fan, redrawn - compare with that       |
//|       article's screenshot, the geometry is identical            |
//|    B. the same shape at 1, 2, 4 and 8 sub-scanlines, with the    |
//|       cost of each printed to the log                            |
//|    C. sub-pixel positioning: ten bars a tenth of a pixel apart   |
//|    D. near-horizontal edges, where sampling in Y matters most    |
//|    E. translucent overlaps - compositing, now that we can blend  |
//|    F. a coverage ramp: one shape drawn at ten opacities          |
//|                                                                  |
//|  Attach to any chart. Everything is removed again on deinit.     |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Sandro Begashvili"
#property link      "https://www.mql5.com/en/users/sandrobegashvil"
#property description "Part 4: coverage-based anti-aliasing and alpha compositing"
#property description "Free to use and extend - please credit the author's mql5.com profile"
#property version   "1.00"
#property strict

#include <CairoG2D/Config.mqh>
#include <CairoG2D/Color.mqh>
#include <CairoG2D/Path.mqh>
#include <CairoG2D/Raster.mqh>
#include <CairoG2D/Surface.mqh>
#include <CairoG2D/DemoTheme.mqh>

#define UI_X      20
#define UI_Y      20
#define UI_W     940
#define UI_H     700

//--- every color is a role from the shared light theme
#define C_BACK    DEMO_BG
#define C_BLUE    DEMO_BLUE
#define C_GREEN   DEMO_GREEN
#define C_ORANGE  DEMO_AMBER
#define C_RED     DEMO_RED
#define C_PURPLE  DEMO_INK_SOFT
#define C_GREY    DEMO_GREY
#define C_NONE    CairoArgb( 0, 0, 0, 0 )

//--- captions are annotation for the article figures, not drawing.
//--- Turn them off and the panel is still exactly one chart object.
input bool InpShowCaptions  = true;   // Draw the explanatory captions
input bool InpSetLightChart = true;   // Switch the chart to Black On White

CCairoSurface    g_surface;
CCairoRasterizer g_ras;

//+------------------------------------------------------------------+
//| One call for every shape in this demo.                           |
//+------------------------------------------------------------------+
void Fill(CCairoPath &p, const uint argb)
  {
   g_ras.Fill(p, argb, g_surface.m_px,
              g_surface.Width(), g_surface.Height());
  }

//+------------------------------------------------------------------+
//| A. THE PART 3 FAN, REDRAWN                                       |
//|                                                                  |
//| Byte for byte the same geometry as the Part 3 demo. The only     |
//| thing that changed is the rasterizer underneath it.              |
//|                                                                  |
//| Put the two screenshots side by side at 6x magnification - that  |
//| comparison is the entire argument of this article.               |
//+------------------------------------------------------------------+
void PanelFan(const double ox, const double oy)
  {
   for(int i = 0; i < 7; i++)
     {
      const double a = -M_PI * 0.5 + M_PI * 0.5 * i / 6.0;

      CCairoPath t;
      t.AddTriangle(ox, oy + 120,
                    ox + 150 * MathCos(a),
                    oy + 120 + 150 * MathSin(a),
                    ox + 150 * MathCos(a + 0.09),
                    oy + 120 + 150 * MathSin(a + 0.09));

      Fill(t, CairoLerp(C_BLUE, C_ORANGE, i / 6.0));
     }
  }

//+------------------------------------------------------------------+
//| B. THE QUALITY DIAL                                              |
//|                                                                  |
//| The same star at four sample counts, with the cost of each       |
//| printed to the log. Coverage in X is exact whatever the setting, |
//| so the visible difference here is confined to the star's         |
//| shallower edges; panel D isolates that case on purpose. What     |
//| this panel is really for is the PRICE of the dial.               |
//|                                                                  |
//| THE BENCHMARK MUST NOT DRAW.                                     |
//|                                                                  |
//| Fill() COMPOSITES; it does not overwrite. Timing a shape by      |
//| drawing it 40 times does not draw it 40 times identically - it   |
//| blends it onto itself, and a pixel at coverage a ends up at      |
//| 1 - (1-a)^41. For a = 0.4 that is 1.000. Every partial pixel     |
//| along every edge - the whole subject of this article - would be  |
//| driven to solid by the act of measuring it, and the panel would  |
//| come out looking exactly like the hard yes/no fill of Part 3.    |
//|                                                                  |
//| So the visible fill happens ONCE, in C_ORANGE, and the 40 timed  |
//| repeats use C_NONE - alpha zero. CairoBlendOver returns dst      |
//| untouched when the source alpha is zero, so those fills do the   |
//| entire job - build edges, walk rows, sample, accumulate coverage |
//| - and write nothing at all.                                      |
//+------------------------------------------------------------------+
void PanelSamples(const double ox, const double oy)
  {
   const int saved = CairoAaSamples;

   int levels[4] = { 1, 2, 4, 8 };

   for(int k = 0; k < 4; k++)
     {
      CairoAaSamples = levels[k];

      const double cx = ox + k * 150;

      double xs[10], ys[10];

      for(int i = 0; i < 10; i++)
        {
         const double r = (i % 2 == 0) ? 58.0 : 24.0;
         const double a = -M_PI * 0.5 + M_PI * i / 5.0;

         xs[i] = cx + 62 + r * MathCos(a);
         ys[i] = oy + 62 + r * MathSin(a);
        }

      CCairoPath star;
      star.AddPolygon(xs, ys, 10);

      //--- the one fill the reader sees
      Fill(star, C_ORANGE);

      //--- an untimed warm-up so the scratch arrays are already at
      //--- their high-water mark, then 40 timed repeats - all of
      //--- them invisible, see the note above
      Fill(star, C_NONE);

      const ulong t0 = GetMicrosecondCount();

      for(int r2 = 0; r2 < 40; r2++)
         Fill(star, C_NONE);

      const ulong t1 = GetMicrosecondCount();

      PrintFormat("B. CairoAaSamples = %d  ->  %.1f us per fill",
                  levels[k], (double)(t1 - t0) / 40.0);
     }

   CairoAaSamples = saved;
  }

//+------------------------------------------------------------------+
//| C. SUB-PIXEL POSITIONING IS REAL NOW                             |
//|                                                                  |
//| Ten identical bars, each shifted a further TENTH of a pixel.     |
//|                                                                  |
//| In Part 2 the path stored those offsets faithfully and the crude |
//| plotter rounded them away. In Part 3 the rasterizer rounded them |
//| away. Here they survive all the way to the screen: each bar's    |
//| left edge is shaded differently, and the bars visibly creep      |
//| rightwards in tenth-pixel steps.                                 |
//|                                                                  |
//| This is what makes smooth animation possible. A widget moving    |
//| 0.1 px per frame now glides instead of juddering between whole   |
//| pixels.                                                          |
//+------------------------------------------------------------------+
void PanelSubPixel(const double ox, const double oy)
  {
   for(int i = 0; i < 10; i++)
     {
      CCairoPath bar;
      bar.AddRect(ox + i * 34 + i / 10.0, oy, 22, 90);
      Fill(bar, C_GREEN);
     }

//--- and a single hairline at a series of fractional widths, to
//--- show that a shape THINNER than a pixel still renders - it
//--- simply comes out fainter, which is exactly right
   for(int i = 0; i < 10; i++)
     {
      CCairoPath hair;
      hair.AddRect(ox + i * 34 + 22, oy + 100, i / 10.0, 60);
      Fill(hair, C_BLUE);
     }
  }

//+------------------------------------------------------------------+
//| D. WHERE SAMPLING IN Y ACTUALLY MATTERS                          |
//|                                                                  |
//| Very shallow wedges - almost horizontal.                         |
//|                                                                  |
//| Coverage in X is exact, so a steep edge looks perfect even at    |
//| one sample. A near-horizontal edge is the opposite case: it      |
//| crosses a whole row over many columns, so what matters is how    |
//| finely the row is sliced vertically. Set CairoAaSamples to 1 and |
//| this panel bands visibly; set it to 8 and it is smooth.          |
//+------------------------------------------------------------------+
void PanelShallow(const double ox, const double oy)
  {
   for(int i = 0; i < 5; i++)
     {
      const double y = oy + i * 30;

      CCairoPath wedge;
      wedge.AddTriangle(ox, y,
                        ox + 380, y + 2.0 + i * 1.5,
                        ox + 380, y + 16);
      Fill(wedge, CairoLerp(C_PURPLE, C_GREEN, i / 4.0));
     }
  }

//+------------------------------------------------------------------+
//| E. COMPOSITING                                                   |
//|                                                                  |
//| Part 3 OVERWROTE pixels, so a translucent color simply replaced  |
//| what was underneath. Now CairoBlendOver mixes properly.          |
//|                                                                  |
//| Three overlapping translucent discs. Where two overlap the color |
//| is the correct blend of both; where three overlap, of all three. |
//| Note that the anti-aliased boundaries stay clean where they      |
//| cross each other - that is the straight-alpha maths in           |
//| CairoBlendOver doing its job. Premultiplied alpha would put a    |
//| dark seam along every one of those edges.                        |
//+------------------------------------------------------------------+
void PanelBlending(const double ox, const double oy)
  {
   const int n = 120;

   double cx[3], cy[3];
   uint   cols[3];

   cx[0] = ox + 70;
   cy[0] = oy + 60;
   cols[0] = C_RED;
   cx[1] = ox + 130;
   cy[1] = oy + 60;
   cols[1] = C_GREEN;
   cx[2] = ox + 100;
   cy[2] = oy + 110;
   cols[2] = C_BLUE;

   for(int k = 0; k < 3; k++)
     {
      double xs[], ys[];

      ArrayResize(xs, n);
      ArrayResize(ys, n);

      for(int i = 0; i < n; i++)
        {
         const double a = 2.0 * M_PI * i / n;

         xs[i] = cx[k] + 52 * MathCos(a);
         ys[i] = cy[k] + 52 * MathSin(a);
        }

      CCairoPath disc;
      disc.AddPolygon(xs, ys, n);

      Fill(disc, CairoWithOpacity(cols[k], 0.55));
     }
  }

//+------------------------------------------------------------------+
//| F. A COVERAGE RAMP                                               |
//|                                                                  |
//| The same bar drawn at ten opacities, over a checkerboard we draw |
//| with the rasterizer itself.                                      |
//|                                                                  |
//| The point: `coverage` and `alpha` enter CairoBlendOver through   |
//| the same multiplication. A 50%-covered pixel of an opaque color  |
//| and a fully covered pixel of a 50% color produce the identical   |
//| result - which is why anti-aliasing needed no code of its own.   |
//+------------------------------------------------------------------+
void PanelRamp(const double ox, const double oy)
  {
//--- checkerboard background
   for(int r = 0; r < 8; r++)
      for(int c = 0; c < 40; c++)
        {
         if((r + c) % 2 != 0)
            continue;

         CCairoPath sq;
         sq.AddRect(ox + c * 9, oy + r * 9, 9, 9);
         Fill(sq, CairoRgb(231, 235, 239));
        }

   for(int i = 0; i < 10; i++)
     {
      CCairoPath bar;
      bar.AddRect(ox + i * 36, oy, 30, 72);
      Fill(bar, CairoWithOpacity(C_ORANGE, 1.0 - i / 10.0));
     }
  }

//+------------------------------------------------------------------+
//| Compose                                                          |
//+------------------------------------------------------------------+
void Render()
  {
   g_surface.Clear(C_BACK);

   PanelFan(60,  50);
   PanelSamples(300,  20);
   PanelSubPixel(40, 210);
   PanelShallow(430, 210);
   PanelBlending(60, 400);
   PanelRamp(300, 420);

   g_surface.Flush();
  }


//+------------------------------------------------------------------+
//| The captions, in chart coordinates.                              |
//+------------------------------------------------------------------+
void Captions()
  {
   DemoLabel("a", UI_X +  60, UI_Y +   4,
             "A. The Part 3 fan");

   DemoLabel("b", UI_X + 400, UI_Y +   4,
             "B. CairoAaSamples = 1, 2, 4, 8");

   DemoLabel("c", UI_X +  40, UI_Y + 192,
             "C. Sub-pixel");

   DemoLabel("d", UI_X + 430, UI_Y + 192,
             "D. Near-horizontal edges");

   DemoLabel("e", UI_X +  60, UI_Y + 382,
             "E. Compositing");

   DemoLabel("f", UI_X + 300, UI_Y + 402,
             "F. One color at ten opacities");
  }

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
   if(InpSetLightChart)
      DemoUseLightChart();

   if(!g_surface.Create("cairo_demo04", UI_X, UI_Y, UI_W, UI_H))
     {
      Print("Cairo5: failed to create the surface");
      return INIT_FAILED;
     }

   Print("=== Part 4: coverage instead of a yes/no test ===");

   const ulong t0 = GetMicrosecondCount();
   Render();
   const ulong t1 = GetMicrosecondCount();

   if(InpShowCaptions)
      Captions();

   ChartRedraw();

   PrintFormat("whole %dx%d frame in %d us at CairoAaSamples = %d",
               UI_W, UI_H, (int)(t1 - t0), CairoAaSamples);

   return INIT_SUCCEEDED;
  }

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   g_surface.Destroy();
   DemoLabelsClear();
   ChartRedraw();
  }

//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
  }
//+------------------------------------------------------------------+
