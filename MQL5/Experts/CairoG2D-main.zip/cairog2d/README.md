# Cairo G2D — a 2D vector graphics engine in pure MQL5

Source code for the mql5.com article series **Creating a Cairo-Inspired Graphics Library for MetaTrader 5**.

Part 1: https://www.mql5.com/en/articles/23818

Part 2: https://www.mql5.com/en/articles/23993

Part 3: https://www.mql5.com/en/articles/24165

Part 4: https://www.mql5.com/en/articles/24259

Part 5: https://www.mql5.com/en/articles/24315

Part 6: https://www.mql5.com/en/articles/24569

Part 7: https://www.mql5.com/en/articles/24632

Part 8: https://www.mql5.com/en/articles/24658

Part 9: https://www.mql5.com/en/articles/25144


A scanline rasteriser, path model and compositing pipeline written from scratch in MQL5, with no external libraries and no `CCanvas`. Everything it draws goes into one `OBJ_BITMAP_LABEL`, so a panel of a thousand shapes still costs the terminal exactly one chart object.

---

## Which version do I want?

**Use the release that matches the article you are reading.** Each part of the series has its own release, frozen at the state the article explains — so if you are reading Part 1, the Part 1 release contains two header files and one demo, and nothing you have not read about yet.

| Release | Article | What it adds |
|---|---|---|
| [`part-01`](https://forge.mql5.io/SandroBegashvil/CairoG2D/releases/tag/part-01) | [Part 1 — Why the Terminal Needs Its Own 2D Renderer](https://www.mql5.com/en/articles/23818) | `Color.mqh`, `Surface.mqh` — the ARGB type and the buffer-to-chart bridge |
| [`part-02`](https://forge.mql5.io/SandroBegashvil/CairoG2D/releases/tag/part-02) | [Part 2 — Points, Contours and the Path](https://www.mql5.com/en/articles/23993) | `Path.mqh` — points, contours, the path |
| [`part-03`](https://forge.mql5.io/SandroBegashvil/CairoG2D/releases/tag/part-03) | [Part 3 — Edges and the First Filled Shape](https://www.mql5.com/en/articles/24165) | `Path.mqh` & `Raster.mqh` — the scanline fill |
| [`part-04`](https://forge.mql5.io/SandroBegashvil/CairoG2D/releases/tag/part-04) | [Part 4 — Anti-Aliasing, Coverage and Compositing](https://www.mql5.com/en/articles/24259) | `Config.mqh` & `Raster.mqh` — coverage and compositing |
| [`part-05`](https://forge.mql5.io/SandroBegashvil/CairoG2D/releases/tag/part-05) | [Part 5 — Fill Rules, Holes and Borders](https://www.mql5.com/en/articles/24315) | `Path.mqh` & `Raster.mqh` — fill rules and holes |
| [`part-06`](https://forge.mql5.io/SandroBegashvil/CairoG2D/releases/tag/part-06) | [Part 6 — Curves and Adaptive Flattening](https://www.mql5.com/en/articles/24569) | `Path.mqh` & `Config.mqh` — cubic Bezier and recursive subdivision to flatten the curves |
| [`part-07`](https://forge.mql5.io/SandroBegashvil/CairoG2D/releases/tag/part-07) | [Part 7 — Arcs, Circles and Rounded Rectangles](https://www.mql5.com/en/articles/24632) | `Path.mqh` — ArcTo, AddCircle, AddEllipse, AddRoundRect |
| [`part-08`](https://forge.mql5.io/SandroBegashvil/CairoG2D/releases/tag/part-08) | [Part 8 — Paint, from Solid Colors to Gradients](https://www.mql5.com/en/articles/24658) | `Paint.mqh`, `Raster.mqh` — The color source, and the two gradients |
| [`part-09`](https://forge.mql5.io/SandroBegashvil/CairoG2D/releases/tag/part-09) | [Part 9 — Clipping, Bounds and Hit Testing](https://www.mql5.com/en/articles/25144) | `Clip.mqh`, `Raster.mqh` — Clip and Bounds for contexts |

Later parts are added to this table as they are published. The `main` branch is always the newest state, which will be ahead of every published article.

---

## Installing

Download the release archive and extract it over your terminal's data folder (**File → Open Data Folder** in MetaTrader 5). The archive already has the right shape, so the files land where they belong:

```text
MQL5/
├── Include/
│   └── CairoG2D/
│       ├── Color.mqh          the ARGB color type
│       ├── Surface.mqh        pixel buffer bound to one chart object
│       ├── Path.mqh           points, contours, the path
│       ├── Raster.mqh         the scanline fill
│       ├── Clip.mqh           the rectangle, the mask, the coverage
│       ├── Paint.mqh          The color source, and the two gradients
│       ├── Config.mqh         CairoAaSamples - the quality dial
│       └── DemoTheme.mqh      the demos' shared palette - NOT library code
└── Experts/
    └── CairoG2D/
        ├── Article 01/
        │   └── Demo01_FirstPixels.mq5
        ├── Article 02/
        │   └── Demo02_PathViewer.mq5
        ├── Article 03/
        │   └── Demo03_FirstFill.mq5
        ├── Article 04/
        │   └── Demo04_AntiAliasing.mq5
        ├── Article 05/
        │   └── Demo05_FillRules.mq5
        ├── Article 06/
        │   └── Demo06_Curves.mq5
        ├── Article 07/
        │   └── Demo07_RoundRect.mq5
        ├── Article 08/
        │   └── Demo08_Paint.mq5
        └── Article 09/
            └── Demo09_Clipping.mq5
```

Then open the demo in MetaEditor, compile with **F7**, and drag it onto any chart. It needs no inputs, no indicators and no market data.

The library headers are included the usual way:

```mql5
#include <CairoG2D/Color.mqh>
#include <CairoG2D/Surface.mqh>
```

`DemoTheme.mqh` is deliberately shipped alongside them but is **not** part of the engine. It holds the light palette and the chart setup that make every screenshot in the series look the same, and nothing in the renderer depends on it.

---

## Scope

This is a software rasteriser aimed at **interface redraw** — panels that are repainted when something happens, not scenes animated at a high frame rate. It uses **straight (non-premultiplied) alpha from input to output**, which is what `COLOR_FORMAT_ARGB_NORMALIZE` expects.

---

## Removing it

Each demo draws into a single chart object and deletes that object on `OnDeinit`, so removing the Expert Advisor leaves the chart exactly as it was found. Nothing is written outside the terminal's data folder.

---

## Copyright and use

Copyright 2026, **Sandro Begashvili**

- mql5.com profile: https://www.mql5.com/en/users/sandrobegashvil
- Telegram: https://t.me/MrMQL5Developer

You are free to **use this code in your own projects and to extend it**, commercially or otherwise. The only thing asked in return is attribution: keep a mention of the author's mql5.com profile in the source you derive from it.

If you build something with it, I would genuinely like to see it — the Telegram link above is the fastest way to reach me.
