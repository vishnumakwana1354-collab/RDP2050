//+------------------------------------------------------------------+
//|                                                 SurvivalDemo.mq5 |
//|                                      MMQ — Muhammad Minhas Qamar |
//|                                   www.mql5.com/en/articles/23928 |
//+------------------------------------------------------------------+
#property copyright "MMQ — Muhammad Minhas Qamar"
#property link      "https://www.mql5.com/en/articles/23928"
#property version   "1.00"
#property strict
#property description "Donchian breakout that exists only to generate a"
#property description "trade history for SurvivalPanel to analyse. Run it"
#property description "in the Strategy Tester with visual mode enabled."

#include <Trade\Trade.mqh>

//--- The panel travels inside this Expert rather than beside it.
//--- A tester agent unpacks the Expert into its own sandbox, so an
//--- indicator merely sitting in Indicators\ would not follow it
//--- there; an embedded one always does.
#resource "\\Indicators\\Survival\\SurvivalPanel.ex5"

//+------------------------------------------------------------------+
//| A deliberately ordinary strategy.                                |
//|                                                                  |
//|  Nothing here is tuned and none of it is a recommendation. The   |
//|  panel needs a history with a spread of holding times and both   |
//|  outcomes in it, and a breakout with a wide target and a tight   |
//|  stop supplies exactly that: mostly short losing trades, a few   |
//|  long winners, and a low win rate. That shape is also where the  |
//|  competing-risks gap is widest, which is what makes it worth     |
//|  looking at on a panel.                                          |
//|                                                                  |
//|  One position at a time, closed only by its stop or its target,  |
//|  so every duration the panel reads is the natural life of the    |
//|  trade rather than an artefact of the Expert interfering.        |
//+------------------------------------------------------------------+

input group           "=== Strategy ==="
input int             InpDonchian   =40;      // channel lookback, bars
input double          InpSlAtr      =1.5;     // stop, in ATR
input double          InpTpAtr      =4.0;     // target, in ATR
input int             InpAtrPeriod  =14;      // ATR period sizing both
input double          InpLots       =0.10;    // fixed volume
input long            InpMagic      =7701;    // magic, also the panel filter

input group           "=== Panel ==="
input bool            InpShowPanel  =true;    // attach SurvivalPanel
input int             InpHorizon    =10;      // forward window, bars
input int             InpMinAtRisk  =20;      // smallest risk set to trust

CTrade                g_trade;
int                   g_atr  =INVALID_HANDLE;
int                   g_panel=INVALID_HANDLE;
datetime              g_bar  =0;

//+------------------------------------------------------------------+
//| Create the ATR, then the panel.                                  |
//|                                                                  |
//|  Note the two empty strings in the iCustom call. An 'input       |
//|  group' occupies a parameter slot of its own, so every group     |
//|  needs a "" placeholder. Omit one and every argument after it    |
//|  shifts down by a position, silently, because the types still    |
//|  convert. Trailing arguments may be dropped, which is why the    |
//|  panel's appearance inputs are absent and keep their defaults.   |
//+------------------------------------------------------------------+
int OnInit(void)
  {
   g_trade.SetExpertMagicNumber(InpMagic);
   g_trade.SetTypeFillingBySymbol(_Symbol);

   g_atr=iATR(_Symbol,PERIOD_CURRENT,InpAtrPeriod);
   if(g_atr==INVALID_HANDLE)
     {
      Print("SurvivalDemo: cannot create ATR handle");
      return(INIT_FAILED);
     }

   if(InpShowPanel)
     {
      g_panel=iCustom(_Symbol,PERIOD_CURRENT,
                      "::Indicators\\Survival\\SurvivalPanel.ex5",
                      "",                    // group: Sample
                      0,                     // InpLookbackDays
                      InpMagic,              // InpMagicA
                      "",                    // group: Diagnostic
                      InpHorizon,            // InpHorizon
                      InpMinAtRisk);         // InpMinAtRisk
      if(g_panel==INVALID_HANDLE)
        {
         Print("SurvivalDemo: cannot create SurvivalPanel handle");
         return(INIT_FAILED);
        }
     }

   g_bar=0;
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//| Release both handles; the panel clears its own objects.          |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   if(g_atr!=INVALID_HANDLE)
      IndicatorRelease(g_atr);
   if(g_panel!=INVALID_HANDLE)
      IndicatorRelease(g_panel);
  }

//+------------------------------------------------------------------+
//| One decision per closed bar.                                     |
//+------------------------------------------------------------------+
void OnTick(void)
  {
   const datetime bar=iTime(_Symbol,PERIOD_CURRENT,0);
   if(bar==g_bar)
      return;
   g_bar=bar;

   if(HasPosition())
      return;                              // stop and target do the exits

   double hi[],lo[],cl[],atr[];
   ArraySetAsSeries(hi,false);
   ArraySetAsSeries(lo,false);

//--- the channel is measured on the bars BEFORE the one that breaks
//--- it, so bar 1 is compared against bars 2..N+1 and never itself.
   if(CopyHigh(_Symbol,PERIOD_CURRENT,2,InpDonchian,hi)<InpDonchian)
      return;
   if(CopyLow(_Symbol,PERIOD_CURRENT,2,InpDonchian,lo)<InpDonchian)
      return;
   if(CopyClose(_Symbol,PERIOD_CURRENT,1,1,cl)<1)
      return;
   if(CopyBuffer(g_atr,0,1,1,atr)<1 || atr[0]<=0.0)
      return;

   const double upper=hi[ArrayMaximum(hi)];
   const double lower=lo[ArrayMinimum(lo)];
   const double a    =atr[0];

   if(cl[0]>upper)
      Enter(true,a);
   else
      if(cl[0]<lower)
         Enter(false,a);
  }

//+------------------------------------------------------------------+
//| Open one position with ATR-scaled stop and target.               |
//+------------------------------------------------------------------+
void Enter(const bool is_buy,const double atr)
  {
   const int    dg  =(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);
   const double ask =SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   const double bid =SymbolInfoDouble(_Symbol,SYMBOL_BID);
   const double px  =(is_buy ? ask : bid);
   if(px<=0.0)
      return;

   const double sl=NormalizeDouble(is_buy ? px-atr*InpSlAtr
                                   : px+atr*InpSlAtr,dg);
   const double tp=NormalizeDouble(is_buy ? px+atr*InpTpAtr
                                   : px-atr*InpTpAtr,dg);

   if(is_buy)
      g_trade.Buy(InpLots,_Symbol,0.0,sl,tp,"survdemo");
   else
      g_trade.Sell(InpLots,_Symbol,0.0,sl,tp,"survdemo");
  }

//+------------------------------------------------------------------+
//| Is one of ours already running on this symbol?                   |
//+------------------------------------------------------------------+
bool HasPosition(void)
  {
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      const ulong tk=PositionGetTicket(i);
      if(tk==0)
         continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol)
         continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic)
         continue;
      return(true);
     }
   return(false);
  }
//+------------------------------------------------------------------+
