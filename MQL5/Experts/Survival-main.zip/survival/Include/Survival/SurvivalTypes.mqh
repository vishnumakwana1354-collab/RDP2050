//+------------------------------------------------------------------+
//|                                                SurvivalTypes.mqh |
//|                                      MMQ — Muhammad Minhas Qamar |
//|                                   www.mql5.com/en/articles/23928 |
//+------------------------------------------------------------------+
#property copyright "MMQ — Muhammad Minhas Qamar"
#property link      "https://www.mql5.com/en/articles/23928"
#property version   "1.00"
#property strict

//+------------------------------------------------------------------+
//| Shared vocabulary for the estimators and the history reader.     |
//|                                                                  |
//|  A trade contributes two numbers: how long it was observed, and  |
//|  what ended it. The second has three answers rather than two -   |
//|  win and loss are competing terminal events, and only a position |
//|  still open at the cutoff is censored. Collapsing three back to  |
//|  two is the standard error here; see CSurvival, which implements |
//|  both the estimator that respects the difference and the one     |
//|  that does not.                                                  |
//+------------------------------------------------------------------+

//--- upper bound on a duration, purely a sanity guard on caller input.
#define SURV_MAX_DURATION 200000

//--- cause selector for the routines that work one event type at a
//--- time. SURV_CAUSE_ALL pools both terminal events into one.
#define SURV_CAUSE_ALL   (-1)
#define SURV_CAUSE_WIN     0
#define SURV_CAUSE_LOSS    1

//+------------------------------------------------------------------+
//| What ended the observation of one trade. WIN and LOSS compete;   |
//| OPEN is the censoring category.                                  |
//+------------------------------------------------------------------+
enum ENUM_SURV_OUTCOME
  {
   SURV_OUTCOME_WIN=0,                 // closed in profit  - terminal event
   SURV_OUTCOME_LOSS=1,                // closed at a loss  - terminal event
   SURV_OUTCOME_OPEN=2                 // open at cutoff    - censored
  };

//+------------------------------------------------------------------+
//| One trade, reduced to what an estimator actually needs.          |
//+------------------------------------------------------------------+
struct SurvObservation
  {
   int               duration;         // bars survived, entry to exit
   ENUM_SURV_OUTCOME outcome;          // which of the three ended it
   long              group;            // magic number / strategy id
  };

//+------------------------------------------------------------------+
//| Bars of 'tf' spanned by an interval, endpoints included.         |
//|                                                                  |
//|  Bars, not seconds: a position carried over a weekend accrues    |
//|  clock time in which price could not move, and charging the      |
//|  trade for it smears every curve. Subtracting one turns "bars    |
//|  touched" into "bars survived", so a trade opened and closed     |
//|  inside one bar is zero. The reader and the panel must both      |
//|  call this or they will disagree about how old a position is.    |
//|  The fallback covers a symbol whose history is not built yet.    |
//+------------------------------------------------------------------+
int SurvBarsBetween(const string symbol,const ENUM_TIMEFRAMES tf,
                    const datetime t0,const datetime t1)
  {
   if(t1<=t0)
      return(0);

   const int counted=Bars(symbol,tf,t0,t1);
   if(counted>0)
      return(counted-1);

   const int secs=PeriodSeconds(tf);
   if(secs<=0)
      return(0);
   return((int)((t1-t0)/secs));
  }

//+------------------------------------------------------------------+
