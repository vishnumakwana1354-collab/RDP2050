//+------------------------------------------------------------------+
//|                                                 TradeHistory.mqh |
//|                                      MMQ — Muhammad Minhas Qamar |
//|                                   www.mql5.com/en/articles/23928 |
//+------------------------------------------------------------------+
#property copyright "MMQ — Muhammad Minhas Qamar"
#property link      "https://www.mql5.com/en/articles/23928"
#property version   "1.00"
#property strict

#include <Survival\SurvivalTypes.mqh>

//+------------------------------------------------------------------+
//| CTradeHistoryReader - deal history reduced to observations.      |
//|                                                                  |
//|  The History API behaves identically in the Strategy Tester and  |
//|  on a live account, so one reader serves both: nothing written   |
//|  to disk, no tester report parsed back, one implementation.      |
//|                                                                  |
//|  Reading is driven by three timestamps:                          |
//|                                                                  |
//|    entry_from / entry_to   which trades belong to this sample,   |
//|                            selected on the bar they were opened  |
//|                                                                  |
//|    censor_at               the moment observation stops          |
//|                                                                  |
//|  A position open at censor_at is reported SURV_OUTCOME_OPEN      |
//|  with its duration truncated there, even when the history read   |
//|  later shows how it ended. Refusing to look is the point: a      |
//|  curve states what was knowable at the cutoff. Passing           |
//|  TimeCurrent() turns that same branch into what the panel wants  |
//|  - positions open right now become censored observations in the  |
//|  textbook sense, with no special case anywhere.                  |
//+------------------------------------------------------------------+
class CTradeHistoryReader
  {
private:
//--- one reconstructed position, assembled from its deals
   struct PosRecord
     {
      long           pid;              // POSITION_ID, the join key
      long           magic;            // becomes the observation group
      string         symbol;           // whose bars measure the duration
      datetime       t_in;             // first DEAL_ENTRY_IN
      datetime       t_out;            // closing deal, 0 while running
      double         pnl;              // profit + swap + commission
      bool           has_in;           // guards truncated histories
      bool           closed;           // a closing deal was seen
     };

   ENUM_TIMEFRAMES   m_tf;             // timeframe the bar clock runs on
   string            m_symbol;         // "" accepts every symbol
   PosRecord         m_pos[];
   int               m_used;           // live entries in m_pos
   int               m_last;           // last index matched, the fast path
   int               m_skipped_no_in;  // closes whose open predates history

   int               Find(const long pid);

public:
                     CTradeHistoryReader(void);

//--- Timeframe is the unit every duration is quoted in, so it must
//--- match the bar clock the Expert trades on. Symbol may be left
//--- empty to pool a multi-symbol account.
   void              Configure(const ENUM_TIMEFRAMES tf,const string symbol="");

//--- Build observations for every position opened in
//--- [entry_from, entry_to) as they appeared at censor_at.
   int               Read(const datetime entry_from,const datetime entry_to,
                          const datetime censor_at,SurvObservation &out[]);

//--- Closing deals whose opening deal was not in the selected
//--- history. Non-zero means the broker's history has been trimmed
//--- and the sample is missing its earliest trades.
   int               SkippedNoEntry(void) const { return m_skipped_no_in; }

//--- Positions assembled on the last read, before any windowing.
   int               PositionsSeen(void) const { return m_used; }
  };

//+------------------------------------------------------------------+
//| Default to the chart timeframe and every symbol on the account.  |
//+------------------------------------------------------------------+
CTradeHistoryReader::CTradeHistoryReader(void)
  {
   m_tf            =PERIOD_CURRENT;
   m_symbol        ="";
   m_used          =0;
   m_last          =-1;
   m_skipped_no_in =0;
  }

//+------------------------------------------------------------------+
//| Fix the bar clock and the symbol filter for subsequent reads.    |
//+------------------------------------------------------------------+
void CTradeHistoryReader::Configure(const ENUM_TIMEFRAMES tf,const string symbol)
  {
   m_tf    =(tf==PERIOD_CURRENT ? (ENUM_TIMEFRAMES)Period() : tf);
   m_symbol=symbol;
  }

//+------------------------------------------------------------------+
//| Locate a position record by id.                                  |
//|                                                                  |
//|  Deals are iterated in time order and a position's deals sit     |
//|  together, so the previous match is usually the right answer;    |
//|  that check is what keeps the join near-linear. The backward     |
//|  scan behind it is the correctness fallback for a position       |
//|  closed long after it was opened, and it is linear in the worst  |
//|  case - see the article for when that starts to matter.          |
//+------------------------------------------------------------------+
int CTradeHistoryReader::Find(const long pid)
  {
   if(m_last>=0 && m_last<m_used && m_pos[m_last].pid==pid)
      return(m_last);

   for(int i=m_used-1;i>=0;i--)
     {
      if(m_pos[i].pid!=pid)
         continue;
      m_last=i;
      return(i);
     }
   return(-1);
  }

//+------------------------------------------------------------------+
//| Assemble positions from deals, then censor them at the cutoff.   |
//|                                                                  |
//|  Two passes. The first joins deals into positions on             |
//|  POSITION_ID, accumulating money across every deal so partial    |
//|  closes and commission land in the same total. The second turns  |
//|  each position into an observation, and it is there that a       |
//|  close occurring after censor_at is demoted back to open.        |
//|                                                                  |
//|  Outcome is taken from the sign of net money rather than from    |
//|  the closing deal's reason code. Reason codes only classify the  |
//|  exits the terminal recognises, so a strategy that ever closes   |
//|  a position itself would leave a hole in the sample; money is    |
//|  defined for every exit and is what "reached target" means to    |
//|  the account. A flat result counts as a loss, since it is not a  |
//|  win and the two categories have to partition the outcomes.      |
//+------------------------------------------------------------------+
int CTradeHistoryReader::Read(const datetime entry_from,const datetime entry_to,
                              const datetime censor_at,SurvObservation &out[])
  {
   ArrayFree(out);
   ArrayFree(m_pos);
   m_used          =0;
   m_last          =-1;
   m_skipped_no_in =0;

//--- Select everything: narrowing to the cutoff would leave a
//--- part-closed position showing a partial exit as its final one.
   if(!HistorySelect(0,(datetime)TimeCurrent()+86400))
      return(0);

   const int deals=HistoryDealsTotal();
   for(int i=0;i<deals;i++)
     {
      const ulong ticket=HistoryDealGetTicket(i);
      if(ticket==0)
         continue;

      const ENUM_DEAL_TYPE dtype=
         (ENUM_DEAL_TYPE)HistoryDealGetInteger(ticket,DEAL_TYPE);
      if(dtype!=DEAL_TYPE_BUY && dtype!=DEAL_TYPE_SELL)
         continue;                     // balance, credit, corrections

      const string sym=HistoryDealGetString(ticket,DEAL_SYMBOL);
      if(m_symbol!="" && sym!=m_symbol)
         continue;

      const long pid=HistoryDealGetInteger(ticket,DEAL_POSITION_ID);
      if(pid==0)
         continue;

      const ENUM_DEAL_ENTRY entry=
         (ENUM_DEAL_ENTRY)HistoryDealGetInteger(ticket,DEAL_ENTRY);
      if(entry==DEAL_ENTRY_STATE)
         continue;                     // state change, not a fill

      int k=Find(pid);
      if(k<0)
        {
         k=m_used;
         //--- grown in blocks; resizing by one per deal is the
         //--- standard way to make an MQL5 reader quadratic.
         if(ArrayResize(m_pos,m_used+1,4096)<0)
            return(0);
         m_used++;
         m_last          =k;
         m_pos[k].pid    =pid;
         m_pos[k].magic  =0;
         m_pos[k].symbol =sym;
         m_pos[k].t_in   =0;
         m_pos[k].t_out  =0;
         m_pos[k].pnl    =0.0;
         m_pos[k].has_in =false;
         m_pos[k].closed =false;
        }

      const datetime dt=(datetime)HistoryDealGetInteger(ticket,DEAL_TIME);

      //--- Only money realised by the cutoff. A position closing after
      //--- censor_at is reported open below, and adding its closing
      //--- deal would stamp it with a result not yet knowable.
      if(dt<=censor_at)
         m_pos[k].pnl += HistoryDealGetDouble(ticket,DEAL_PROFIT)
                         +HistoryDealGetDouble(ticket,DEAL_SWAP)
                         +HistoryDealGetDouble(ticket,DEAL_COMMISSION);

      if(entry==DEAL_ENTRY_IN)
        {
         if(!m_pos[k].has_in)
           {
            m_pos[k].t_in  =dt;
            m_pos[k].magic =HistoryDealGetInteger(ticket,DEAL_MAGIC);
            m_pos[k].symbol=sym;
            m_pos[k].has_in=true;
           }
        }
      else
        {
         //--- OUT, OUT_BY and the netting reversal INOUT all end the
         //--- position that was running; the last one wins so a
         //--- partially closed position is timed to its final exit.
         m_pos[k].t_out =dt;
         m_pos[k].closed=true;
        }
     }

//--- second pass: censor, measure, emit.
   if(m_used>0 && ArrayResize(out,m_used)<0)
      return(0);

   int n=0;
   for(int k=0;k<m_used;k++)
     {
      if(!m_pos[k].has_in)
        {
         if(m_pos[k].closed)
            m_skipped_no_in++;
         continue;
        }

      const datetime t_in=m_pos[k].t_in;
      if(t_in<entry_from || t_in>=entry_to || t_in>censor_at)
         continue;

      const bool decided=(m_pos[k].closed && m_pos[k].t_out<=censor_at);
      const datetime t_end=(decided ? m_pos[k].t_out : censor_at);

      out[n].duration=SurvBarsBetween(m_pos[k].symbol,m_tf,t_in,t_end);
      out[n].group   =m_pos[k].magic;

      if(!decided)
         out[n].outcome=SURV_OUTCOME_OPEN;
      else
         out[n].outcome=(m_pos[k].pnl>0.0 ? SURV_OUTCOME_WIN
                         : SURV_OUTCOME_LOSS);
      n++;
     }

   ArrayResize(out,n);
   return(n);
  }
//+------------------------------------------------------------------+
