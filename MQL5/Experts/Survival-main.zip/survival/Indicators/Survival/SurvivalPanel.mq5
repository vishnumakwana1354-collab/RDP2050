//+------------------------------------------------------------------+
//|                                                SurvivalPanel.mq5 |
//|                                      MMQ — Muhammad Minhas Qamar |
//|                                   www.mql5.com/en/articles/23928 |
//+------------------------------------------------------------------+
#property copyright "MMQ — Muhammad Minhas Qamar"
#property link      "https://www.mql5.com/en/articles/23928"
#property version   "1.00"
#property strict
#property description "Survival analysis of this symbol's trade history:"
#property description "how long positions live, and what a position that"
#property description "has already survived N bars is still likely to do."
#property indicator_chart_window
#property indicator_buffers 0
#property indicator_plots   0

#include <Survival\SurvivalTypes.mqh>
#include <Survival\SurvivalCore.mqh>
#include <Survival\TradeHistory.mqh>

//+------------------------------------------------------------------+
//| A read-only panel, deliberately.                                 |
//|                                                                  |
//|  This is an indicator and not an Expert because a chart has one  |
//|  Expert slot and the reader's strategy is already in it. Nothing |
//|  here trades, and nothing here tells you to.                     |
//|                                                                  |
//|  The headline number is conditional: P(target | survived to bar  |
//|  N). A win rate answers "what fraction of all trades ever opened |
//|  reached target", which is not the question in front of someone  |
//|  holding a position that is already N bars old.                  |
//|                                                                  |
//|  Every figure carries the risk set it was computed from, because |
//|  a curve fitted on nine trades looks exactly like one fitted on  |
//|  nine hundred, and every survival curve degenerates in its tail. |
//+------------------------------------------------------------------+

input group           "=== Sample ==="
input int             InpLookbackDays =0;             // history depth, days (0 = all)
input long            InpMagicA       =-1;            // magic to analyse (-1 = all)

input group           "=== Diagnostic ==="
input int             InpHorizon      =10;            // forward window, bars
input int             InpMinAtRisk    =20;            // smallest risk set worth reading

input group           "=== Panel ==="
input ENUM_BASE_CORNER InpCorner      =CORNER_LEFT_UPPER; // anchor
input int             InpX            =14;            // x offset, px
input int             InpY            =14;            // y offset, px
input int             InpFontSize     =9;             // font size
input color           InpColBg        =C'252,252,253';// panel fill
input color           InpColBorder    =C'202,209,220';// panel border
input color           InpColTitle     =C'21,94,182';  // title
input color           InpColSection   =C'112,124,142';// section headings
input color           InpColText      =C'32,38,48';   // body text
input color           InpColLive      =C'166,102,0';  // live position block
input color           InpColWarn      =C'186,58,16';  // thin-sample warnings

//--- object names all share this, so cleanup is one call.
const string PANEL_PREFIX="SurvPanel_";
const string PANEL_BG   =PANEL_PREFIX+"bg";

//--- a row carrying this instead of text becomes a horizontal rule,
//--- drawn once the widest line is known.
const string PANEL_RULE ="\x01";

//--- every value column lands here, so the numbers line up in one
//--- vertical stack rather than trailing their labels.
#define PANEL_COLS 42

CTradeHistoryReader   g_reader;
CSurvival             g_surv;
SurvObservation       g_obs[];            // everything read, both magics
SurvObservation       g_fit[];            // the subset the curves are fitted on
int                   g_obs_count=0;

datetime              g_last_bar=0;       // bar the panel was last rebuilt on
string                g_last_key="";      // position state, to catch a change
int                   g_rows    =0;       // labels currently on the chart

//+------------------------------------------------------------------+
//| Attach: fix the bar clock to this chart and draw nothing yet.    |
//+------------------------------------------------------------------+
int OnInit(void)
  {
   IndicatorSetString(INDICATOR_SHORTNAME,"Survival Panel");
   g_reader.Configure((ENUM_TIMEFRAMES)Period(),_Symbol);
   g_last_bar=0;
   g_last_key="";
   g_rows    =0;
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//| Detach: the panel owns every object carrying its prefix.         |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   ObjectsDeleteAll(0,PANEL_PREFIX);
   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
//| Refit only when the sample can actually have changed.            |
//|                                                                  |
//|  The numbers move when a bar closes (the live position ages) or  |
//|  when the position state changes (the sample changes), and       |
//|  LiveKey() folds the second into one comparison. Selecting the   |
//|  whole deal history per tick would crawl in a long test.         |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   const datetime bar=(rates_total>0 ? iTime(_Symbol,Period(),0) : 0);
   const string   key=LiveKey();

   if(prev_calculated==0 || bar!=g_last_bar || key!=g_last_key)
     {
      g_last_bar=bar;
      g_last_key=key;
      Rebuild();
      Render();
     }
   return(rates_total);
  }

//+------------------------------------------------------------------+
//| Read the history and fit the curves for the selected magic.      |
//|                                                                  |
//|  TimeCurrent() as the cutoff is what makes the open positions    |
//|  censored observations rather than missing ones: they are still  |
//|  under observation and their outcome is genuinely undecided, so  |
//|  they belong in the risk set and nowhere else.                   |
//+------------------------------------------------------------------+
void Rebuild(void)
  {
   const datetime now=TimeCurrent();
   const datetime from=(InpLookbackDays>0
                        ? now-(datetime)InpLookbackDays*86400 : 0);

   g_obs_count=g_reader.Read(from,now+1,now,g_obs);

//--- Fit resets itself on an empty or rejected sample, so a failure
//--- needs no handling here: the panel reads Count()==0 and says so.
   if(InpMagicA>=0)
     {
      const int kept=SurvFilterByGroup(g_obs,g_obs_count,InpMagicA,g_fit);
      g_surv.Fit(g_fit,kept);
     }
   else
      g_surv.Fit(g_obs,g_obs_count);
  }

//+------------------------------------------------------------------+
//| This chart's open position for the selected magic, with the      |
//| identity and size the refresh gate is keyed on.                  |
//+------------------------------------------------------------------+
bool LivePosition(datetime &t_open,ulong &ticket,double &volume)
  {
   t_open=0;
   ticket=0;
   volume=0.0;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      const ulong tk=PositionGetTicket(i);
      if(tk==0)
         continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol)
         continue;
      if(InpMagicA>=0 && PositionGetInteger(POSITION_MAGIC)!=InpMagicA)
         continue;
      t_open=(datetime)PositionGetInteger(POSITION_TIME);
      ticket=tk;
      volume=PositionGetDouble(POSITION_VOLUME);
      return(true);
     }
   return(false);
  }

//+------------------------------------------------------------------+
//| Everything the panel reads besides the bar, as one string.       |
//|                                                                  |
//|  A position count alone misses every change that leaves it       |
//|  intact: a partial close, a netting reversal, a close and an     |
//|  open inside one bar, or a swap of which position is first.      |
//+------------------------------------------------------------------+
string LiveKey(void)
  {
   datetime t_open=0;
   ulong    ticket=0;
   double   volume=0.0;
   LivePosition(t_open,ticket,volume);
   return(StringFormat("%d|%I64u|%.2f|%I64d",PositionsTotal(),ticket,
                       volume,(long)t_open));
  }

//+------------------------------------------------------------------+
//| The ages the aging block is sampled at: entry, then the three    |
//| quartiles of holding time.                                       |
//|                                                                  |
//|  Quartiles rather than fixed bar numbers, so the block scales to |
//|  whatever this strategy's holding times happen to be instead of  |
//|  printing the same row four times on a fast system. Duplicates   |
//|  and unreached quantiles both fall out of the ascending test.    |
//+------------------------------------------------------------------+
int AgingAges(int &ages[])
  {
   ArrayResize(ages,4);
   ages[0]=0;
   int n=1;

   const double q[3]={0.75,0.5,0.25};
   for(int i=0;i<3;i++)
     {
      const int a=g_surv.QuantileDuration(q[i]);
      if(a>ages[n-1])
        {
         ages[n]=a;
         n++;
        }
     }
   ArrayResize(ages,n);
   return(n);
  }

//+------------------------------------------------------------------+
//| Compose the panel text and push it to the chart.                 |
//+------------------------------------------------------------------+
void Render(void)
  {
   string  txt[];
   color   col[];
   int     n=0;

   const string scope=(InpMagicA>=0
                       ? "magic "+IntegerToString(InpMagicA) : "all magics");
   Push(txt,col,n,"SURVIVAL   "+_Symbol+"  "+
        StringSubstr(EnumToString((ENUM_TIMEFRAMES)Period()),7)+
        "   "+scope,InpColTitle);
   Push(txt,col,n,PANEL_RULE,InpColBorder);

   if(g_surv.Count()<=0)
     {
      Push(txt,col,n,"  no closed trades in this window yet",InpColWarn);
      Commit(txt,col,n);
      return;
     }

//--- sample composition. A curve fitted on nine trades looks exactly
//--- like one fitted on nine hundred, so this never gets omitted.
   Push(txt,col,n,"SAMPLE",InpColSection);
   Push(txt,col,n,Kv("trades",IntegerToString(g_surv.Count())),InpColText);
   Push(txt,col,n,Kv("win / loss / open",
                     StringFormat("%d / %d / %d",g_surv.Wins(),
                                  g_surv.Losses(),g_surv.Censored())),
        InpColText);

   const int med=g_surv.MedianDuration();
   Push(txt,col,n,Kv("median held",(med>=0
                                    ? IntegerToString(med)+" bars"
                                    : "not reached")),InpColText);

   const int skipped=g_reader.SkippedNoEntry();
   if(skipped>0)
      Push(txt,col,n,Kv("closes predating history",
                        IntegerToString(skipped)),InpColWarn);

//--- the live position, which is the whole reason this runs on a chart.
   Push(txt,col,n,PANEL_RULE,InpColBorder);
   Push(txt,col,n,"OPEN POSITION",InpColSection);
   datetime t_open=0;
   ulong    t_tick=0;
   double   t_vol =0.0;
   if(LivePosition(t_open,t_tick,t_vol))
     {
      const int age=SurvBarsBetween(_Symbol,(ENUM_TIMEFRAMES)Period(),
                                    t_open,TimeCurrent());
      const double p_win =g_surv.ConditionalIncidence(age,InpHorizon,
                                                      SURV_CAUSE_WIN);
      const double p_loss=g_surv.ConditionalIncidence(age,InpHorizon,
                                                      SURV_CAUSE_LOSS);
      const double haz   =g_surv.HazardAt(age,SURV_CAUSE_ALL);
      const int    risk  =g_surv.AtRiskAt(age);

      Push(txt,col,n,Kv("age",IntegerToString(age)+" bars"),InpColLive);
      Push(txt,col,n,Kv("P(target) within "+IntegerToString(InpHorizon),
                        StringFormat("%.2f %%",p_win*100.0)),InpColLive);
      Push(txt,col,n,Kv("P(stop)   within "+IntegerToString(InpHorizon),
                        StringFormat("%.2f %%",p_loss*100.0)),InpColLive);
      Push(txt,col,n,Kv("hazard at this bar",
                        StringFormat("%.2f %%",haz*100.0)),InpColLive);
      Push(txt,col,n,Kv("trades at this age",IntegerToString(risk)),
           (risk<InpMinAtRisk ? InpColWarn : InpColText));
      if(risk<InpMinAtRisk)
         Push(txt,col,n,"  thin sample - read with suspicion",InpColWarn);
     }
   else
      Push(txt,col,n,Kv("none open","-"),InpColText);

//--- how the same question answers differently at different ages.
//--- This is the aging profile the whole library exists to produce.
   Push(txt,col,n,PANEL_RULE,InpColBorder);
   Push(txt,col,n,"AGING   P(target within "+IntegerToString(InpHorizon)+
        " | age)",InpColSection);
   int ages[];
   const int na=AgingAges(ages);
   for(int i=0;i<na;i++)
     {
      const double p=g_surv.ConditionalIncidence(ages[i],InpHorizon,
                                                 SURV_CAUSE_WIN);
      const int    r=g_surv.AtRiskAt(ages[i]);
      Push(txt,col,n,Kv("age "+IntegerToString(ages[i])+
                        "  (n="+IntegerToString(r)+")",
                        StringFormat("%.2f %%",p*100.0)),
           (r<InpMinAtRisk ? InpColWarn : InpColText));
     }

//--- the competing-risks gap, read where the risk set can still
//--- support it rather than at the very end of the curve.
   Push(txt,col,n,PANEL_RULE,InpColBorder);
   const int end =g_surv.MaxDuration();
   const int safe=g_surv.ReliableBar(InpMinAtRisk);
   const int at  =(safe>=0 ? safe : end);
   const double cif  =g_surv.IncidenceAt(at,SURV_CAUSE_WIN);
   const double naive=g_surv.NaiveIncidenceAt(at);

   Push(txt,col,n,"REACH TARGET BY BAR "+IntegerToString(at)+
        "   (n="+IntegerToString(g_surv.AtRiskAt(at))+")",InpColSection);
   Push(txt,col,n,Kv("competing risks",
                     StringFormat("%.2f %%",cif*100.0)),InpColText);
   Push(txt,col,n,Kv("losses censored",
                     StringFormat("%.2f %%",naive*100.0)),InpColText);
   if(cif>0.0)
      Push(txt,col,n,Kv("overstated by",
                        StringFormat("%+.1f %%",(naive/cif-1.0)*100.0)),
           InpColWarn);

   if(safe<0)
      Push(txt,col,n,"  no bar holds "+IntegerToString(InpMinAtRisk)+
           " trades - every figure is thin",InpColWarn);
   else
      if(end>safe)
         Push(txt,col,n,Kv("naive at bar "+IntegerToString(end)+
                           " (n="+IntegerToString(g_surv.AtRiskAt(end))+")",
                           StringFormat("%.2f %%",
                                        g_surv.NaiveIncidenceAt(end)*100.0)),
              InpColWarn);

   Commit(txt,col,n);
  }

//+------------------------------------------------------------------+
//| Append one line to the pending panel.                            |
//+------------------------------------------------------------------+
void Push(string &txt[],color &col[],int &n,const string s,const color c)
  {
   if(ArrayResize(txt,n+1,64)<0 || ArrayResize(col,n+1,64)<0)
      return;
   txt[n]=s;
   col[n]=c;
   n++;
  }

//+------------------------------------------------------------------+
//| "label ................ value", padded to one value column.      |
//|                                                                  |
//|  Right-aligning by padding only works because the face is fixed  |
//|  width; in a proportional font the same character count is a     |
//|  different number of pixels and the column would wander.         |
//+------------------------------------------------------------------+
string Kv(const string k,const string v)
  {
   int pad=PANEL_COLS-2-StringLen(k)-StringLen(v);
   if(pad<1)
      pad=1;

   string s="  "+k;
   for(int i=0;i<pad;i++)
      s+=" ";
   return(s+v);
  }

//+------------------------------------------------------------------+
//| Draw the pending lines and retire any left over from last time.  |
//|                                                                  |
//|  The rules are filled in here rather than in Render because      |
//|  their width is not known until every row has been composed.     |
//+------------------------------------------------------------------+
void Commit(const string &txt[],const color &col[],const int n)
  {
   int wide=0;
   for(int i=0;i<n;i++)
      if(txt[i]!=PANEL_RULE && StringLen(txt[i])>wide)
         wide=StringLen(txt[i]);

   string rule="";
   for(int i=0;i<wide;i++)
      rule+="─";

   Background(wide,n);
   for(int i=0;i<n;i++)
      Label(i,(txt[i]==PANEL_RULE ? rule : txt[i]),col[i]);

   for(int i=n;i<g_rows;i++)
      ObjectDelete(0,PANEL_PREFIX+IntegerToString(i));

   g_rows=n;
   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
//| The opaque plate everything else sits on.                        |
//|                                                                  |
//|  Without it the text renders straight onto the candles and is    |
//|  unreadable wherever price happens to be. It is sized from the   |
//|  measured text rather than a guess, so the plate fits whatever   |
//|  the rows happen to say. BACK is false so it draws over the      |
//|  candles rather than behind them, and SELECTABLE is false so     |
//|  clicks and the crosshair still reach the chart underneath.      |
//+------------------------------------------------------------------+
void Background(const int cols,const int rows)
  {
   const int pad_x=12;
   const int pad_y=10;

   uint tw=0,th=0;
   TextSetFont("Consolas",-InpFontSize*10);
   TextGetSize("M",tw,th);
   const int cw=(tw>0 ? (int)tw : InpFontSize);
   const int rh=RowHeight();

   if(ObjectFind(0,PANEL_BG)<0)
     {
      ObjectCreate(0,PANEL_BG,OBJ_RECTANGLE_LABEL,0,0,0);
      ObjectSetInteger(0,PANEL_BG,OBJPROP_CORNER,InpCorner);
      ObjectSetInteger(0,PANEL_BG,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,PANEL_BG,OBJPROP_HIDDEN,true);
      ObjectSetInteger(0,PANEL_BG,OBJPROP_BACK,false);
      ObjectSetInteger(0,PANEL_BG,OBJPROP_BORDER_TYPE,BORDER_FLAT);
      ObjectSetInteger(0,PANEL_BG,OBJPROP_STYLE,STYLE_SOLID);
      ObjectSetInteger(0,PANEL_BG,OBJPROP_WIDTH,1);
     }
   ObjectSetInteger(0,PANEL_BG,OBJPROP_XDISTANCE,InpX-pad_x);
   ObjectSetInteger(0,PANEL_BG,OBJPROP_YDISTANCE,InpY-pad_y);
   ObjectSetInteger(0,PANEL_BG,OBJPROP_XSIZE,cols*cw+pad_x*2);
   ObjectSetInteger(0,PANEL_BG,OBJPROP_YSIZE,rows*rh+pad_y*2);
   ObjectSetInteger(0,PANEL_BG,OBJPROP_BGCOLOR,InpColBg);
   ObjectSetInteger(0,PANEL_BG,OBJPROP_COLOR,InpColBorder);
  }

//+------------------------------------------------------------------+
//| Baseline-to-baseline spacing, measured not assumed.              |
//+------------------------------------------------------------------+
int RowHeight(void)
  {
   uint tw=0,th=0;
   TextSetFont("Consolas",-InpFontSize*10);
   if(TextGetSize("Mg",tw,th) && th>0)
      return((int)th+3);
   return(InpFontSize+7);
  }

//+------------------------------------------------------------------+
//| One text label, created on first use and updated thereafter.     |
//+------------------------------------------------------------------+
void Label(const int row,const string text,const color clr)
  {
   const string name=PANEL_PREFIX+IntegerToString(row);
   if(ObjectFind(0,name)<0)
     {
      ObjectCreate(0,name,OBJ_LABEL,0,0,0);
      ObjectSetInteger(0,name,OBJPROP_CORNER,InpCorner);
      ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
      ObjectSetInteger(0,name,OBJPROP_BACK,false);
      //--- a fixed-width face is what keeps the columns lined up.
      ObjectSetString(0,name,OBJPROP_FONT,"Consolas");
      ObjectSetInteger(0,name,OBJPROP_FONTSIZE,InpFontSize);
     }
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,InpX);
   ObjectSetInteger(0,name,OBJPROP_YDISTANCE,InpY+row*RowHeight());
   ObjectSetInteger(0,name,OBJPROP_COLOR,clr);
   ObjectSetString(0,name,OBJPROP_TEXT,text);
  }
//+------------------------------------------------------------------+
