﻿//+------------------------------------------------------------------+
//|                         JGV FX NO LOSS RECOVERY PRO ENHANCED     |
//|                                  Copyright 2024, JGV FX Premium  |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright "Copyright 2024, JGV FX"
#property link      "https://www.mql5.com"
#property version   "4.00"
#property strict

#include <Trade\Trade.mqh>
#include <Trade\PositionInfo.mqh>
#include <Trade\SymbolInfo.mqh>

//--- Enums for Advanced Logic
enum ENUM_RECOVERY_MODE {
   RECOVERY_GRID,    // Standard Martingale Grid
   RECOVERY_HEDGE,   // Hedging recovery (Advanced)
   RECOVERY_SMART    // ADX-Volatily Based Spacing
};

enum ENUM_TRADING_SESSION {
   SESSION_ASIA,      // Asian Session
   SESSION_LONDON,    // London Session
   SESSION_NEWYORK,   // New York Session
   SESSION_SYDNEY     // Sydney Session
};

//--- Input Parameters
input group "---- [1] No-Loss Recovery Settings ----"
input double    InpLotSize        = 0.01;        // Start Lot
input double    InpLotMultiplier  = 1.6;         // Martingale Multiplier
input int       InpMaxOrders      = 100;          // Max Basket Orders
input int       InpGridDistance   = 3000;         // Min Distance between orders (Points)
input int       InpBasketTP       = 100;         // Profit target above Break-Even (Points)
input ENUM_RECOVERY_MODE InpMode  = RECOVERY_SMART; // Recovery Mode

input group "---- [2] Sideway ADX Filter ----"
input int       InpADXPeriod      = 14;          // ADX Period
input double    InpTrendThreshold = 25.0;        // Below this = Sideways (Safe)
input double    InpMinADXEntry    = 15.0;        // Min ADX to avoid "Dead" market

input group "---- [3] Session Filter Settings ----"
input bool      InpUseSessionFilter = true;       // Enable Session Filter
input ENUM_TRADING_SESSION InpTradingSession = SESSION_ASIA; // Select Trading Session
input bool      InpTradeAsia      = true;         // Trade Asian Session
input bool      InpTradeLondon    = true;         // Trade London Session
input bool      InpTradeNewYork   = true;         // Trade New York Session
input bool      InpTradeSydney    = true;         // Trade Sydney Session

input group "---- [4] Time Filter Settings ----"
input bool      InpUseTimeFilter  = true;         // Enable Time Filter
input int       InpStartHour      = 1;            // 24h Format Start
input int       InpEndHour        = 22;           // 24h Format End
input bool      InpTradeWeekend   = false;        // Allow Weekend Trading
input int       InpStartDay       = 1;            // Trade Start Day (1=Monday, 5=Friday)
input int       InpEndDay         = 5;            // Trade End Day (1=Monday, 5=Friday)

input group "---- [5] TimeFrame Filter ----"
input bool      InpUseTimeFrameFilter = true;    // Enable TimeFrame Filter
input ENUM_TIMEFRAMES InpAllowedTimeFrame = PERIOD_M15; // Only M15

input group "---- [6] News Filter Settings ----"
input bool      InpUseNewsFilter  = true;         // Enable News Filter
input int       InpNewsBuffer     = 60;           // Minutes before news to stop trading
input int       InpNewsAfter      = 60;           // Minutes after news to resume trading
input string    InpNewsLevelFilter = "High";      // Filter: "High", "Medium", "All"
input string    InpNewsURL        = "https://nfs.faireconomy.media/ff_calendar_thisweek.csv";

input group "---- [7] Magic Number ----"
input long      InpMagic          = 88899


9;        // Unique Magic Number

//--- Global Variables
CTrade         trade;
CPositionInfo  pos;
CSymbolInfo    sym;
int            handleADX;
datetime       lastNewsTime = 0;
datetime       nextNewsTime = 0;
string         newsCalendarData = "";
bool           newsEventNear = false;

//+------------------------------------------------------------------+
//| Session Time Structures                                          |
//+------------------------------------------------------------------+
struct SessionTime {
   int startHour;
   int startMin;
   int endHour;
   int endMin;
   string name;
};

SessionTime asiaSession = {9, 0, 17, 0, "Asia"};
SessionTime londonSession = {8, 0, 17, 0, "London"};
SessionTime newyorkSession = {13, 0, 22, 0, "New York"};
SessionTime sydneySession = {22, 0, 7, 0, "Sydney"};

//+------------------------------------------------------------------+
//| Init                                                             |
//+------------------------------------------------------------------+
int OnInit() {
   // Validate TimeFrame
   if(InpUseTimeFrameFilter && _Period != InpAllowedTimeFrame) {
      Alert("ERROR: EA only works on " + TimeframeToString(InpAllowedTimeFrame) + " timeframe!");
      return(INIT_FAILED);
   }

   handleADX = iADX(_Symbol, _Period, InpADXPeriod);
   trade.SetExpertMagicNumber(InpMagic);
   sym.Name(_Symbol);
   
   // Load News Calendar
   if(InpUseNewsFilter) {
      LoadNewsCalendar();
   }
   
   Print("[INIT] JGV NO-LOSS PRO ENHANCED v4.00 initialized successfully!");
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Tick                                                             |
//+------------------------------------------------------------------+
void OnTick() {
   // Check all filters before processing
   if(!IsTimeAllowed()) {
      DisplayDashboard("Time Filter: OFF");
      return;
   }
   
   if(!IsSessionAllowed()) {
      DisplayDashboard("Session Filter: OFF");
      return;
   }
   
   if(InpUseNewsFilter && IsNewsEventNear()) {
      DisplayDashboard("News Event Near: PAUSED");
      return;
   }
   
   sym.RefreshRates();
   
   // 1. Manage existing basket (Closing at Break-Even + Profit)
   ManageBasketRecovery();
   
   // 2. Entry Signal for First Trade (Sideways Logic)
   if(CountTotalPositions() == 0) {
      CheckInitialEntry();
   } 
   // 3. Logic for adding to Recovery Grid
   else {
      CheckRecoveryGrid();
   }
   
   // 4. UI Display
   DisplayDashboard("TRADING");
}

//+------------------------------------------------------------------+
//| Time Filter - Check if trading is allowed by time                |
//+------------------------------------------------------------------+
bool IsTimeAllowed() {
   if(!InpUseTimeFilter) return true;
   
   MqlDateTime dt;
   TimeCurrent(dt);
   
   // Check Day of Week
   if(dt.day_of_week == 0 || dt.day_of_week == 6) { // Sunday or Saturday
      if(!InpTradeWeekend) return false;
   }
   
   // Check Start and End Days
   if(dt.day_of_week < InpStartDay || dt.day_of_week > InpEndDay) {
      if(!InpTradeWeekend) return false;
   }
   
   // Check Hour Range
   if(dt.hour < InpStartHour || dt.hour > InpEndHour) {
      return false;
   }
   
   return true;
}

//+------------------------------------------------------------------+
//| Session Filter - Check if trading is allowed in current session  |
//+------------------------------------------------------------------+
bool IsSessionAllowed() {
   if(!InpUseSessionFilter) return true;
   
   MqlDateTime dt;
   TimeCurrent(dt);
   int currentHour = dt.hour;
   int currentMin = dt.min;
   
   // Convert to minutes for easier comparison
   int currentTime = currentHour * 100 + currentMin;
   
   bool allowed = false;
   
   // Check Asia Session
   if(InpTradeAsia) {
      int asiaStart = asiaSession.startHour * 100 + asiaSession.startMin;
      int asiaEnd = asiaSession.endHour * 100 + asiaSession.endMin;
      if(currentTime >= asiaStart && currentTime <= asiaEnd) allowed = true;
   }
   
   // Check London Session
   if(InpTradeLondon) {
      int londonStart = londonSession.startHour * 100 + londonSession.startMin;
      int londonEnd = londonSession.endHour * 100 + londonSession.endMin;
      if(currentTime >= londonStart && currentTime <= londonEnd) allowed = true;
   }
   
   // Check New York Session
   if(InpTradeNewYork) {
      int newyorkStart = newyorkSession.startHour * 100 + newyorkSession.startMin;
      int newyorkEnd = newyorkSession.endHour * 100 + newyorkSession.endMin;
      if(currentTime >= newyorkStart && currentTime <= newyorkEnd) allowed = true;
   }
   
   // Check Sydney Session (handles midnight crossing)
   if(InpTradeSydney) {
      int sydneyStart = sydneySession.startHour * 100 + sydneySession.startMin;
      int sydneyEnd = sydneySession.endHour * 100 + sydneySession.endMin;
      if(currentTime >= sydneyStart || currentTime <= sydneyEnd) allowed = true;
   }
   
   return allowed;
}

//+------------------------------------------------------------------+
//| News Filter - Load Calendar from CSV                             |
//+------------------------------------------------------------------+
void LoadNewsCalendar() {
   // This function loads news data from the provided CSV URL
   // For production use, integrate with WebRequest or file system
   Print("[NEWS] Loading calendar from: " + InpNewsURL);
   
   // Note: Full implementation requires WebRequest API or external data source
   // This is a placeholder for news filtering logic
   newsCalendarData = "News calendar initialized";
}

//+------------------------------------------------------------------+
//| Check if News Event is Near                                      |
//+------------------------------------------------------------------+
bool IsNewsEventNear() {
   if(!InpUseNewsFilter) return false;
   
   datetime currentTime = TimeCurrent();
   
   // Check if we're within news event window
   // This is a simplified example - implement actual calendar parsing for production
   
   // Example: Pause trading if a high-impact news event is near
   // Parse CSV file and check event times
   
   return newsEventNear;
}

//+------------------------------------------------------------------+
//| Parse News Event Level from CSV Data                             |
//+------------------------------------------------------------------+
bool IsHighImpactNews(string newsLevel) {
   if(InpNewsLevelFilter == "All") return true;
   if(InpNewsLevelFilter == "High" && newsLevel == "High") return true;
   if(InpNewsLevelFilter == "Medium" && (newsLevel == "High" || newsLevel == "Medium")) return true;
   return false;
}

//+------------------------------------------------------------------+
//| Initial Trade Entry Logic                                        |
//+------------------------------------------------------------------+
void CheckInitialEntry() {
   double adx[], pDI[], mDI[];
   ArraySetAsSeries(adx, true);
   ArraySetAsSeries(pDI, true);
   ArraySetAsSeries(mDI, true);
   
   if(CopyBuffer(handleADX, 0, 0, 2, adx) < 2) return;
   if(CopyBuffer(handleADX, 1, 0, 2, pDI) < 2) return;
   if(CopyBuffer(handleADX, 2, 0, 2, mDI) < 2) return;
   
   // Sideways check: Only trade if ADX is between 15 and 25
   if(adx[0] < InpMinADXEntry || adx[0] > InpTrendThreshold) return;
   
   // Entry on DI Cross
   if(pDI[0] > mDI[0] && pDI[1] <= mDI[1]) {
      trade.Buy(InpLotSize, _Symbol, sym.Ask(), 0, 0, "Vishnu Initial Buy");
   }
   else if(mDI[0] > pDI[0] && mDI[1] <= pDI[1]) {
      trade.Sell(InpLotSize, _Symbol, sym.Bid(), 0, 0, "Vishnu Initial Sell");
   }
}

//+------------------------------------------------------------------+
//| Recovery Grid Management (The "No Loss" Engine)                  |
//+------------------------------------------------------------------+
void ManageBasketRecovery() {
   double totalProfit = 0;
   double totalLots = 0;
   int buyCount = 0, sellCount = 0;
   
   for(int i=PositionsTotal()-1; i>=0; i--) {
      if(pos.SelectByIndex(i) && pos.Magic() == InpMagic && pos.Symbol() == _Symbol) {
         totalProfit += pos.Commission() + pos.Swap() + pos.Profit();
         totalLots += pos.Volume();
         if(pos.PositionType() == POSITION_TYPE_BUY) buyCount++;
         else sellCount++;
      }
   }
   
   if(totalLots <= 0) return;

   // Calculation of target profit in currency based on points
   double tickValue = sym.TickValue();
   double profitTargetMoney = (InpBasketTP * _Point / sym.TickSize()) * tickValue * totalLots;
   
   if(totalProfit >= profitTargetMoney) {
      CloseAllPositions();
      Print("Recovery Successful. Basket closed in Profit.");
   }
}

//+------------------------------------------------------------------+
//| Smart Grid Logic                                                 |
//+------------------------------------------------------------------+
void CheckRecoveryGrid() {
   int buyCount = 0, sellCount = 0;
   double lastBuyPrice = 0, lastSellPrice = 0;
   double buyLots = 0, sellLots = 0;

   for(int i=PositionsTotal()-1; i>=0; i--) {
      if(pos.SelectByIndex(i) && pos.Magic() == InpMagic && pos.Symbol() == _Symbol) {
         if(pos.PositionType() == POSITION_TYPE_BUY) {
            buyCount++;
            if(lastBuyPrice == 0 || pos.PriceOpen() < lastBuyPrice) lastBuyPrice = pos.PriceOpen();
            buyLots = pos.Volume();
         } else {
            sellCount++;
            if(lastSellPrice == 0 || pos.PriceOpen() > lastSellPrice) lastSellPrice = pos.PriceOpen();
            sellLots = pos.Volume();
         }
      }
   }

   // Dynamic Grid Spacing based on ADX
   double adxVal[]; 
   ArraySetAsSeries(adxVal, true);
   if(CopyBuffer(handleADX, 0, 0, 1, adxVal) < 1) return;
   
   double dynamicDist = InpGridDistance;
   if(adxVal[0] > InpTrendThreshold) dynamicDist *= 1.5; 

   // Add to Buy Basket
   if(buyCount > 0 && buyCount < InpMaxOrders) {
      if(sym.Ask() < lastBuyPrice - (dynamicDist * _Point)) {
         double nextLot = NormalizeDouble(buyLots * InpLotMultiplier, 2);
         trade.Buy(nextLot, _Symbol, sym.Ask(), 0, 0, "Vishnu Recovery Buy "+(string)buyCount);
      }
   }
   
   // Add to Sell Basket
   if(sellCount > 0 && sellCount < InpMaxOrders) {
      if(sym.Bid() > lastSellPrice + (dynamicDist * _Point)) {
         double nextLot = NormalizeDouble(sellLots * InpLotMultiplier, 2);
         trade.Sell(nextLot, _Symbol, sym.Bid(), 0, 0, "Vishnu Recovery Sell "+(string)sellCount);
      }
   }
}

//+------------------------------------------------------------------+
//| Utility Functions                                                |
//+------------------------------------------------------------------+
void CloseAllPositions() {
   for(int i=PositionsTotal()-1; i>=0; i--) {
      if(pos.SelectByIndex(i) && pos.Magic() == InpMagic && pos.Symbol() == _Symbol)
         trade.PositionClose(pos.Ticket());
   }
}

int CountTotalPositions() {
   int c=0;
   for(int i=PositionsTotal()-1; i>=0; i--) {
      if(pos.SelectByIndex(i) && pos.Magic() == InpMagic && pos.Symbol() == _Symbol) c++;
   }
   return c;
}

string TimeframeToString(ENUM_TIMEFRAMES tf) {
   if(tf == PERIOD_M1) return "M1";
   if(tf == PERIOD_M5) return "M5";
   if(tf == PERIOD_M15) return "M15";
   if(tf == PERIOD_M30) return "M30";
   if(tf == PERIOD_H1) return "H1";
   if(tf == PERIOD_H4) return "H4";
   if(tf == PERIOD_D1) return "D1";
   if(tf == PERIOD_W1) return "W1";
   if(tf == PERIOD_MN1) return "MN1";
   return "Unknown";
}

string SessionToString(ENUM_TRADING_SESSION session) {
   if(session == SESSION_ASIA) return "Asia (09:00-17:00)";
   if(session == SESSION_LONDON) return "London (08:00-17:00)";
   if(session == SESSION_NEWYORK) return "New York (13:00-22:00)";
   if(session == SESSION_SYDNEY) return "Sydney (22:00-07:00)";
   return "Unknown";
}

void DisplayDashboard(string status = "TRADING") {
   string msg = "\n╔════════════════════════════════════════╗\n";
   msg += "║     JGV NO-LOSS PRO ENHANCED v4.00      ║\n";
   msg += "║══════════════════════════════════════════║\n";
   msg += "║ Status: " + status + "\n";
   msg += "║──────────────────────────────────────────║\n";
   msg += "║ Open Orders: " + (string)CountTotalPositions() + "\n";
   msg += "║ Symbol: " + _Symbol + "\n";
   msg += "║ TimeFrame: " + TimeframeToString(_Period) + "\n";
   msg += "║ Current Session: " + GetCurrentSession() + "\n";
   
   if(status == "TRADING") {
      double bal = AccountInfoDouble(ACCOUNT_EQUITY) - AccountInfoDouble(ACCOUNT_BALANCE);
      msg += "║ Floating P/L: " + DoubleToString(bal, 2) + "\n";
      msg += "║ Account Equity: " + DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY), 2) + "\n";
   }
   
   msg += "║──────────────────────────────────────────║\n";
   msg += "║ Filters Active:\n";
   msg += "║ • Time Filter: " + (InpUseTimeFilter ? "ON" : "OFF") + "\n";
   msg += "║ • Session Filter: " + (InpUseSessionFilter ? "ON" : "OFF") + "\n";
   msg += "║ • TimeFrame Filter: " + (InpUseTimeFrameFilter ? "ON" : "OFF") + "\n";
   msg += "║ • News Filter: " + (InpUseNewsFilter ? "ON" : "OFF") + "\n";
   msg += "║══════════════════════════════════════════║\n";
   msg += "╚════════════════════════════════════════════╝\n";
   
   Comment(msg);
}

string GetCurrentSession() {
   MqlDateTime dt;
   TimeCurrent(dt);
   int currentTime = dt.hour * 100 + dt.min;
   
   if(currentTime >= 900 && currentTime <= 1700) return "Asia";
   if(currentTime >= 800 && currentTime <= 1700) return "London";
   if(currentTime >= 1300 && currentTime <= 2200) return "New York";
   if(currentTime >= 2200 || currentTime <= 700) return "Sydney";
   
   return "None";
}

//+------------------------------------------------------------------+
//| OnDeinit                                                          |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
   Comment("");
   Print("[EXIT] JGV NO-LOSS PRO ENHANCED closed");
}
//+------------------------------------------------------------------+